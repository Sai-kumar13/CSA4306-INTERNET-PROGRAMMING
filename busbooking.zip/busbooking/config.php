<?php
session_start();

define('BASE', '/busbooking');   // folder name inside htdocs
define('DEMO_MODE', true);       // true: show password reset link on screen (mail() usually not set up in XAMPP)

mysqli_report(MYSQLI_REPORT_OFF);
$conn = @mysqli_connect('localhost', 'root', '', 'busbooking');
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error() .
        '<br><br>Fix: start MySQL in XAMPP, open http://localhost/phpmyadmin, and import database.sql (Import tab).');
}
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
mysqli_set_charset($conn, 'utf8mb4');

// Escape output
function e($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// Run a prepared query. SELECT returns a result, other queries return true.
function q($sql, $types = '', $params = []) {
    global $conn;
    $st = mysqli_prepare($conn, $sql);
    if ($types !== '') {
        mysqli_stmt_bind_param($st, $types, ...$params);
    }
    mysqli_stmt_execute($st);
    $res = mysqli_stmt_get_result($st);
    return $res ? $res : true;
}

function rows($res) {
    return mysqli_fetch_all($res, MYSQLI_ASSOC);
}

function one($res) {
    return mysqli_fetch_assoc($res);
}

function require_login() {
    if (!isset($_SESSION['user'])) {
        header('Location: ' . BASE . '/login.php');
        exit;
    }
}

function require_admin() {
    require_login();
    if ($_SESSION['user']['role'] !== 'admin') {
        header('Location: ' . BASE . '/index.php');
        exit;
    }
}

// Seat numbers already booked on a bus
function seats_booked($bus_id) {
    $r = rows(q("SELECT p.seat_no FROM passengers p JOIN bookings b ON b.id = p.booking_id
                 WHERE b.bus_id = ? AND b.status = 'Booked'", 'i', [$bus_id]));
    return array_map(function ($x) { return (int)$x['seat_no']; }, $r);
}

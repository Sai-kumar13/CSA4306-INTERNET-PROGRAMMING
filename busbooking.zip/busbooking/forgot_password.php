<?php
require __DIR__ . '/config.php';

$msg = '';
$link = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $u = one(q("SELECT id FROM users WHERE email = ?", 's', [$email]));
    if ($u) {
        $token = bin2hex(random_bytes(16));
        q("UPDATE users SET reset_token = ? WHERE id = ?", 'si', [$token, $u['id']]);
        $link = 'http://' . $_SERVER['HTTP_HOST'] . BASE . '/reset_password.php?token=' . $token;
        @mail($email, 'BusBook password reset', "Click to reset your password:\n" . $link, 'From: noreply@busbook.local');
    }
    $msg = 'If this email is registered, a password reset link has been sent.';
}
include __DIR__ . '/header.php';
?>
<div class="card formbox">
  <h2>Forgot Password</h2>
  <?php if ($msg): ?><div class="msg ok"><?= e($msg) ?></div><?php endif; ?>
  <?php if (DEMO_MODE && $link): ?>
    <div class="msg ok">Demo mode: <a href="<?= e($link) ?>">click here to reset your password</a></div>
  <?php endif; ?>
  <form method="post">
    Registered email<input type="email" name="email" required>
    <button type="submit">Send Reset Link</button>
  </form>
  <p><a href="login.php">Back to login</a></p>
</div>
<?php include __DIR__ . '/footer.php'; ?>

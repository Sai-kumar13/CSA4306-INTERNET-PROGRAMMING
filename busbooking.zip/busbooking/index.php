<?php
require __DIR__ . '/config.php';

$from = trim($_GET['from'] ?? '');
$to   = trim($_GET['to'] ?? '');
$date = $_GET['date'] ?? '';
$time = $_GET['time'] ?? '';

$sql = "SELECT b.*, c.name AS cat,
        (b.total_seats - (SELECT COUNT(*) FROM passengers p JOIN bookings k ON k.id = p.booking_id
                          WHERE k.bus_id = b.id AND k.status = 'Booked')) AS available
        FROM buses b JOIN categories c ON c.id = b.category_id
        WHERE b.travel_date >= CURDATE()";
$types = '';
$params = [];
if ($from !== '') { $sql .= " AND b.from_city LIKE ?"; $types .= 's'; $params[] = "%$from%"; }
if ($to !== '')   { $sql .= " AND b.to_city LIKE ?";   $types .= 's'; $params[] = "%$to%"; }
if ($date !== '') { $sql .= " AND b.travel_date = ?";  $types .= 's'; $params[] = $date; }
if ($time !== '') { $sql .= " AND b.travel_time >= ?"; $types .= 's'; $params[] = $time; }
$sql .= " ORDER BY b.travel_date, b.travel_time";
$buses = rows(q($sql, $types, $params));

$searching = ($from . $to . $date . $time) !== '';
$news = $searching ? [] : rows(q("SELECT * FROM news ORDER BY id DESC LIMIT 3"));

include __DIR__ . '/header.php';
?>
<h2>Search Buses</h2>
<form class="card" method="get">
  <div class="grid2">
    <div>From<input name="from" value="<?= e($from) ?>" placeholder="e.g. Chennai"></div>
    <div>To<input name="to" value="<?= e($to) ?>" placeholder="e.g. Bangalore"></div>
    <div>Date<input type="date" name="date" value="<?= e($date) ?>"></div>
    <div>Departure after<input type="time" name="time" value="<?= e($time) ?>"></div>
  </div>
  <button type="submit">Search</button>
  <a class="btn btn-gray" href="index.php">Reset</a>
</form>

<?php if ($news): ?>
<div class="card">
  <h3>Latest News</h3>
  <?php foreach ($news as $n): ?>
    <p><b><?= e($n['title']) ?></b><br><?= e($n['body']) ?></p>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<h2>Available Buses</h2>
<?php if (!$buses): ?>
  <div class="card">No buses found.</div>
<?php endif; ?>

<?php foreach ($buses as $b): ?>
<div class="card bus">
  <?php if ($b['photo']): ?>
    <img src="<?= BASE ?>/uploads/<?= e($b['photo']) ?>" alt="bus">
  <?php else: ?>
    <div class="noimg">&#128652;</div>
  <?php endif; ?>
  <div class="info">
    <h3><?= e($b['bus_name']) ?> <small>(<?= e($b['cat']) ?>)</small></h3>
    <p><b><?= e($b['from_city']) ?> &rarr; <?= e($b['to_city']) ?></b></p>
    <p>Date: <?= e($b['travel_date']) ?> &nbsp; Time: <?= e(substr($b['travel_time'], 0, 5)) ?></p>
    <p>Fare: &#8377;<?= e($b['price']) ?> per seat &nbsp; | &nbsp; Available seats: <?= (int)$b['available'] ?></p>
    <a class="btn" href="bus.php?id=<?= (int)$b['id'] ?>">View Details</a>
    <?php if ($b['available'] > 0): ?>
      <a class="btn" href="book.php?id=<?= (int)$b['id'] ?>">Book Now</a>
    <?php else: ?>
      <b>Sold out</b>
    <?php endif; ?>
  </div>
</div>
<?php endforeach; ?>

<?php include __DIR__ . '/footer.php'; ?>

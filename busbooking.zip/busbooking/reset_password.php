<?php
require __DIR__ . '/config.php';

$token = $_GET['token'] ?? ($_POST['token'] ?? '');
$u = $token !== '' ? one(q("SELECT id FROM users WHERE reset_token = ?", 's', [$token])) : null;

$err = '';
if ($u && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $new = $_POST['new'] ?? '';
    if (strlen($new) < 6) {
        $err = 'Password must be at least 6 characters.';
    } else {
        q("UPDATE users SET password = ?, reset_token = NULL WHERE id = ?", 'si',
          [password_hash($new, PASSWORD_DEFAULT), $u['id']]);
        header('Location: login.php?reset=1');
        exit;
    }
}
include __DIR__ . '/header.php';
?>
<div class="card formbox">
  <h2>Reset Password</h2>
  <?php if (!$u): ?>
    <div class="msg err">This reset link is invalid or already used.</div>
  <?php else: ?>
    <?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
    <form method="post">
      <input type="hidden" name="token" value="<?= e($token) ?>">
      New password<input type="password" name="new" required>
      <button type="submit">Set Password</button>
    </form>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/footer.php'; ?>

<?php
require __DIR__ . '/config.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    q("UPDATE bookings SET status = 'Cancelled' WHERE id = ? AND user_id = ? AND status = 'Booked'",
      'ii', [$id, $_SESSION['user']['id']]);
}
header('Location: my_bookings.php?cancelled=1');
exit;

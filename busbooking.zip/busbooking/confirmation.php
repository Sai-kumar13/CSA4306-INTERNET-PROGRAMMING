<?php
require __DIR__ . '/config.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
$k = one(q("SELECT k.*, b.bus_name, b.from_city, b.to_city, b.travel_date, b.travel_time, u.email
            FROM bookings k JOIN buses b ON b.id = k.bus_id JOIN users u ON u.id = k.user_id
            WHERE k.id = ? AND k.user_id = ?", 'ii', [$id, $_SESSION['user']['id']]));
if (!$k) {
    header('Location: my_bookings.php');
    exit;
}
$pax = rows(q("SELECT * FROM passengers WHERE booking_id = ? ORDER BY seat_no", 'i', [$id]));

include __DIR__ . '/header.php';
?>
<div class="card">
  <h2>&#10004; Booking Confirmed</h2>
  <p>Booking ID: <b>#<?= (int)$k['id'] ?></b> &nbsp; | &nbsp; Payment: <?= e($k['payment_status']) ?></p>
  <p><?= e($k['bus_name']) ?> &mdash; <?= e($k['from_city']) ?> &rarr; <?= e($k['to_city']) ?><br>
     <?= e($k['travel_date']) ?> at <?= e(substr($k['travel_time'], 0, 5)) ?></p>
  <div class="table-wrap">
  <table>
    <tr><th>Seat</th><th>Passenger</th><th>Age</th></tr>
    <?php foreach ($pax as $p): ?>
      <tr><td><?= (int)$p['seat_no'] ?></td><td><?= e($p['name']) ?></td><td><?= (int)$p['age'] ?></td></tr>
    <?php endforeach; ?>
  </table>
  </div>
  <p>Total paid: <b>&#8377;<?= e($k['total_amount']) ?></b></p>
  <p>A confirmation email has been sent to <?= e($k['email']) ?> (requires mail setup in XAMPP).</p>
  <a class="btn" href="my_bookings.php">Go to My Bookings</a>
</div>
<?php include __DIR__ . '/footer.php'; ?>

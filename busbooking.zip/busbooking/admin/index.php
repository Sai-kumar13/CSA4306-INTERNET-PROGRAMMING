<?php
require __DIR__ . '/../config.php';
require_admin();

$stats = [
    'Registered users' => one(q("SELECT COUNT(*) c FROM users WHERE role = 'user'"))['c'],
    'Bus categories'   => one(q("SELECT COUNT(*) c FROM categories"))['c'],
    'Buses'            => one(q("SELECT COUNT(*) c FROM buses"))['c'],
    'Active bookings'  => one(q("SELECT COUNT(*) c FROM bookings WHERE status = 'Booked'"))['c'],
    'Comments'         => one(q("SELECT COUNT(*) c FROM comments"))['c'],
];

include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<h2>Admin Dashboard</h2>
<div class="grid2">
  <?php foreach ($stats as $label => $n): ?>
    <div class="card"><h2><?= (int)$n ?></h2><?= e($label) ?></div>
  <?php endforeach; ?>
</div>
<?php include __DIR__ . '/../footer.php'; ?>

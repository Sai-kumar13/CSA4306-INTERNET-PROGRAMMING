<?php
require __DIR__ . '/../config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete'])) {
        q("DELETE FROM news WHERE id = ?", 'i', [(int)$_POST['delete']]);
    } else {
        $title = trim($_POST['title'] ?? '');
        $body = trim($_POST['body'] ?? '');
        if ($title !== '' && $body !== '') {
            q("INSERT INTO news (title, body) VALUES (?, ?)", 'ss', [$title, $body]);
        }
    }
    header('Location: news.php');
    exit;
}
$news = rows(q("SELECT * FROM news ORDER BY id DESC"));

include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<h2>Manage News</h2>
<form method="post" class="card formbox">
  Title<input name="title" required>
  News<textarea name="body" rows="3" required></textarea>
  <button type="submit">Add News</button>
</form>

<div class="table-wrap">
<table>
  <tr><th>Date</th><th>Title</th><th>News</th><th></th></tr>
  <?php foreach ($news as $n): ?>
  <tr>
    <td><?= e($n['created_at']) ?></td>
    <td><?= e($n['title']) ?></td>
    <td><?= e($n['body']) ?></td>
    <td>
      <form method="post" onsubmit="return confirm('Delete this news?');">
        <button class="btn-red small" name="delete" value="<?= (int)$n['id'] ?>">Delete</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/../footer.php'; ?>

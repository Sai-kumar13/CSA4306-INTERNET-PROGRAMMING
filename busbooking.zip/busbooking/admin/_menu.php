<div class="card menu">
  <b>Admin:</b>
  <a href="<?= BASE ?>/admin/index.php">Dashboard</a>
  <a href="<?= BASE ?>/admin/categories.php">Bus Categories</a>
  <a href="<?= BASE ?>/admin/buses.php">Buses</a>
  <a href="<?= BASE ?>/admin/users.php">Users</a>
  <a href="<?= BASE ?>/admin/news.php">News</a>
  <a href="<?= BASE ?>/admin/comments.php">Comments</a>
  <a href="<?= BASE ?>/admin/report.php">Reports</a>
</div>

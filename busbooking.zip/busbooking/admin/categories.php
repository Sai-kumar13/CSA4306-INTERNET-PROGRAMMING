<?php
require __DIR__ . '/../config.php';
require_admin();

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete'])) {
        q("DELETE FROM categories WHERE id = ?", 'i', [(int)$_POST['delete']]);
        header('Location: categories.php');
        exit;
    }
    $name = trim($_POST['name'] ?? '');
    if ($name === '') {
        $err = 'Enter a category name.';
    } elseif (one(q("SELECT id FROM categories WHERE name = ?", 's', [$name]))) {
        $err = 'Category already exists.';
    } else {
        q("INSERT INTO categories (name) VALUES (?)", 's', [$name]);
        header('Location: categories.php');
        exit;
    }
}
$cats = rows(q("SELECT c.*, (SELECT COUNT(*) FROM buses WHERE category_id = c.id) AS n FROM categories c ORDER BY c.name"));

include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<h2>Bus Categories</h2>
<?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="card formbox">
  Add new category (e.g. Volvo, Sleeper Coach, Coach)
  <input name="name" required>
  <button type="submit">Add Category</button>
</form>

<div class="table-wrap">
<table>
  <tr><th>ID</th><th>Category</th><th>Buses</th><th></th></tr>
  <?php foreach ($cats as $c): ?>
  <tr>
    <td><?= (int)$c['id'] ?></td>
    <td><?= e($c['name']) ?></td>
    <td><?= (int)$c['n'] ?></td>
    <td>
      <form method="post" onsubmit="return confirm('Delete this category and all its buses?');">
        <button class="btn-red small" name="delete" value="<?= (int)$c['id'] ?>">Delete</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/../footer.php'; ?>

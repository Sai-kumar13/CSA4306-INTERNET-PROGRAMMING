<?php
require __DIR__ . '/../config.php';
require_admin();

$from = $_GET['from'] ?? '';
$to   = $_GET['to'] ?? '';

$where = '1=1';
$types = '';
$params = [];
if ($from !== '') { $where .= " AND b.travel_date >= ?"; $types .= 's'; $params[] = $from; }
if ($to !== '')   { $where .= " AND b.travel_date <= ?"; $types .= 's'; $params[] = $to; }

$report = rows(q("SELECT b.bus_name, b.from_city, b.to_city, b.travel_date, b.total_seats,
    (SELECT COUNT(*) FROM bookings k WHERE k.bus_id = b.id AND k.status = 'Booked') AS bookings,
    (SELECT COUNT(*) FROM passengers p JOIN bookings k ON k.id = p.booking_id WHERE k.bus_id = b.id AND k.status = 'Booked') AS seats_sold,
    (SELECT COALESCE(SUM(k.total_amount), 0) FROM bookings k WHERE k.bus_id = b.id AND k.status = 'Booked') AS revenue,
    (SELECT COUNT(*) FROM bookings k WHERE k.bus_id = b.id AND k.status = 'Cancelled') AS cancelled
    FROM buses b WHERE $where ORDER BY b.travel_date, b.bus_name", $types, $params));

$tot = ['bookings' => 0, 'seats_sold' => 0, 'revenue' => 0, 'cancelled' => 0];
foreach ($report as $r) {
    foreach ($tot as $k => $x) { $tot[$k] += $r[$k]; }
}

include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<h2>Booking Report</h2>
<form method="get" class="card noprint">
  <div class="grid2">
    <div>Travel date from<input type="date" name="from" value="<?= e($from) ?>"></div>
    <div>Travel date to<input type="date" name="to" value="<?= e($to) ?>"></div>
  </div>
  <button type="submit">Generate</button>
  <button type="button" class="btn-gray" onclick="window.print()">Print</button>
</form>

<p>Generated on <?= date('Y-m-d H:i') ?></p>
<div class="table-wrap">
<table>
  <tr><th>Bus</th><th>Route</th><th>Date</th><th>Total Seats</th><th>Bookings</th><th>Seats Sold</th><th>Cancelled</th><th>Revenue</th></tr>
  <?php if (!$report): ?><tr><td colspan="8">No data.</td></tr><?php endif; ?>
  <?php foreach ($report as $r): ?>
  <tr>
    <td><?= e($r['bus_name']) ?></td>
    <td><?= e($r['from_city']) ?> &rarr; <?= e($r['to_city']) ?></td>
    <td><?= e($r['travel_date']) ?></td>
    <td><?= (int)$r['total_seats'] ?></td>
    <td><?= (int)$r['bookings'] ?></td>
    <td><?= (int)$r['seats_sold'] ?></td>
    <td><?= (int)$r['cancelled'] ?></td>
    <td>&#8377;<?= e(number_format($r['revenue'], 2)) ?></td>
  </tr>
  <?php endforeach; ?>
  <tr>
    <th colspan="4">Total</th>
    <th><?= (int)$tot['bookings'] ?></th>
    <th><?= (int)$tot['seats_sold'] ?></th>
    <th><?= (int)$tot['cancelled'] ?></th>
    <th>&#8377;<?= e(number_format($tot['revenue'], 2)) ?></th>
  </tr>
</table>
</div>
<?php include __DIR__ . '/../footer.php'; ?>

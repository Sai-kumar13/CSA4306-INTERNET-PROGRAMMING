<?php
require __DIR__ . '/../config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    q("DELETE FROM comments WHERE id = ?", 'i', [(int)$_POST['delete']]);
    header('Location: comments.php');
    exit;
}
$list = rows(q("SELECT c.*, u.name, b.bus_name FROM comments c
                JOIN users u ON u.id = c.user_id JOIN buses b ON b.id = c.bus_id ORDER BY c.id DESC"));

include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<h2>Manage Comments</h2>
<div class="table-wrap">
<table>
  <tr><th>Date</th><th>Bus</th><th>User</th><th>Comment</th><th></th></tr>
  <?php if (!$list): ?><tr><td colspan="5">No comments.</td></tr><?php endif; ?>
  <?php foreach ($list as $c): ?>
  <tr>
    <td><?= e($c['created_at']) ?></td>
    <td><?= e($c['bus_name']) ?></td>
    <td><?= e($c['name']) ?></td>
    <td><?= e($c['comment']) ?></td>
    <td>
      <form method="post" onsubmit="return confirm('Delete this comment?');">
        <button class="btn-red small" name="delete" value="<?= (int)$c['id'] ?>">Delete</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/../footer.php'; ?>

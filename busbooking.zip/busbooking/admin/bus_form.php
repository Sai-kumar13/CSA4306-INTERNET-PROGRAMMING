<?php
require __DIR__ . '/../config.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
$bus = $id ? one(q("SELECT * FROM buses WHERE id = ?", 'i', [$id])) : null;
if ($id && !$bus) {
    header('Location: buses.php');
    exit;
}
$cats = rows(q("SELECT * FROM categories ORDER BY name"));

// Form values (existing bus, or empty for a new one)
$v = $bus ?: ['category_id' => '', 'bus_name' => '', 'from_city' => '', 'to_city' => '', 'travel_date' => '',
              'travel_time' => '', 'price' => '', 'total_seats' => 40, 'description' => '', 'photo' => ''];
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v['category_id'] = (int)($_POST['category_id'] ?? 0);
    $v['bus_name']    = trim($_POST['bus_name'] ?? '');
    $v['from_city']   = trim($_POST['from_city'] ?? '');
    $v['to_city']     = trim($_POST['to_city'] ?? '');
    $v['travel_date'] = $_POST['travel_date'] ?? '';
    $v['travel_time'] = $_POST['travel_time'] ?? '';
    $v['price']       = (float)($_POST['price'] ?? 0);
    $v['total_seats'] = (int)($_POST['total_seats'] ?? 0);
    $v['description'] = trim($_POST['description'] ?? '');

    if (!$v['category_id'] || $v['bus_name'] === '' || $v['from_city'] === '' || $v['to_city'] === ''
        || $v['travel_date'] === '' || $v['travel_time'] === '' || $v['price'] <= 0) {
        $err = 'Please fill all required fields.';
    } elseif ($v['total_seats'] < 1 || $v['total_seats'] > 60) {
        $err = 'Seats must be between 1 and 60.';
    } elseif ($id && ($booked = seats_booked($id)) && $v['total_seats'] < max($booked)) {
        $err = 'Total seats cannot be less than the highest booked seat number (' . max($booked) . ').';
    }

    // Photo upload (optional)
    if ($err === '' && !empty($_FILES['photo']['name'])) {
        $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
            $err = 'Photo must be a jpg, png, gif or webp image.';
        } else {
            $fn = uniqid('bus_') . '.' . $ext;
            move_uploaded_file($_FILES['photo']['tmp_name'], __DIR__ . '/../uploads/' . $fn);
            $v['photo'] = $fn;
        }
    }

    if ($err === '') {
        if ($id) {
            q("UPDATE buses SET category_id=?, bus_name=?, from_city=?, to_city=?, travel_date=?, travel_time=?,
               price=?, total_seats=?, description=?, photo=? WHERE id=?",
              'isssssdissi', [$v['category_id'], $v['bus_name'], $v['from_city'], $v['to_city'], $v['travel_date'],
                              $v['travel_time'], $v['price'], $v['total_seats'], $v['description'], $v['photo'], $id]);
        } else {
            q("INSERT INTO buses (category_id, bus_name, from_city, to_city, travel_date, travel_time, price, total_seats, description, photo)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
              'isssssdiss', [$v['category_id'], $v['bus_name'], $v['from_city'], $v['to_city'], $v['travel_date'],
                             $v['travel_time'], $v['price'], $v['total_seats'], $v['description'], $v['photo']]);
        }
        header('Location: buses.php');
        exit;
    }
}

include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<h2><?= $id ? 'Update Bus' : 'Add New Bus' ?></h2>
<?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
<?php if (!$cats): ?><div class="msg err">Add a bus category first.</div><?php endif; ?>

<form method="post" enctype="multipart/form-data" class="card formbox">
  Bus type (category)
  <select name="category_id" required>
    <option value="">-- select --</option>
    <?php foreach ($cats as $c): ?>
      <option value="<?= (int)$c['id'] ?>" <?= $v['category_id'] == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
    <?php endforeach; ?>
  </select>
  Bus name<input name="bus_name" value="<?= e($v['bus_name']) ?>" required>
  From<input name="from_city" value="<?= e($v['from_city']) ?>" required>
  To<input name="to_city" value="<?= e($v['to_city']) ?>" required>
  Travel date<input type="date" name="travel_date" value="<?= e($v['travel_date']) ?>" required>
  Departure time<input type="time" name="travel_time" value="<?= e(substr($v['travel_time'], 0, 5)) ?>" required>
  Fare per seat (&#8377;)<input type="number" step="0.01" name="price" value="<?= e($v['price']) ?>" required>
  Total seats<input type="number" name="total_seats" min="1" max="60" value="<?= e($v['total_seats']) ?>" required>
  Description<textarea name="description" rows="3"><?= e($v['description']) ?></textarea>
  Photo <?= $v['photo'] ? '(leave empty to keep current)' : '' ?>
  <input type="file" name="photo" accept="image/*">
  <button type="submit"><?= $id ? 'Update' : 'Add' ?> Bus</button>
  <a class="btn btn-gray" href="buses.php">Cancel</a>
</form>
<?php include __DIR__ . '/../footer.php'; ?>

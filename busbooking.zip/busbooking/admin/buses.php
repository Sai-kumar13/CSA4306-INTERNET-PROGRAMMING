<?php
require __DIR__ . '/../config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    q("DELETE FROM buses WHERE id = ?", 'i', [(int)$_POST['delete']]);
    header('Location: buses.php');
    exit;
}

$buses = rows(q("SELECT b.*, c.name AS cat,
                 (b.total_seats - (SELECT COUNT(*) FROM passengers p JOIN bookings k ON k.id = p.booking_id
                                   WHERE k.bus_id = b.id AND k.status = 'Booked')) AS available
                 FROM buses b JOIN categories c ON c.id = b.category_id ORDER BY b.travel_date, b.travel_time"));

include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<h2>Buses</h2>
<p><a class="btn" href="bus_form.php">+ Add New Bus</a></p>
<div class="table-wrap">
<table>
  <tr><th>ID</th><th>Bus</th><th>Category</th><th>Route</th><th>Date / Time</th><th>Fare</th><th>Seats (free/total)</th><th></th></tr>
  <?php foreach ($buses as $b): ?>
  <tr>
    <td><?= (int)$b['id'] ?></td>
    <td><?= e($b['bus_name']) ?></td>
    <td><?= e($b['cat']) ?></td>
    <td><?= e($b['from_city']) ?> &rarr; <?= e($b['to_city']) ?></td>
    <td><?= e($b['travel_date']) ?> <?= e(substr($b['travel_time'], 0, 5)) ?></td>
    <td>&#8377;<?= e($b['price']) ?></td>
    <td><?= (int)$b['available'] ?> / <?= (int)$b['total_seats'] ?></td>
    <td>
      <a class="btn small" href="bus_form.php?id=<?= (int)$b['id'] ?>">Edit</a>
      <form method="post" style="display:inline" onsubmit="return confirm('Delete this bus and its bookings?');">
        <button class="btn-red small" name="delete" value="<?= (int)$b['id'] ?>">Delete</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/../footer.php'; ?>

<?php
require __DIR__ . '/config.php';
require_login();

$err = $ok = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old = $_POST['old'] ?? '';
    $new = $_POST['new'] ?? '';
    $confirm = $_POST['confirm'] ?? '';
    $u = one(q("SELECT password FROM users WHERE id = ?", 'i', [$_SESSION['user']['id']]));

    if (!password_verify($old, $u['password'])) {
        $err = 'Current password is wrong.';
    } elseif (strlen($new) < 6) {
        $err = 'New password must be at least 6 characters.';
    } elseif ($new !== $confirm) {
        $err = 'New passwords do not match.';
    } else {
        q("UPDATE users SET password = ? WHERE id = ?", 'si',
          [password_hash($new, PASSWORD_DEFAULT), $_SESSION['user']['id']]);
        $ok = 'Password changed successfully.';
    }
}
include __DIR__ . '/header.php';
?>
<div class="card formbox">
  <h2>Change Password</h2>
  <?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
  <?php if ($ok): ?><div class="msg ok"><?= e($ok) ?></div><?php endif; ?>
  <form method="post">
    Current password<input type="password" name="old" required>
    New password<input type="password" name="new" required>
    Confirm new password<input type="password" name="confirm" required>
    <button type="submit">Change Password</button>
  </form>
</div>
<?php include __DIR__ . '/footer.php'; ?>

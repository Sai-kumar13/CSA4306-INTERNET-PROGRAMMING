<?php require_once __DIR__ . '/config.php'; ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BusBook - Online Bus Ticket Booking</title>
<link rel="stylesheet" href="<?= BASE ?>/style.css">
</head>
<body>
<header>
  <div class="wrap nav">
    <a class="logo" href="<?= BASE ?>/index.php">&#128652; BusBook</a>
    <nav>
      <a href="<?= BASE ?>/index.php">Home</a>
      <?php if (isset($_SESSION['user'])): ?>
        <?php if ($_SESSION['user']['role'] === 'admin'): ?>
          <a href="<?= BASE ?>/admin/index.php">Admin Panel</a>
        <?php else: ?>
          <a href="<?= BASE ?>/my_bookings.php">My Bookings</a>
        <?php endif; ?>
        <a href="<?= BASE ?>/change_password.php">Change Password</a>
        <a href="<?= BASE ?>/logout.php">Logout (<?= e($_SESSION['user']['name']) ?>)</a>
      <?php else: ?>
        <a href="<?= BASE ?>/login.php">Login</a>
        <a href="<?= BASE ?>/register.php">Register</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main><div class="wrap">

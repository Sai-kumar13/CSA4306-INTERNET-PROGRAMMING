-- Import this file in phpMyAdmin (Import tab) or run: mysql -u root < database.sql
-- WARNING: re-importing resets all data.
CREATE DATABASE IF NOT EXISTS busbooking;
USE busbooking;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS comments, passengers, bookings, news, buses, categories, users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('user','admin') NOT NULL DEFAULT 'user',
  reset_token VARCHAR(64) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE buses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT NOT NULL,
  bus_name VARCHAR(100) NOT NULL,
  from_city VARCHAR(60) NOT NULL,
  to_city VARCHAR(60) NOT NULL,
  travel_date DATE NOT NULL,
  travel_time TIME NOT NULL,
  price DECIMAL(8,2) NOT NULL,
  total_seats INT NOT NULL,
  description TEXT,
  photo VARCHAR(255) NULL,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  bus_id INT NOT NULL,
  phone VARCHAR(15) NOT NULL,
  total_amount DECIMAL(8,2) NOT NULL,
  payment_status VARCHAR(20) NOT NULL DEFAULT 'Paid',
  status ENUM('Booked','Cancelled') NOT NULL DEFAULT 'Booked',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (bus_id) REFERENCES buses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE passengers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  seat_no INT NOT NULL,
  name VARCHAR(100) NOT NULL,
  age INT NOT NULL,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE news (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  body TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE comments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  bus_id INT NOT NULL,
  user_id INT NOT NULL,
  comment TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (bus_id) REFERENCES buses(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Admin login: admin@busbook.com / admin123
INSERT INTO users (name, email, password, role) VALUES
('Admin', 'admin@busbook.com', '$2y$10$MUL5X1ossjEgl7UcBkmmMu9pa6yvdxcV2B3b0pv9CTDkYbUZ1kBqe', 'admin');

INSERT INTO categories (name) VALUES ('Volvo'), ('Sleeper Coach'), ('Coach');

INSERT INTO buses (category_id, bus_name, from_city, to_city, travel_date, travel_time, price, total_seats, description) VALUES
(1, 'Volvo Multi-Axle', 'Chennai', 'Bangalore', DATE_ADD(CURDATE(), INTERVAL 1 DAY), '21:30:00', 850.00, 40, 'AC Volvo with push-back seats, charging point and water bottle.'),
(2, 'Night Rider Sleeper', 'Chennai', 'Madurai', DATE_ADD(CURDATE(), INTERVAL 1 DAY), '22:00:00', 950.00, 30, 'AC sleeper coach with blanket and reading light.'),
(3, 'Express Coach', 'Chennai', 'Coimbatore', DATE_ADD(CURDATE(), INTERVAL 2 DAY), '08:15:00', 600.00, 36, 'Non-AC express coach, comfortable seats.'),
(1, 'Volvo Executive', 'Bangalore', 'Hyderabad', DATE_ADD(CURDATE(), INTERVAL 3 DAY), '19:00:00', 1200.00, 40, 'AC Volvo executive class with snacks.'),
(2, 'Dream Sleeper', 'Chennai', 'Bangalore', DATE_ADD(CURDATE(), INTERVAL 2 DAY), '23:00:00', 1000.00, 28, 'AC sleeper with single and double berths.');

INSERT INTO news (title, body) VALUES
('Welcome to BusBook', 'Book your bus tickets online quickly and securely.'),
('Festival Special Buses', 'Extra buses are added on popular routes during festival season.');

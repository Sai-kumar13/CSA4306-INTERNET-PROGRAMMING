<?php
require __DIR__ . '/config.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
$bus = one(q("SELECT * FROM buses WHERE id = ?", 'i', [$id]));
if (!$bus) {
    header('Location: index.php');
    exit;
}

$taken = seats_booked($id);
$past = $bus['travel_date'] < date('Y-m-d');
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$past) {
    $seats = $_POST['seats'] ?? [];
    $names = $_POST['name'] ?? [];
    $ages  = $_POST['age'] ?? [];
    $phone = trim($_POST['phone'] ?? '');
    $pax = [];

    if (!$seats) {
        $err = 'Please select at least one seat.';
    } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $err = 'Enter a valid 10 digit mobile number.';
    } else {
        foreach ($seats as $s) {
            $s = (int)$s;
            $n = trim($names[$s] ?? '');
            $a = (int)($ages[$s] ?? 0);
            if ($s < 1 || $s > $bus['total_seats'] || in_array($s, $taken)) {
                $err = "Seat $s is not available.";
                break;
            }
            if ($n === '' || $a < 1 || $a > 120) {
                $err = "Enter name and age for seat $s.";
                break;
            }
            $pax[$s] = ['name' => $n, 'age' => $a];
        }
    }

    if ($err === '') {
        $_SESSION['pending'] = ['bus_id' => $id, 'phone' => $phone, 'passengers' => $pax];
        header('Location: payment.php');
        exit;
    }
}

include __DIR__ . '/header.php';
?>
<h2>Book Ticket</h2>
<div class="card">
  <b><?= e($bus['bus_name']) ?></b> &mdash; <?= e($bus['from_city']) ?> &rarr; <?= e($bus['to_city']) ?><br>
  <?= e($bus['travel_date']) ?> at <?= e(substr($bus['travel_time'], 0, 5)) ?> &nbsp;|&nbsp; &#8377;<?= e($bus['price']) ?> per seat
</div>

<?php if ($past): ?>
  <div class="msg err">This bus has already departed.</div>
<?php else: ?>
<?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="card">
  <h3>1. Select Seats</h3>
  <div class="seats">
    <?php for ($i = 1; $i <= $bus['total_seats']; $i++): $t = in_array($i, $taken); ?>
      <label class="seat <?= $t ? 'taken' : '' ?>">
        <input type="checkbox" name="seats[]" value="<?= $i ?>" <?= $t ? 'disabled' : '' ?>><?= $i ?>
      </label>
    <?php endfor; ?>
  </div>
  <small>Grey seats are already booked.</small>

  <h3>2. Passenger Details</h3>
  <div id="pax"><small>Select seats above to enter passenger details.</small></div>
  Mobile number<input name="phone" maxlength="10" required>

  <button type="submit">Continue to Payment</button>
</form>

<script>
var box = document.getElementById('pax');
document.querySelectorAll('.seat input').forEach(function (c) {
  c.addEventListener('change', function () {
    var pid = 'pax' + c.value, ex = document.getElementById(pid);
    if (c.checked && !ex) {
      var d = document.createElement('div');
      d.id = pid; d.className = 'pax';
      d.innerHTML = '<b>Seat ' + c.value + '</b> ' +
        '<input type="text" name="name[' + c.value + ']" placeholder="Passenger name" required>' +
        '<input type="number" name="age[' + c.value + ']" placeholder="Age" min="1" max="120" required>';
      box.appendChild(d);
    } else if (!c.checked && ex) {
      ex.remove();
    }
  });
});
</script>
<?php endif; ?>
<?php include __DIR__ . '/footer.php'; ?>

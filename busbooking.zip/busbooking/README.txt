ONLINE BUS TICKET BOOKING SYSTEM  (PHP + MySQL, XAMPP)
=======================================================

SETUP
1. Install and start XAMPP (Apache + MySQL).
2. Copy the "busbooking" folder into  C:\xampp\htdocs\
3. Open http://localhost/phpmyadmin -> Import tab -> choose database.sql -> Go.
   (This creates the database "busbooking" with tables and sample data.)
4. Open http://localhost/busbooking/

LOGINS
  Admin : admin@busbook.com / admin123
  User  : click Register to create one.

DATABASE SETTINGS (config.php)
  host: localhost, user: root, password: (empty), database: busbooking
  If you rename the folder, change BASE in config.php.

MODULES
  Search buses (route, date, time) ........ index.php
  Register / Login ........................ register.php, login.php
  Change / Forgot password ................ change_password.php, forgot_password.php, reset_password.php
  Bus details + Comments .................. bus.php
  Book ticket (seats, passengers) ......... book.php
  Payment (demo gateway) .................. payment.php, confirmation.php
  Dashboard / Cancel ticket ............... my_bookings.php, cancel.php
  Admin: categories, buses, users, news,
         comments, reports ................ admin/ folder

NOTES
  * Payment is a demo gateway: any well-formed card (16 digits, MM/YY, 3-digit CVV)
    is accepted, e.g. 4111 1111 1111 1111. Card details are not stored.
  * Confirmation and reset emails use PHP mail(), which needs mail setup in XAMPP.
    Without it the booking still works. In DEMO_MODE (config.php) the password
    reset link is shown on screen instead.
  * Bus photos are saved in the uploads/ folder.

<?php
require __DIR__ . '/config.php';

$id = (int)($_GET['id'] ?? 0);
$b = one(q("SELECT b.*, c.name AS cat FROM buses b JOIN categories c ON c.id = b.category_id WHERE b.id = ?", 'i', [$id]));
if (!$b) {
    header('Location: index.php');
    exit;
}

// Post a comment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_login();
    $text = trim($_POST['comment'] ?? '');
    if ($text !== '') {
        q("INSERT INTO comments (bus_id, user_id, comment) VALUES (?, ?, ?)", 'iis', [$id, $_SESSION['user']['id'], $text]);
    }
    header('Location: bus.php?id=' . $id);
    exit;
}

$available = $b['total_seats'] - count(seats_booked($id));
$comments = rows(q("SELECT c.*, u.name FROM comments c JOIN users u ON u.id = c.user_id WHERE c.bus_id = ? ORDER BY c.id DESC", 'i', [$id]));

include __DIR__ . '/header.php';
?>
<div class="card bus">
  <?php if ($b['photo']): ?>
    <img src="<?= BASE ?>/uploads/<?= e($b['photo']) ?>" alt="bus">
  <?php else: ?>
    <div class="noimg">&#128652;</div>
  <?php endif; ?>
  <div class="info">
    <h2><?= e($b['bus_name']) ?> <small>(<?= e($b['cat']) ?>)</small></h2>
    <p><b><?= e($b['from_city']) ?> &rarr; <?= e($b['to_city']) ?></b></p>
    <p>Date: <?= e($b['travel_date']) ?> &nbsp; Time: <?= e(substr($b['travel_time'], 0, 5)) ?></p>
    <p>Fare: &#8377;<?= e($b['price']) ?> per seat</p>
    <p>Seats: <?= (int)$available ?> available of <?= (int)$b['total_seats'] ?></p>
    <p><?= nl2br(e($b['description'])) ?></p>
    <?php if ($available > 0): ?>
      <a class="btn" href="book.php?id=<?= $id ?>">Book Now</a>
    <?php else: ?>
      <b>Sold out</b>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <h3>Comments</h3>
  <?php if (isset($_SESSION['user'])): ?>
    <form method="post">
      <textarea name="comment" rows="3" placeholder="Write your comment about this bus" required></textarea>
      <button type="submit">Post Comment</button>
    </form>
  <?php else: ?>
    <p><a href="login.php">Login</a> to post a comment.</p>
  <?php endif; ?>

  <?php if (!$comments): ?><p>No comments yet.</p><?php endif; ?>
  <?php foreach ($comments as $c): ?>
    <div class="comment">
      <b><?= e($c['name']) ?></b> <small><?= e($c['created_at']) ?></small><br>
      <?= nl2br(e($c['comment'])) ?>
    </div>
  <?php endforeach; ?>
</div>
<?php include __DIR__ . '/footer.php'; ?>

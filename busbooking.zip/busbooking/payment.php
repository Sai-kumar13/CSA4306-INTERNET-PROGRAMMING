<?php
require __DIR__ . '/config.php';
require_login();

$p = $_SESSION['pending'] ?? null;
if (!$p) {
    header('Location: index.php');
    exit;
}
$bus = one(q("SELECT * FROM buses WHERE id = ?", 'i', [$p['bus_id']]));
$count = count($p['passengers']);
$total = $count * $bus['price'];
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $holder = trim($_POST['card_name'] ?? '');
    $card = preg_replace('/\D/', '', $_POST['card_no'] ?? '');
    $exp = trim($_POST['expiry'] ?? '');
    $cvv = trim($_POST['cvv'] ?? '');

    if ($holder === '' || strlen($card) !== 16 || !preg_match('#^(0[1-9]|1[0-2])/\d{2}$#', $exp) || !preg_match('/^\d{3}$/', $cvv)) {
        $err = 'Invalid card details.';
    } else {
        // Simulated payment gateway: accepts any well-formed card. Card data is NOT stored.
        $taken = seats_booked($bus['id']);
        foreach ($p['passengers'] as $seat => $info) {
            if (in_array($seat, $taken)) {
                $err = "Seat $seat was just booked by someone else. Please select again.";
            }
        }
        if ($err === '') {
            q("INSERT INTO bookings (user_id, bus_id, phone, total_amount, payment_status, status) VALUES (?, ?, ?, ?, 'Paid', 'Booked')",
              'iisd', [$_SESSION['user']['id'], $bus['id'], $p['phone'], $total]);
            $booking_id = mysqli_insert_id($conn);
            foreach ($p['passengers'] as $seat => $info) {
                q("INSERT INTO passengers (booking_id, seat_no, name, age) VALUES (?, ?, ?, ?)", 'iisi',
                  [$booking_id, $seat, $info['name'], $info['age']]);
            }

            // Confirmation email (works only if mail is configured in XAMPP)
            $u = one(q("SELECT email, name FROM users WHERE id = ?", 'i', [$_SESSION['user']['id']]));
            $body = "Hello {$u['name']},\n\nYour booking #$booking_id is confirmed.\n"
                  . "Bus: {$bus['bus_name']} ({$bus['from_city']} to {$bus['to_city']})\n"
                  . "Date: {$bus['travel_date']} Time: " . substr($bus['travel_time'], 0, 5) . "\n"
                  . "Seats: " . implode(', ', array_keys($p['passengers'])) . "\n"
                  . "Amount paid: Rs. $total\n\nThank you for booking with BusBook.";
            @mail($u['email'], "Booking Confirmation #$booking_id", $body, 'From: noreply@busbook.local');

            unset($_SESSION['pending']);
            header('Location: confirmation.php?id=' . $booking_id);
            exit;
        }
    }
}
include __DIR__ . '/header.php';
?>
<h2>Payment</h2>
<div class="card">
  <b><?= e($bus['bus_name']) ?></b> &mdash; <?= e($bus['from_city']) ?> &rarr; <?= e($bus['to_city']) ?><br>
  Seats: <?= e(implode(', ', array_keys($p['passengers']))) ?><br>
  <h3>Total: &#8377;<?= e($total) ?></h3>
</div>

<?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="card formbox">
  <h3>Card Details (demo gateway)</h3>
  Name on card<input name="card_name" required>
  Card number (16 digits)<input name="card_no" maxlength="19" placeholder="4111 1111 1111 1111" required>
  Expiry (MM/YY)<input name="expiry" maxlength="5" placeholder="12/29" required>
  CVV<input type="password" name="cvv" maxlength="3" required>
  <button type="submit">Pay &#8377;<?= e($total) ?></button>
  <a class="btn btn-gray" href="book.php?id=<?= (int)$bus['id'] ?>">Back</a>
</form>
<?php include __DIR__ . '/footer.php'; ?>

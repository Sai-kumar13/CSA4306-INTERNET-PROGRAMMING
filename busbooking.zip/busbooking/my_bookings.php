<?php
require __DIR__ . '/config.php';
require_login();

$list = rows(q("SELECT k.*, b.bus_name, b.from_city, b.to_city, b.travel_date, b.travel_time,
                (SELECT GROUP_CONCAT(seat_no ORDER BY seat_no) FROM passengers WHERE booking_id = k.id) AS seats
                FROM bookings k JOIN buses b ON b.id = k.bus_id
                WHERE k.user_id = ? ORDER BY k.id DESC", 'i', [$_SESSION['user']['id']]));

include __DIR__ . '/header.php';
?>
<h2>My Dashboard</h2>
<p>Welcome, <b><?= e($_SESSION['user']['name']) ?></b>. <a href="index.php">Book a new ticket</a></p>

<?php if (isset($_GET['cancelled'])): ?><div class="msg ok">Booking cancelled.</div><?php endif; ?>

<h3>Booking History</h3>
<div class="table-wrap">
<table>
  <tr><th>ID</th><th>Bus</th><th>Route</th><th>Date / Time</th><th>Seats</th><th>Amount</th><th>Status</th><th></th></tr>
  <?php if (!$list): ?><tr><td colspan="8">No bookings yet.</td></tr><?php endif; ?>
  <?php foreach ($list as $r): ?>
  <tr>
    <td>#<?= (int)$r['id'] ?></td>
    <td><?= e($r['bus_name']) ?></td>
    <td><?= e($r['from_city']) ?> &rarr; <?= e($r['to_city']) ?></td>
    <td><?= e($r['travel_date']) ?> <?= e(substr($r['travel_time'], 0, 5)) ?></td>
    <td><?= e($r['seats']) ?></td>
    <td>&#8377;<?= e($r['total_amount']) ?></td>
    <td><?= e($r['status']) ?></td>
    <td>
      <?php if ($r['status'] === 'Booked' && $r['travel_date'] >= date('Y-m-d')): ?>
        <form method="post" action="cancel.php" onsubmit="return confirm('Cancel this ticket?');">
          <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
          <button class="btn-red small" type="submit">Cancel</button>
        </form>
      <?php endif; ?>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/footer.php'; ?>

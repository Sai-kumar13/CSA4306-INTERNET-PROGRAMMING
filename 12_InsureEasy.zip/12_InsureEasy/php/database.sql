CREATE DATABASE IF NOT EXISTS insureeasy_db;
USE insureeasy_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80),
  mobile VARCHAR(15),
  email VARCHAR(80),
  username VARCHAR(40),
  password VARCHAR(255),
  role VARCHAR(20) DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS agents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80),
  mobile VARCHAR(15),
  status VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS customers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  agent_id INT,
  name VARCHAR(80),
  mobile VARCHAR(15)
);

CREATE TABLE IF NOT EXISTS policies (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT,
  type VARCHAR(30),
  premium INT,
  due_date DATE
);

INSERT INTO users (name, mobile, email, username, password, role) VALUES ('Admin', '9840012345', 'admin@example.in', 'admin', '$2y$10$abcdefghijklmnopqrstuv', 'admin');

<?php
include 'config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $conn) {
    $hash = password_hash($_POST['password'] ?? '', PASSWORD_DEFAULT);
    $stmt = $conn->prepare('INSERT INTO users (name, mobile, email, username, password) VALUES (?,?,?,?,?)');
    $stmt->bind_param('sssss', $_POST['name'], $_POST['mobile'], $_POST['email'], $_POST['username'], $hash);
    $stmt->execute();
    echo 'Registered';
}
?>
<!DOCTYPE html>
<html><head><title>InsureEasy Register</title></head>
<body>
<h2>Register</h2>
<form method="post">
  <input name="name" placeholder="Name">
  <input name="mobile" placeholder="Mobile">
  <input name="email" placeholder="Email">
  <input name="username" placeholder="Username">
  <input name="password" type="password" placeholder="Password">
  <button>Register</button>
</form>
</body></html>

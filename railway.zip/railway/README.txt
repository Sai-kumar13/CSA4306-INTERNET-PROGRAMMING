RAILBOOK - Online Train Reservation System (DEMO)  |  PHP + MySQL (XAMPP)

HOW TO RUN
1. Install XAMPP, start Apache and MySQL in the XAMPP Control Panel.
2. Copy the folder "railway" into  C:\xampp\htdocs\
3. Open  http://localhost/railway/setup.php   (creates DB "railway_demo" + sample data)
   (or import database.sql in http://localhost/phpmyadmin)
4. Open  http://localhost/railway/

DEMO MODE
- Login: just click "Login as Passenger" or "Login as Admin" - nothing to type.
- Payment: click "Pay (Demo)" - it always succeeds, nothing is charged.
- Emails are saved in the database (shown in Dashboard / Admin > Emails), not sent.

DEMO FLOW
Home -> search Chennai Egmore to Madurai -> Book -> (auto login) -> passengers + seats
-> Pay (Demo) -> ticket with PNR -> Dashboard (history, print, cancel) -> PNR Status page.
Admin: Admin Panel -> trains/seats/fares, users, bookings, payments, refund approval.
Tip: Nellai Express (MS -> TEN) class 1A has only 2 seats, already booked in sample data,
so a new booking there becomes RAC; cancel the sample PNR 2100000002 to see promotion.

DB settings: config.php (user root, empty password, DB railway_demo).

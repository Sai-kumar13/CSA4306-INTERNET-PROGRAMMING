<?php
require 'config.php'; header('Content-Type: application/json');
$tid=(int)($_GET['train']??0); $cls=$_GET['cls']??''; $date=$_GET['date']??'';
$av = availability($pdo,$tid,$cls,$date);
if (!$av) { echo json_encode(['error'=>true]); exit; }
echo json_encode(['taken'=>taken_seats($pdo,$tid,$cls,$date),'total'=>$av['total'],'avail'=>$av['avail'],'label'=>$av['label'],'tone'=>$av['tone'],'time'=>date('H:i:s')]);

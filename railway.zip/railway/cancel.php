<?php
require 'config.php'; require_login();
$pnr=$_GET['pnr']??$_POST['pnr']??'';
$s=$pdo->prepare('SELECT * FROM bookings WHERE pnr=?'); $s->execute([$pnr]); $b=$s->fetch();
if (!$b || (user()['role']!=='admin' && $b['user_id']!=user()['id'])) { flash('Booking not found.'); redirect('dashboard.php'); }
if ($b['status']==='CANCELLED') { flash('This ticket is already cancelled.'); redirect('dashboard.php'); }
$ri=refund_info($pdo,$b);
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $pdo->prepare("UPDATE bookings SET status='CANCELLED', cancelled_at=NOW(), refund_percent=?, refund_amount=?, refund_status=? WHERE id=?")
        ->execute([$ri['percent'],$ri['amount'],$ri['amount']>0?'PENDING':'NONE',$b['id']]);
    $pdo->prepare("UPDATE passengers SET status='CANCELLED', seat_no=NULL WHERE booking_id=?")->execute([$b['id']]);
    promote($pdo,$b['train_id'],$b['class_code'],$b['journey_date']);
    $pdo->prepare('INSERT INTO emails (user_id,to_email,subject,body) VALUES (?,?,?,?)')->execute([$b['user_id'],user()['email'],"Ticket cancelled - PNR {$b['pnr']}",
        "Your ticket {$b['pnr']} was cancelled.\nRefund: ".money($ri['amount'])." ({$ri['percent']}%). It will be released after admin approval."]);
    flash('Ticket cancelled. Refund of '.money($ri['amount']).' ('.$ri['percent'].'%) sent to admin for approval.');
    redirect('dashboard.php');
}
$rules=$pdo->query('SELECT * FROM refund_rules ORDER BY min_hours DESC')->fetchAll();
$title='Cancel Ticket'; include 'header.php';
?>
<div class="narrow wide"><div class="card">
<h2>Cancel ticket <?= e($b['pnr']) ?></h2>
<p>Fare paid: <b><?= money($b['fare_total']) ?></b> • Hours before departure: <b><?= max(0,round($ri['hours'],1)) ?></b></p>
<p class="between"><span>Applicable rule: <?= e($ri['label']) ?> (<b><?= $ri['percent'] ?>%</b>)</span><span class="big"><?= money($ri['amount']) ?> refund</span></p>
<table class="tbl"><tr><th>Refund rule</th><th>Refundable %</th></tr><?php foreach($rules as $r): ?><tr><td><?= e($r['label']) ?></td><td><?= $r['percent'] ?>%</td></tr><?php endforeach; ?></table>
<form method="post" onsubmit="return confirm('Cancel this ticket?')"><input type="hidden" name="pnr" value="<?= e($b['pnr']) ?>">
<button class="btn danger">Confirm cancellation</button> <a class="btn ghost" href="dashboard.php">Keep ticket</a></form>
</div></div>
<?php include 'footer.php'; ?>

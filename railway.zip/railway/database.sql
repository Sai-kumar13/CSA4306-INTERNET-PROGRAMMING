-- RailBook DEMO database (XAMPP / MySQL / MariaDB)
CREATE DATABASE IF NOT EXISTS railway_demo CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE railway_demo;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS emails, payments, passengers, bookings, train_classes, trains, stations, refund_rules, users;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  phone VARCHAR(20),
  password VARCHAR(255) NOT NULL,
  role ENUM('user','admin') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE stations (
  code VARCHAR(8) PRIMARY KEY,
  name VARCHAR(80) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE trains (
  id INT AUTO_INCREMENT PRIMARY KEY,
  number VARCHAR(10) NOT NULL,
  name VARCHAR(80) NOT NULL,
  zone VARCHAR(10) NOT NULL DEFAULT 'SR',
  route VARCHAR(255) NOT NULL,          -- comma separated station codes in order
  dep_time TIME NOT NULL,
  arr_time TIME NOT NULL,
  active TINYINT DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE train_classes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  train_id INT NOT NULL,
  class_code VARCHAR(3) NOT NULL,
  total_seats INT NOT NULL,
  fare DECIMAL(10,2) NOT NULL,
  UNIQUE KEY uq_train_class (train_id, class_code),
  FOREIGN KEY (train_id) REFERENCES trains(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pnr CHAR(10) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  train_id INT NOT NULL,
  class_code VARCHAR(3) NOT NULL,
  journey_date DATE NOT NULL,
  from_code VARCHAR(8) NOT NULL,
  to_code VARCHAR(8) NOT NULL,
  pax INT NOT NULL,
  fare_total DECIMAL(10,2) NOT NULL,
  status ENUM('CONFIRMED','RAC','WL','CANCELLED') NOT NULL,
  payment_mode VARCHAR(40),
  booked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  cancelled_at DATETIME NULL,
  refund_percent INT DEFAULT 0,
  refund_amount DECIMAL(10,2) DEFAULT 0,
  refund_status ENUM('NONE','PENDING','REFUNDED') DEFAULT 'NONE',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (train_id) REFERENCES trains(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE passengers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  name VARCHAR(80) NOT NULL,
  age INT NOT NULL,
  gender VARCHAR(10) NOT NULL,
  seat_no INT NULL,
  status VARCHAR(12) NOT NULL,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  type ENUM('PAYMENT','REFUND') DEFAULT 'PAYMENT',
  mode VARCHAR(40),
  txn_id VARCHAR(30),
  status VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE refund_rules (
  id INT AUTO_INCREMENT PRIMARY KEY,
  min_hours INT NOT NULL,
  percent INT NOT NULL,
  label VARCHAR(80) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE emails (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  to_email VARCHAR(120),
  subject VARCHAR(160),
  body TEXT,
  sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- SEED DATA ----------
-- (passwords are not used in demo mode: login is a single click)
INSERT INTO users (name,email,phone,password,role) VALUES
('Site Admin','admin@railbook.demo','9000000001','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin'),
('Demo Traveller','demo@railbook.demo','9000000002','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','user');

INSERT INTO stations (code,name) VALUES
('MS','Chennai Egmore'),('MAS','Chennai Central'),('VM','Villupuram Jn'),('TPJ','Tiruchirappalli Jn'),
('DG','Dindigul Jn'),('MDU','Madurai Jn'),('KOVL','Kovilpatti'),('TEN','Tirunelveli Jn'),
('CAPE','Kanniyakumari'),('KPD','Katpadi Jn'),('SA','Salem Jn'),('ED','Erode Jn'),
('CBE','Coimbatore Jn'),('SBC','KSR Bengaluru');

INSERT INTO trains (number,name,zone,route,dep_time,arr_time) VALUES
('12635','Vaigai Express','SR','MS,VM,TPJ,DG,MDU','06:40:00','14:30:00'),
('12637','Pandian Express','SR','MS,VM,TPJ,DG,MDU','21:40:00','05:35:00'),
('12631','Nellai Express','SR','MS,VM,TPJ,DG,MDU,KOVL,TEN','19:50:00','06:20:00'),
('12633','Kanyakumari Express','SR','MS,VM,TPJ,MDU,TEN,CAPE','17:20:00','05:10:00'),
('12243','Chennai - Coimbatore Shatabdi','SR','MAS,KPD,SA,ED,CBE','06:00:00','12:40:00'),
('12607','Lalbagh Express','SR','MAS,KPD,SBC','15:30:00','21:20:00'),
('12636','Vaigai Express (Return)','SR','MDU,DG,TPJ,VM,MS','13:50:00','21:35:00'),
('12638','Pandian Express (Return)','SR','MDU,DG,TPJ,VM,MS','21:15:00','05:00:00');

INSERT INTO train_classes (train_id,class_code,total_seats,fare)
SELECT t.id,c.code,c.seats,c.fare FROM trains t
CROSS JOIN (SELECT 'SL' code,72 seats,350 fare UNION ALL SELECT '3A',64,950 UNION ALL SELECT '2A',48,1350 UNION ALL SELECT '1A',24,2800) c;
DELETE FROM train_classes WHERE train_id=5 AND class_code='SL';
-- Nellai Express First AC only has 2 seats so you can demo RAC / waiting list quickly
UPDATE train_classes SET total_seats=2 WHERE train_id=3 AND class_code='1A';

INSERT INTO refund_rules (min_hours,percent,label) VALUES
(48,75,'48 hours or more before departure'),
(24,50,'24 to 48 hours before departure'),
(4,25,'4 to 24 hours before departure'),
(-100000,0,'Less than 4 hours / after departure');

-- sample bookings
INSERT INTO bookings (pnr,user_id,train_id,class_code,journey_date,from_code,to_code,pax,fare_total,status,payment_mode) VALUES
('2100000001',2,1,'3A',DATE_ADD(CURDATE(),INTERVAL 5 DAY),'MS','MDU',2,1900,'CONFIRMED','Online - UPI'),
('2100000002',2,3,'1A',DATE_ADD(CURDATE(),INTERVAL 5 DAY),'MS','TEN',2,5600,'CONFIRMED','Online - Card');
INSERT INTO passengers (booking_id,name,age,gender,seat_no,status) VALUES
(1,'Demo Traveller',30,'Male',1,'CONFIRMED'),(1,'Guest Rider',28,'Female',2,'CONFIRMED'),
(2,'Demo Traveller',30,'Male',1,'CONFIRMED'),(2,'Guest Rider',28,'Female',2,'CONFIRMED');
INSERT INTO payments (booking_id,amount,type,mode,txn_id,status) VALUES
(1,1900,'PAYMENT','Online - UPI','TXNDEMO0001','SUCCESS'),(2,5600,'PAYMENT','Online - Card','TXNDEMO0002','SUCCESS');

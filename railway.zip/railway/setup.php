<?php
// One-click database installer: open http://localhost/railway/setup.php
$msg=''; $ok=false;
try {
    $pdo = new PDO('mysql:host=localhost;charset=utf8mb4','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    $pdo->exec(file_get_contents(__DIR__.'/database.sql'));
    $ok=true; $msg='Database "railway_demo" created and sample data loaded.';
} catch (Exception $e) { $msg='Setup failed: '.$e->getMessage().' — make sure MySQL is running in XAMPP, or import database.sql in phpMyAdmin.'; }
?><!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Setup</title><link rel="stylesheet" href="assets/style.css"></head>
<body><div class="wrap narrow"><div class="card center"><h1><?= $ok?'✅ Setup complete':'⚠️ Setup problem' ?></h1><p><?= htmlspecialchars($msg) ?></p>
<?php if($ok): ?><a class="btn" href="index.php">Open RailBook →</a><?php endif; ?></div></div></body></html>

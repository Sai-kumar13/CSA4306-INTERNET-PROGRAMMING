<?php require_once __DIR__.'/config.php'; $u = user(); $fl = flash(); ?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title ?? 'Train Reservation') ?> • RailBook</title>
<link rel="stylesheet" href="assets/style.css"></head><body>
<div class="demo-bar">🎭 DEMO MODE — login &amp; payment are simulated. Just click through, nothing real is charged.</div>
<header class="nav">
  <a class="brand" href="index.php">🚆 RailBook</a>
  <button class="burger" onclick="document.getElementById('menu').classList.toggle('open')" aria-label="menu">☰</button>
  <nav id="menu" class="menu">
    <a href="index.php">Home</a>
    <a href="search.php">Book Ticket</a>
    <a href="pnr.php">PNR Status</a>
    <?php if ($u): ?>
      <a href="dashboard.php">My Dashboard</a>
      <?php if ($u['role']==='admin'): ?><a href="admin.php">Admin Panel</a><?php endif; ?>
      <a href="logout.php" class="btn small ghost">Logout (<?= e(explode(' ',$u['name'])[0]) ?>)</a>
    <?php else: ?>
      <a href="register.php">Register</a>
      <a href="login.php" class="btn small">Login</a>
    <?php endif; ?>
  </nav>
</header>
<main class="wrap">
<?php if ($fl): ?><div class="alert"><?= e($fl) ?></div><?php endif; ?>

<?php
if (session_status() === PHP_SESSION_NONE) session_start();
date_default_timezone_set('Asia/Kolkata');

const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = '';          // XAMPP default is empty
const DB_NAME = 'railway_demo';
const RAC_MAX = 6;           // RAC seats per train/class/date
const WL_MAX  = 20;          // waiting list limit
const CLASSES = ['SL'=>'Sleeper','3A'=>'AC 3 Tier','2A'=>'AC 2 Tier','1A'=>'First AC'];

try {
    $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die('<div style="font-family:sans-serif;max-width:560px;margin:60px auto;padding:24px;border:1px solid #ddd;border-radius:12px">
    <h2>Database not ready</h2><p>Start <b>Apache</b> and <b>MySQL</b> in XAMPP, then run the
    <a href="setup.php">one-click setup</a> (or import <code>database.sql</code> in phpMyAdmin).</p></div>');
}

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function money($n) { return '₹'.number_format((float)$n, 0); }
function flash($m = null) {
    if ($m !== null) { $_SESSION['flash'] = $m; return; }
    $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f;
}
function redirect($url) { header('Location: '.$url); exit; }

function user() {
    global $pdo; static $u = null;
    if (!isset($_SESSION['uid'])) return null;
    if ($u === null) {
        $s = $pdo->prepare('SELECT * FROM users WHERE id=?'); $s->execute([$_SESSION['uid']]);
        $u = $s->fetch() ?: null;
    }
    return $u;
}
function require_login() {
    if (!user()) redirect('login.php?next='.urlencode(basename($_SERVER['REQUEST_URI'])));
}
function require_admin() {
    require_login();
    if (user()['role'] !== 'admin') { flash('Admin area: use "Login as Admin".'); redirect('dashboard.php'); }
}

function stations() { global $pdo; return $pdo->query('SELECT * FROM stations ORDER BY name')->fetchAll(); }
function station_map() { $m=[]; foreach (stations() as $s) $m[$s['code']]=$s['name']; return $m; }

// Date-wise fare: weekends cost 10% more
function unit_fare($base, $date) { return round($base * (date('N', strtotime($date)) >= 6 ? 1.10 : 1.0)); }

function availability($pdo, $tid, $cls, $date) {
    $s = $pdo->prepare('SELECT total_seats,fare FROM train_classes WHERE train_id=? AND class_code=?');
    $s->execute([$tid, $cls]); $tc = $s->fetch();
    if (!$tc) return null;
    $s = $pdo->prepare("SELECT status, COALESCE(SUM(pax),0) c FROM bookings
        WHERE train_id=? AND class_code=? AND journey_date=? AND status IN ('CONFIRMED','RAC','WL') GROUP BY status");
    $s->execute([$tid, $cls, $date]);
    $c = ['CONFIRMED'=>0,'RAC'=>0,'WL'=>0];
    foreach ($s->fetchAll() as $r) $c[$r['status']] = (int)$r['c'];
    $avail = max(0, (int)$tc['total_seats'] - $c['CONFIRMED']);
    $racLeft = max(0, RAC_MAX - $c['RAC']);
    if ($avail > 0)               { $label = 'AVAILABLE '.$avail; $tone = 'ok'; }
    elseif ($racLeft > 0)         { $label = 'RAC '.($c['RAC']+1); $tone = 'warn'; }
    elseif ($c['WL'] < WL_MAX)    { $label = 'WL '.($c['WL']+1);  $tone = 'bad'; }
    else                          { $label = 'REGRET';            $tone = 'bad'; }
    return ['total'=>(int)$tc['total_seats'],'fare'=>(float)$tc['fare'],'avail'=>$avail,'rac'=>$c['RAC'],
            'rac_left'=>$racLeft,'wl'=>$c['WL'],'label'=>$label,'tone'=>$tone];
}
function taken_seats($pdo, $tid, $cls, $date) {
    $s = $pdo->prepare("SELECT p.seat_no FROM passengers p JOIN bookings b ON b.id=p.booking_id
        WHERE b.train_id=? AND b.class_code=? AND b.journey_date=? AND b.status='CONFIRMED' AND p.seat_no IS NOT NULL");
    $s->execute([$tid, $cls, $date]);
    return array_map('intval', $s->fetchAll(PDO::FETCH_COLUMN));
}
function assign_seats($pdo, $tid, $cls, $date, $total, $n, $prefer = []) {
    $taken = taken_seats($pdo, $tid, $cls, $date); $out = [];
    foreach ($prefer as $p) {
        $p = (int)$p;
        if ($p>=1 && $p<=$total && !in_array($p,$taken) && !in_array($p,$out) && count($out)<$n) $out[] = $p;
    }
    for ($i=1; $i<=$total && count($out)<$n; $i++) if (!in_array($i,$taken) && !in_array($i,$out)) $out[] = $i;
    return $out;
}
// After a cancellation, move RAC / waiting-list tickets up if seats are free
function promote($pdo, $tid, $cls, $date) {
    foreach (['RAC','WL'] as $st) {
        $q = $pdo->prepare('SELECT * FROM bookings WHERE train_id=? AND class_code=? AND journey_date=? AND status=? ORDER BY id');
        $q->execute([$tid,$cls,$date,$st]);
        foreach ($q->fetchAll() as $b) {
            $av = availability($pdo,$tid,$cls,$date);
            if ($av['avail'] >= $b['pax']) {
                $seats = assign_seats($pdo,$tid,$cls,$date,$av['total'],(int)$b['pax']);
                $ps = $pdo->prepare('SELECT id FROM passengers WHERE booking_id=? ORDER BY id'); $ps->execute([$b['id']]);
                foreach ($ps->fetchAll() as $i=>$p)
                    $pdo->prepare("UPDATE passengers SET seat_no=?, status='CONFIRMED' WHERE id=?")->execute([$seats[$i]??null,$p['id']]);
                $pdo->prepare("UPDATE bookings SET status='CONFIRMED' WHERE id=?")->execute([$b['id']]);
            }
        }
    }
}
function gen_pnr($pdo) {
    do {
        $pnr = (string)random_int(2000000000, 2999999999);
        $s = $pdo->prepare('SELECT 1 FROM bookings WHERE pnr=?'); $s->execute([$pnr]);
    } while ($s->fetch());
    return $pnr;
}
function refund_info($pdo, $booking) {
    $s = $pdo->prepare('SELECT dep_time FROM trains WHERE id=?'); $s->execute([$booking['train_id']]);
    $dep = strtotime($booking['journey_date'].' '.$s->fetchColumn());
    $hours = ($dep - time()) / 3600;
    $r = $pdo->prepare('SELECT * FROM refund_rules WHERE min_hours<=? ORDER BY min_hours DESC LIMIT 1');
    $r->execute([(int)floor($hours)]); $rule = $r->fetch();
    $pct = $rule ? (int)$rule['percent'] : 0;
    return ['hours'=>$hours,'percent'=>$pct,'amount'=>round($booking['fare_total']*$pct/100),'label'=>$rule['label']??''];
}
function status_badge($st) {
    $t = ['CONFIRMED'=>'ok','RAC'=>'warn','WL'=>'bad','CANCELLED'=>'grey'][$st] ?? 'grey';
    return '<span class="badge '.$t.'">'.e($st).'</span>';
}

<?php
require 'config.php';
$pnr=trim($_GET['pnr']??''); $b=null; $pax=[];
if ($pnr!=='') {
    $s=$pdo->prepare('SELECT b.*,t.name tname,t.number tnum FROM bookings b JOIN trains t ON t.id=b.train_id WHERE b.pnr=?'); $s->execute([$pnr]); $b=$s->fetch();
    if ($b) { $p=$pdo->prepare('SELECT * FROM passengers WHERE booking_id=? ORDER BY id'); $p->execute([$b['id']]); $pax=$p->fetchAll(); }
}
$names=station_map(); $title='PNR Status'; include 'header.php';
?>
<div class="narrow wide">
<div class="card"><h2>Check PNR Status</h2>
<form method="get" class="inline"><input name="pnr" placeholder="Enter 10-digit PNR" value="<?= e($pnr) ?>" maxlength="10"><button class="btn">Check</button></form>
<p class="muted tiny">Try: 2100000001 or 2100000002</p></div>
<?php if ($pnr!=='' && !$b): ?><div class="alert bad">No booking found for PNR <?= e($pnr) ?>.</div><?php endif; ?>
<?php if ($b): ?>
<div class="card"><h3><?= e($b['tname']) ?> #<?= e($b['tnum']) ?> <?= status_badge($b['status']) ?></h3>
<p><?= e($names[$b['from_code']]) ?> → <?= e($names[$b['to_code']]) ?> • <?= date('D, d M Y',strtotime($b['journey_date'])) ?> • Class <?= e($b['class_code']) ?></p>
<table class="tbl"><tr><th>#</th><th>Passenger</th><th>Seat</th><th>Status</th></tr>
<?php foreach ($pax as $i=>$x): ?><tr><td><?= $i+1 ?></td><td><?= e($x['name']) ?></td><td><?= $x['seat_no']?e($b['class_code'].'-'.$x['seat_no']):'—' ?></td><td><?= e($x['status']) ?></td></tr><?php endforeach; ?></table>
<?php if ($b['refund_status']!=='NONE'): ?><p>Refund: <b><?= money($b['refund_amount']) ?></b> (<?= $b['refund_percent'] ?>%) — <?= $b['refund_status']==='REFUNDED'?'Paid back to passenger':'Waiting for admin approval' ?></p><?php endif; ?>
<?php if (user() && $b['status']!=='CANCELLED' && (user()['id']==$b['user_id'] || user()['role']==='admin')): ?><a class="btn ghost" href="cancel.php?pnr=<?= e($b['pnr']) ?>">Cancel this ticket</a><?php endif; ?></div>
<?php endif; ?>
</div>
<?php include 'footer.php'; ?>

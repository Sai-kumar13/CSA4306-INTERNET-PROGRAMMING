<?php
require 'config.php';
$from=$_GET['from']??''; $to=$_GET['to']??''; $date=$_GET['date']??date('Y-m-d');
$clsF=$_GET['cls']??''; $tm=$_GET['time']??'';
$err=''; $results=[]; $names=station_map();
if (!$from || !$to) $err='Please choose origin and destination.';
elseif ($from===$to) $err='Origin and destination must be different.';
elseif (strtotime($date) < strtotime(date('Y-m-d'))) $err='Please choose today or a future date.';
else {
    foreach ($pdo->query('SELECT * FROM trains WHERE active=1 ORDER BY dep_time')->fetchAll() as $t) {
        $r = explode(',', $t['route']);
        $i = array_search($from,$r); $j = array_search($to,$r);
        if ($i===false || $j===false || $i>=$j) continue;
        $h = (int)substr($t['dep_time'],0,2);
        if ($tm==='morning'   && !($h>=5 && $h<12))  continue;
        if ($tm==='afternoon' && !($h>=12 && $h<17)) continue;
        if ($tm==='evening'   && !($h>=17 && $h<21)) continue;
        if ($tm==='night'     && !($h>=21 || $h<5))  continue;
        $t['via'] = array_slice($r,$i+1,$j-$i-1); $t['classes']=[];
        $cs = $pdo->prepare("SELECT class_code FROM train_classes WHERE train_id=? ORDER BY FIELD(class_code,'SL','3A','2A','1A')");
        $cs->execute([$t['id']]);
        foreach ($cs->fetchAll(PDO::FETCH_COLUMN) as $c) {
            if ($clsF && $clsF!==$c) continue;
            $t['classes'][$c] = availability($pdo,$t['id'],$c,$date);
        }
        if ($t['classes']) $results[]=$t;
    }
}
$title='Train Search'; include 'header.php';
?>
<div class="card"><?php include 'search_form.php'; ?></div>
<?php if ($err): ?><div class="alert bad"><?= e($err) ?></div>
<?php else: ?>
<h2><?= e($names[$from]??$from) ?> → <?= e($names[$to]??$to) ?> <small class="muted">• <?= date('D, d M Y', strtotime($date)) ?> • <?= count($results) ?> train(s)</small></h2>
<?php if (!$results): ?><div class="card center"><p>No trains found for this route. Try <b>Chennai Egmore → Madurai</b> or <b>Chennai Egmore → Tirunelveli</b>.</p></div><?php endif; ?>
<?php foreach ($results as $t): ?>
<div class="card train">
  <div class="train-head">
    <div><h3><?= e($t['name']) ?> <span class="muted">#<?= e($t['number']) ?></span></h3>
      <div class="muted">Zone <?= e($t['zone']) ?> • Via: <?= $t['via'] ? e(implode(', ', array_map(fn($c)=>$names[$c]??$c, $t['via']))) : 'Non-stop' ?></div></div>
    <div class="times"><b><?= substr($t['dep_time'],0,5) ?></b> <span>→</span> <b><?= substr($t['arr_time'],0,5) ?></b></div>
  </div>
  <div class="classes">
    <?php foreach ($t['classes'] as $c=>$av): ?>
    <div class="cls">
      <div class="cls-name"><?= $c ?> <small><?= CLASSES[$c] ?></small></div>
      <div class="price"><?= money(unit_fare($av['fare'],$date)) ?></div>
      <div class="badge <?= $av['tone'] ?>"><?= e($av['label']) ?></div>
      <a class="btn small" href="book.php?train=<?= $t['id'] ?>&cls=<?= $c ?>&date=<?= e($date) ?>&from=<?= e($from) ?>&to=<?= e($to) ?>">Book</a>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endforeach; endif; ?>
<?php include 'footer.php'; ?>

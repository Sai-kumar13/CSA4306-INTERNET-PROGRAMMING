<?php
require 'config.php'; require_login(); $u=user(); $names=station_map();
$q=$pdo->prepare('SELECT b.*,t.name tname,t.number tnum FROM bookings b JOIN trains t ON t.id=b.train_id WHERE b.user_id=? ORDER BY b.id DESC');
$q->execute([$u['id']]); $list=$q->fetchAll();
$em=$pdo->prepare('SELECT * FROM emails WHERE user_id=? ORDER BY id DESC LIMIT 5'); $em->execute([$u['id']]); $mails=$em->fetchAll();
$title='My Dashboard'; include 'header.php';
?>
<h1>Hello, <?= e($u['name']) ?> 👋</h1>
<div class="grid3">
  <div class="card stat"><b><?= count($list) ?></b><span>Total bookings</span></div>
  <div class="card stat"><b><?= count(array_filter($list,fn($b)=>$b['status']==='CONFIRMED')) ?></b><span>Confirmed</span></div>
  <div class="card stat"><b><?= money(array_sum(array_map(fn($b)=>$b['status']==='CANCELLED'?0:$b['fare_total'],$list))) ?></b><span>Total spent</span></div>
</div>
<p><a class="btn" href="search.php">+ Book a new ticket</a> <a class="btn ghost" href="pnr.php">Check PNR status</a></p>
<div class="card"><h3>Booking history</h3>
<?php if(!$list): ?><p class="muted">No bookings yet.</p><?php else: ?>
<div class="scroll"><table class="tbl"><tr><th>PNR</th><th>Train</th><th>Route</th><th>Date</th><th>Class</th><th>Pax</th><th>Fare</th><th>Status</th><th>Refund</th><th></th></tr>
<?php foreach($list as $b): ?><tr>
 <td><b><?= e($b['pnr']) ?></b></td><td><?= e($b['tname']) ?><br><small class="muted">#<?= e($b['tnum']) ?></small></td>
 <td><?= e($b['from_code']) ?> → <?= e($b['to_code']) ?></td><td><?= date('d M Y',strtotime($b['journey_date'])) ?></td>
 <td><?= e($b['class_code']) ?></td><td><?= $b['pax'] ?></td><td><?= money($b['fare_total']) ?></td><td><?= status_badge($b['status']) ?></td>
 <td><?php if($b['refund_status']==='PENDING') echo '<span class="badge warn">'.money($b['refund_amount']).' pending</span>'; elseif($b['refund_status']==='REFUNDED') echo '<span class="badge ok">'.money($b['refund_amount']).' refunded</span>'; else echo '—'; ?></td>
 <td class="nowrap"><a class="btn small" href="ticket.php?pnr=<?= e($b['pnr']) ?>">View / Print</a>
  <?php if($b['status']!=='CANCELLED'): ?><a class="btn small ghost" href="cancel.php?pnr=<?= e($b['pnr']) ?>">Cancel</a><?php endif; ?></td></tr>
<?php endforeach; ?></table></div><?php endif; ?></div>
<div class="card"><h3>📧 Confirmation emails (demo inbox)</h3>
<?php if(!$mails): ?><p class="muted">No emails yet. Emails are simulated and stored here instead of being sent.</p><?php endif; ?>
<?php foreach($mails as $m): ?><details><summary><b><?= e($m['subject']) ?></b> <small class="muted"><?= e($m['sent_at']) ?></small></summary><pre><?= e($m['body']) ?></pre></details><?php endforeach; ?></div>
<?php include 'footer.php'; ?>

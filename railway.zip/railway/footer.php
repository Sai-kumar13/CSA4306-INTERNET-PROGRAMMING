</main>
<footer class="foot">RailBook — Online Train Reservation System (college demo project) • PHP + MySQL on XAMPP</footer>
</body></html>

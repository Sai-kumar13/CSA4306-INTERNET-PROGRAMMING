<?php require 'config.php'; $title='Home'; include 'header.php'; ?>
<section class="hero">
  <h1>Book train tickets in a few clicks</h1>
  <p>Search trains, check live seat availability, pick seats, pay and print your ticket.</p>
  <?php include 'search_form.php'; ?>
</section>
<section class="grid3">
  <div class="card"><h3>⚡ Live seat availability</h3><p>Seat map refreshes automatically while you book. Full trains roll into RAC and waiting list.</p></div>
  <div class="card"><h3>🎫 PNR &amp; tickets</h3><p>Every booking gets a PNR. Check status anytime and print your ticket from the dashboard.</p></div>
  <div class="card"><h3>↩️ Easy cancellation</h3><p>Cancel with your PNR. Refund follows the refund rules and is released by the admin.</p></div>
</section>
<section class="card">
  <h3>Try the demo quickly</h3>
  <p>Sample PNRs: <a href="pnr.php?pnr=2100000001">2100000001</a> (Confirmed) • <a href="pnr.php?pnr=2100000002">2100000002</a> (Confirmed, First AC full → next booking becomes RAC).</p>
  <p>
    <?php if(!$u): ?>
    <a class="btn" href="login.php">Go to Login (one click)</a>
    <?php else: ?><a class="btn" href="dashboard.php">Open dashboard</a><?php endif; ?>
  </p>
</section>
<?php include 'footer.php'; ?>

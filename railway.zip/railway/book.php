<?php
require 'config.php'; require_login();
$tid=(int)($_GET['train']??$_POST['train']??0); $cls=$_GET['cls']??$_POST['cls']??'';
$date=$_GET['date']??$_POST['date']??''; $from=$_GET['from']??$_POST['from']??''; $to=$_GET['to']??$_POST['to']??'';
$s=$pdo->prepare('SELECT * FROM trains WHERE id=? AND active=1'); $s->execute([$tid]); $tr=$s->fetch();
$av=$tr?availability($pdo,$tid,$cls,$date):null;
$names=station_map();
if (!$tr || !$av || strtotime($date)<strtotime(date('Y-m-d')) || !isset($names[$from],$names[$to])) { flash('Please search for a train first.'); redirect('search.php'); }
$unit = unit_fare($av['fare'],$date);
$err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $pn=$_POST['pname']??[]; $pa=$_POST['page']??[]; $pg=$_POST['pgender']??[]; $pax=[];
    foreach ($pn as $i=>$n) {
        $n=trim($n); if ($n==='') continue;
        $pax[] = ['name'=>mb_substr($n,0,80),'age'=>max(1,min(120,(int)($pa[$i]??30))),'gender'=>in_array($pg[$i]??'',['Male','Female','Other'])?$pg[$i]:'Male'];
    }
    if (!$pax) $err='Add at least one passenger.';
    elseif (count($pax)>6) $err='Maximum 6 passengers per booking.';
    else {
        $seats = array_filter(array_map('intval', explode(',', $_POST['seats']??'')));
        $_SESSION['pending']=['train'=>$tid,'cls'=>$cls,'date'=>$date,'from'=>$from,'to'=>$to,'pax'=>$pax,'seats'=>array_values($seats),
            'unit'=>$unit,'total'=>$unit*count($pax)];
        redirect('payment.php');
    }
}
$title='Passenger Details'; include 'header.php';
$u=user();
?>
<div class="two">
<div>
  <div class="card">
    <h2><?= e($tr['name']) ?> <span class="muted">#<?= e($tr['number']) ?></span></h2>
    <p><b><?= e($names[$from]) ?></b> → <b><?= e($names[$to]) ?></b> • <?= date('D, d M Y',strtotime($date)) ?> • Dep <?= substr($tr['dep_time'],0,5) ?> • <?= $cls ?> (<?= CLASSES[$cls] ?>) •
       <span id="statusBadge" class="badge <?= $av['tone'] ?>"><?= e($av['label']) ?></span></p>
    <p class="muted tiny">Live availability — last updated <span id="upd"><?= date('H:i:s') ?></span> (auto-refresh every 5 s)</p>
  </div>
  <?php if ($err): ?><div class="alert bad"><?= e($err) ?></div><?php endif; ?>
  <form method="post" id="bookForm">
    <input type="hidden" name="train" value="<?= $tid ?>"><input type="hidden" name="cls" value="<?= e($cls) ?>">
    <input type="hidden" name="date" value="<?= e($date) ?>"><input type="hidden" name="from" value="<?= e($from) ?>"><input type="hidden" name="to" value="<?= e($to) ?>">
    <input type="hidden" name="seats" id="seatsInput">
    <div class="card">
      <h3>Passenger details</h3>
      <div id="paxRows">
        <div class="paxrow">
          <input name="pname[]" placeholder="Full name" value="<?= e($u['name']) ?>" required>
          <input name="page[]" type="number" min="1" max="120" value="30" required>
          <select name="pgender[]"><option>Male</option><option>Female</option><option>Other</option></select>
          <button type="button" class="x" onclick="removeRow(this)">✕</button>
        </div>
      </div>
      <button type="button" class="btn small ghost" onclick="addRow()">+ Add passenger</button>
    </div>
    <div class="card" id="seatCard">
      <h3>Choose seats <small class="muted">(optional)</small></h3>
      <div id="seatNote" class="muted"></div>
      <div id="seatGrid" class="seatgrid"></div>
      <div class="legend"><span class="s free"></span>Free <span class="s sel"></span>Selected <span class="s tk"></span>Booked</div>
    </div>
    <div class="card between">
      <div><div class="muted">Total fare (<span id="paxCount">1</span> × <?= money($unit) ?>)</div><div class="big" id="totalFare"><?= money($unit) ?></div></div>
      <button class="btn">Continue to Payment →</button>
    </div>
  </form>
</div>
</div>
<script>
const P={train:<?= $tid ?>,cls:"<?= e($cls) ?>",date:"<?= e($date) ?>",unit:<?= $unit ?>,total:<?= $av['total'] ?>};
let taken=<?= json_encode(taken_seats($pdo,$tid,$cls,$date)) ?>, selected=[], avail=<?= $av['avail'] ?>;
const rows=()=>document.querySelectorAll('.paxrow').length;
function addRow(){ if(rows()>=6){alert('Maximum 6 passengers');return;}
  const d=document.createElement('div'); d.className='paxrow';
  d.innerHTML='<input name="pname[]" placeholder="Full name" required><input name="page[]" type="number" min="1" max="120" value="25" required><select name="pgender[]"><option>Male</option><option>Female</option><option>Other</option></select><button type="button" class="x" onclick="removeRow(this)">✕</button>';
  document.getElementById('paxRows').appendChild(d); refresh(); }
function removeRow(b){ if(rows()<=1){alert('At least one passenger is required');return;} b.parentElement.remove(); refresh(); }
function refresh(){ const n=rows(); if(selected.length>n) selected=selected.slice(0,n);
  document.getElementById('paxCount').textContent=n;
  document.getElementById('totalFare').textContent='₹'+(n*P.unit).toLocaleString('en-IN');
  render(); }
function render(){
  const g=document.getElementById('seatGrid'), note=document.getElementById('seatNote');
  if(avail<=0){ g.innerHTML=''; note.textContent='All berths are booked. You can still book — your ticket will go to RAC / Waiting List.'; document.getElementById('seatsInput').value=''; return; }
  note.textContent='Tap seats to choose up to '+rows()+' seat(s). Unselected seats are auto-assigned.';
  g.innerHTML='';
  for(let i=1;i<=P.total;i++){ const b=document.createElement('button'); b.type='button'; b.textContent=i;
    b.className='seat '+(taken.includes(i)?'tk':(selected.includes(i)?'sel':'free')); b.disabled=taken.includes(i);
    b.onclick=()=>{ if(selected.includes(i)) selected=selected.filter(x=>x!==i); else { if(selected.length>=rows()) selected.shift(); selected.push(i);} render(); };
    g.appendChild(b); if(i%4===0&&i<P.total){} }
  document.getElementById('seatsInput').value=selected.join(',');
}
async function poll(){ try{ const r=await fetch('seats.php?train='+P.train+'&cls='+P.cls+'&date='+P.date); const j=await r.json(); if(j.error)return;
  taken=j.taken; avail=j.avail; selected=selected.filter(x=>!taken.includes(x));
  const b=document.getElementById('statusBadge'); b.textContent=j.label; b.className='badge '+j.tone;
  document.getElementById('upd').textContent=j.time; render(); }catch(e){} }
render(); setInterval(poll,5000);
</script>
<?php include 'footer.php'; ?>

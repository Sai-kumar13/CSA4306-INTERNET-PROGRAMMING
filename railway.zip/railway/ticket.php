<?php
require 'config.php'; require_login();
$pnr=$_GET['pnr']??'';
$s=$pdo->prepare('SELECT b.*,t.name tname,t.number tnum,t.dep_time,t.arr_time,t.zone FROM bookings b JOIN trains t ON t.id=b.train_id WHERE b.pnr=?');
$s->execute([$pnr]); $b=$s->fetch();
if (!$b || (user()['role']!=='admin' && $b['user_id']!=user()['id'])) { flash('Ticket not found.'); redirect('dashboard.php'); }
$ps=$pdo->prepare('SELECT * FROM passengers WHERE booking_id=? ORDER BY id'); $ps->execute([$b['id']]); $pax=$ps->fetchAll();
$pm=$pdo->prepare('SELECT * FROM payments WHERE booking_id=? AND type="PAYMENT" LIMIT 1'); $pm->execute([$b['id']]); $pay=$pm->fetch();
$names=station_map(); $title='E-Ticket '.$pnr; include 'header.php';
?>
<div class="noprint between"><a href="dashboard.php">← Dashboard</a><button class="btn" onclick="window.print()">🖨 Print Ticket</button></div>
<div class="ticket">
  <div class="t-head"><div>🚆 RailBook E-Ticket</div><div>PNR <b><?= e($b['pnr']) ?></b></div></div>
  <div class="t-body">
    <h2><?= e($b['tname']) ?> <small>#<?= e($b['tnum']) ?></small></h2>
    <div class="route"><div><b><?= e($names[$b['from_code']]) ?></b><br><small>Dep <?= substr($b['dep_time'],0,5) ?></small></div><div class="arrow">━━━▶</div><div><b><?= e($names[$b['to_code']]) ?></b><br><small>Arr <?= substr($b['arr_time'],0,5) ?></small></div></div>
    <p>Journey date: <b><?= date('D, d M Y',strtotime($b['journey_date'])) ?></b> • Class: <b><?= e($b['class_code']) ?></b> (<?= CLASSES[$b['class_code']]??'' ?>) • Zone <?= e($b['zone']) ?></p>
    <p>Booking status: <?= status_badge($b['status']) ?></p>
    <table class="tbl"><tr><th>#</th><th>Passenger</th><th>Age</th><th>Gender</th><th>Seat</th><th>Status</th></tr>
    <?php foreach ($pax as $i=>$x): ?><tr><td><?= $i+1 ?></td><td><?= e($x['name']) ?></td><td><?= $x['age'] ?></td><td><?= e($x['gender']) ?></td>
      <td><?= $x['seat_no'] ? e($b['class_code'].'-'.$x['seat_no']) : '—' ?></td><td><?= e($x['status']) ?></td></tr><?php endforeach; ?></table>
    <p class="between"><span>Total fare: <b><?= money($b['fare_total']) ?></b> • <?= e($b['payment_mode']) ?><?= $pay?' • Txn '.e($pay['txn_id']):'' ?></span>
       <span class="muted tiny">Booked <?= date('d M Y H:i',strtotime($b['booked_at'])) ?></span></p>
    <div class="barcode"><?= str_repeat('▌▎▍▏▌▋▎', 8) ?></div>
  </div>
</div>
<?php if ($b['status']!=='CANCELLED'): ?><p class="noprint center"><a class="btn ghost" href="cancel.php?pnr=<?= e($b['pnr']) ?>">Cancel this ticket</a></p><?php endif; ?>
<?php include 'footer.php'; ?>

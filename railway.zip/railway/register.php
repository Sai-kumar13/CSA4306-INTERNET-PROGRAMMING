<?php
require 'config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name']  ?? '') ?: 'New Traveller';
    $email = trim($_POST['email'] ?? '') ?: 'traveller'.random_int(100,999).'@railbook.demo';
    $phone = trim($_POST['phone'] ?? '') ?: '9000000000';
    $s = $pdo->prepare('SELECT 1 FROM users WHERE email=?'); $s->execute([$email]);
    if ($s->fetch()) $email = random_int(100,999).'.'.$email;
    $pdo->prepare("INSERT INTO users (name,email,phone,password,role) VALUES (?,?,?,?, 'user')")
        ->execute([$name,$email,$phone,password_hash('demo',PASSWORD_DEFAULT)]);
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$pdo->lastInsertId();
    flash('Registration successful! You are now logged in (demo).');
    redirect('dashboard.php');
}
$title='Register'; include 'header.php';
?>
<div class="narrow"><div class="card center">
  <h1>Create account</h1>
  <p class="muted">Demo mode: fields are pre-filled — just press Register.</p>
  <form method="post">
    <label>Full name<input name="name" value="Demo Traveller"></label>
    <label>Email<input name="email" type="email" value="newuser<?= random_int(10,99) ?>@railbook.demo"></label>
    <label>Phone<input name="phone" value="9876543210"></label>
    <button class="btn block">✅ Register &amp; Login</button>
  </form>
</div></div>
<?php include 'footer.php'; ?>

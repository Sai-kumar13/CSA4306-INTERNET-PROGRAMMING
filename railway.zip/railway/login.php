<?php
require 'config.php';
$next = $_GET['next'] ?? $_POST['next'] ?? '';
if (!preg_match('/^[A-Za-z0-9_\-\.\?=&%]+$/', $next) || strpos($next,'..') !== false) $next = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // DEMO: no credentials are checked. The button simply logs in as the demo account.
    $role  = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
    $email = $role === 'admin' ? 'admin@railbook.demo' : 'demo@railbook.demo';
    $s = $pdo->prepare('SELECT id FROM users WHERE email=?'); $s->execute([$email]); $id = $s->fetchColumn();
    if ($id) {
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$id;
        flash('Logged in successfully as '.($role==='admin'?'Administrator':'Passenger').' (demo).');
        redirect($next ?: ($role === 'admin' ? 'admin.php' : 'dashboard.php'));
    }
    flash('Demo users missing - run setup.php again.');
}
$title = 'Login'; include 'header.php';
?>
<div class="narrow">
  <div class="card center">
    <h1>Welcome back 👋</h1>
    <p class="muted">Demo mode: no username or password needed. Just click a button.</p>
    <form method="post">
      <input type="hidden" name="next" value="<?= e($next) ?>">
      <label>Email<input type="email" value="demo@railbook.demo" readonly></label>
      <label>Password<input type="password" value="••••••••" readonly></label>
      <button class="btn block" name="role" value="user">🔐 Login as Passenger</button>
      <button class="btn block ghost" name="role" value="admin" style="margin-top:10px">🛠 Login as Admin</button>
    </form>
    <p class="muted">New here? <a href="register.php">Register (also one click)</a></p>
  </div>
</div>
<?php include 'footer.php'; ?>

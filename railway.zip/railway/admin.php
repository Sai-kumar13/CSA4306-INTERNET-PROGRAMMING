<?php
require 'config.php'; require_admin();
$tab=$_GET['tab']??'overview';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $a=$_POST['action']??'';
    if ($a==='add_train') {
        $route=strtoupper(preg_replace('/[^A-Za-z,]/','',$_POST['route']??''));
        $pdo->prepare('INSERT INTO trains (number,name,zone,route,dep_time,arr_time) VALUES (?,?,?,?,?,?)')
            ->execute([trim($_POST['number']),trim($_POST['name']),trim($_POST['zone'])?:'SR',$route,$_POST['dep'],$_POST['arr']]);
        $id=$pdo->lastInsertId();
        foreach (CLASSES as $k=>$v) { $seats=(int)($_POST["seats_$k"]??0);
            if ($seats>0) $pdo->prepare('INSERT INTO train_classes (train_id,class_code,total_seats,fare) VALUES (?,?,?,?)')->execute([$id,$k,$seats,(float)$_POST["fare_$k"]]); }
        flash('Train added.'); redirect('admin.php?tab=trains');
    }
    if ($a==='toggle_train') { $pdo->prepare('UPDATE trains SET active=1-active WHERE id=?')->execute([(int)$_POST['id']]); redirect('admin.php?tab=trains'); }
    if ($a==='delete_train') { $pdo->prepare('DELETE FROM trains WHERE id=?')->execute([(int)$_POST['id']]); flash('Train deleted.'); redirect('admin.php?tab=trains'); }
    if ($a==='save_class') {
        $pdo->prepare('UPDATE train_classes SET total_seats=?, fare=? WHERE id=?')->execute([max(0,(int)$_POST['seats']),max(0,(float)$_POST['fare']),(int)$_POST['id']]);
        flash('Seats / fare updated.'); redirect('admin.php?tab=trains');
    }
    if ($a==='delete_user' && (int)$_POST['id']!==user()['id']) { $pdo->prepare('DELETE FROM users WHERE id=?')->execute([(int)$_POST['id']]); flash('User deleted.'); redirect('admin.php?tab=users'); }
    if ($a==='toggle_role' && (int)$_POST['id']!==user()['id']) { $pdo->prepare("UPDATE users SET role=IF(role='admin','user','admin') WHERE id=?")->execute([(int)$_POST['id']]); redirect('admin.php?tab=users'); }
    if ($a==='approve_refund') {
        $s=$pdo->prepare("SELECT * FROM bookings WHERE id=? AND refund_status='PENDING'"); $s->execute([(int)$_POST['id']]); $b=$s->fetch();
        if ($b) {
            $pdo->prepare("UPDATE bookings SET refund_status='REFUNDED' WHERE id=?")->execute([$b['id']]);
            $pdo->prepare("INSERT INTO payments (booking_id,amount,type,mode,txn_id,status) VALUES (?,?, 'REFUND','Original payment mode',?, 'REFUNDED')")
                ->execute([$b['id'],$b['refund_amount'],'RFD'.strtoupper(bin2hex(random_bytes(4)))]);
            $uu=$pdo->prepare('SELECT email FROM users WHERE id=?'); $uu->execute([$b['user_id']]);
            $pdo->prepare('INSERT INTO emails (user_id,to_email,subject,body) VALUES (?,?,?,?)')->execute([$b['user_id'],$uu->fetchColumn(),"Refund processed - PNR {$b['pnr']}","Your refund of ".money($b['refund_amount'])." has been released."]);
            flash('Refund of '.money($b['refund_amount']).' approved.');
        }
        redirect('admin.php?tab=refunds');
    }
}
$stat=[
 'Users'=>$pdo->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn(),
 'Trains'=>$pdo->query('SELECT COUNT(*) FROM trains')->fetchColumn(),
 'Bookings'=>$pdo->query('SELECT COUNT(*) FROM bookings')->fetchColumn(),
 'Revenue'=>money($pdo->query("SELECT COALESCE(SUM(CASE WHEN type='PAYMENT' THEN amount ELSE -amount END),0) FROM payments")->fetchColumn()),
 'Pending refunds'=>$pdo->query("SELECT COUNT(*) FROM bookings WHERE refund_status='PENDING'")->fetchColumn(),
];
$title='Admin Panel'; include 'header.php';
$tabs=['overview'=>'Overview','trains'=>'Trains & Seats','users'=>'Users','bookings'=>'Bookings','payments'=>'Payments','refunds'=>'Refunds','emails'=>'Emails'];
?>
<h1>🛠 Admin Panel</h1>
<div class="tabs"><?php foreach($tabs as $k=>$v): ?><a class="<?= $tab===$k?'active':'' ?>" href="admin.php?tab=<?= $k ?>"><?= $v ?></a><?php endforeach; ?></div>

<?php if ($tab==='overview'): ?>
<div class="grid5"><?php foreach($stat as $k=>$v): ?><div class="card stat"><b><?= e($v) ?></b><span><?= $k ?></span></div><?php endforeach; ?></div>
<div class="card"><p>Use the tabs above to manage train schedules, seat availability &amp; fares, users, bookings, payments received and refund approvals.</p></div>

<?php elseif ($tab==='trains'): ?>
<div class="card"><h3>Add train</h3>
<form method="post" class="formgrid"><input type="hidden" name="action" value="add_train">
 <label>Number<input name="number" required placeholder="12345"></label><label>Name<input name="name" required placeholder="Express name"></label>
 <label>Zone<input name="zone" value="SR"></label><label>Route (station codes)<input name="route" required placeholder="MS,VM,TPJ,MDU"></label>
 <label>Departure<input type="time" name="dep" required></label><label>Arrival<input type="time" name="arr" required></label>
 <?php foreach(CLASSES as $k=>$v): ?><label><?= $k ?> seats / fare<span class="two-in"><input type="number" name="seats_<?= $k ?>" value="<?= ['SL'=>72,'3A'=>64,'2A'=>48,'1A'=>24][$k] ?>"><input type="number" name="fare_<?= $k ?>" value="<?= ['SL'=>350,'3A'=>950,'2A'=>1350,'1A'=>2800][$k] ?>"></span></label><?php endforeach; ?>
 <button class="btn">Add train</button></form>
 <p class="muted tiny">Station codes: <?= e(implode(', ', array_keys(station_map()))) ?>. Weekend dates automatically add +10% to fares (date-wise fare).</p></div>
<?php foreach($pdo->query('SELECT * FROM trains ORDER BY id')->fetchAll() as $t): ?>
<div class="card"><div class="between"><h3><?= e($t['name']) ?> <span class="muted">#<?= e($t['number']) ?> • <?= e($t['zone']) ?> • <?= substr($t['dep_time'],0,5) ?> → <?= substr($t['arr_time'],0,5) ?></span> <?= $t['active']?'<span class="badge ok">Active</span>':'<span class="badge grey">Disabled</span>' ?></h3>
 <span class="nowrap"><form method="post" style="display:inline"><input type="hidden" name="action" value="toggle_train"><input type="hidden" name="id" value="<?= $t['id'] ?>"><button class="btn small ghost"><?= $t['active']?'Disable':'Enable' ?></button></form>
 <form method="post" style="display:inline" onsubmit="return confirm('Delete train and its bookings?')"><input type="hidden" name="action" value="delete_train"><input type="hidden" name="id" value="<?= $t['id'] ?>"><button class="btn small danger">Delete</button></form></span></div>
 <p class="muted tiny">Route: <?= e($t['route']) ?></p>
 <?php $cs=$pdo->prepare('SELECT * FROM train_classes WHERE train_id=? ORDER BY FIELD(class_code,"SL","3A","2A","1A")'); $cs->execute([$t['id']]); foreach($cs->fetchAll() as $c): ?>
 <form method="post" class="classrow"><input type="hidden" name="action" value="save_class"><input type="hidden" name="id" value="<?= $c['id'] ?>">
  <b><?= e($c['class_code']) ?></b><label>Seats <input type="number" name="seats" value="<?= $c['total_seats'] ?>"></label><label>Fare ₹ <input type="number" name="fare" value="<?= (int)$c['fare'] ?>"></label><button class="btn small">Save</button></form>
 <?php endforeach; ?></div>
<?php endforeach; ?>

<?php elseif ($tab==='users'): ?>
<div class="card scroll"><table class="tbl"><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Joined</th><th></th></tr>
<?php foreach($pdo->query('SELECT * FROM users ORDER BY id')->fetchAll() as $x): ?><tr><td><?= $x['id'] ?></td><td><?= e($x['name']) ?></td><td><?= e($x['email']) ?></td><td><?= e($x['phone']) ?></td><td><span class="badge <?= $x['role']==='admin'?'warn':'grey' ?>"><?= e($x['role']) ?></span></td><td><?= e($x['created_at']) ?></td>
<td class="nowrap"><?php if($x['id']!=user()['id']): ?>
<form method="post" style="display:inline"><input type="hidden" name="action" value="toggle_role"><input type="hidden" name="id" value="<?= $x['id'] ?>"><button class="btn small ghost">Toggle admin</button></form>
<form method="post" style="display:inline" onsubmit="return confirm('Delete this user?')"><input type="hidden" name="action" value="delete_user"><input type="hidden" name="id" value="<?= $x['id'] ?>"><button class="btn small danger">Delete</button></form><?php else: ?>(you)<?php endif; ?></td></tr><?php endforeach; ?></table></div>

<?php elseif ($tab==='bookings'): ?>
<div class="card scroll"><table class="tbl"><tr><th>PNR</th><th>Passenger (user)</th><th>Train</th><th>Date</th><th>Class</th><th>Pax</th><th>Fare</th><th>Status</th><th></th></tr>
<?php foreach($pdo->query('SELECT b.*,u.name uname,t.name tname FROM bookings b JOIN users u ON u.id=b.user_id JOIN trains t ON t.id=b.train_id ORDER BY b.id DESC')->fetchAll() as $b): ?>
<tr><td><b><?= e($b['pnr']) ?></b></td><td><?= e($b['uname']) ?></td><td><?= e($b['tname']) ?></td><td><?= e($b['journey_date']) ?></td><td><?= e($b['class_code']) ?></td><td><?= $b['pax'] ?></td><td><?= money($b['fare_total']) ?></td><td><?= status_badge($b['status']) ?></td><td><a class="btn small" href="ticket.php?pnr=<?= e($b['pnr']) ?>">View</a></td></tr><?php endforeach; ?></table></div>

<?php elseif ($tab==='payments'): ?>
<div class="card scroll"><h3>Payment details received by the system</h3><table class="tbl"><tr><th>Date</th><th>PNR</th><th>Type</th><th>Mode</th><th>Txn ID</th><th>Amount</th><th>Status</th></tr>
<?php foreach($pdo->query('SELECT p.*,b.pnr FROM payments p JOIN bookings b ON b.id=p.booking_id ORDER BY p.id DESC')->fetchAll() as $p): ?>
<tr><td><?= e($p['created_at']) ?></td><td><?= e($p['pnr']) ?></td><td><?= e($p['type']) ?></td><td><?= e($p['mode']) ?></td><td><?= e($p['txn_id']) ?></td><td><?= $p['type']==='REFUND'?'−':'' ?><?= money($p['amount']) ?></td><td><?= e($p['status']) ?></td></tr><?php endforeach; ?></table></div>

<?php elseif ($tab==='refunds'): ?>
<div class="card scroll"><h3>Cancellations &amp; refunds</h3><table class="tbl"><tr><th>PNR</th><th>Passenger</th><th>Fare paid</th><th>Refund %</th><th>Refund</th><th>Status</th><th></th></tr>
<?php foreach($pdo->query("SELECT b.*,u.name uname FROM bookings b JOIN users u ON u.id=b.user_id WHERE b.status='CANCELLED' ORDER BY b.id DESC")->fetchAll() as $b): ?>
<tr><td><b><?= e($b['pnr']) ?></b></td><td><?= e($b['uname']) ?></td><td><?= money($b['fare_total']) ?></td><td><?= $b['refund_percent'] ?>%</td><td><?= money($b['refund_amount']) ?></td>
<td><?= $b['refund_status']==='PENDING'?'<span class="badge warn">PENDING</span>':($b['refund_status']==='REFUNDED'?'<span class="badge ok">REFUNDED</span>':'<span class="badge grey">NO REFUND</span>') ?></td>
<td><?php if($b['refund_status']==='PENDING'): ?><form method="post"><input type="hidden" name="action" value="approve_refund"><input type="hidden" name="id" value="<?= $b['id'] ?>"><button class="btn small">Approve &amp; pay refund</button></form><?php endif; ?></td></tr><?php endforeach; ?></table></div>

<?php elseif ($tab==='emails'): ?>
<div class="card"><h3>Email log (demo — emails are stored, not sent)</h3>
<?php foreach($pdo->query('SELECT * FROM emails ORDER BY id DESC LIMIT 30')->fetchAll() as $m): ?><details><summary><b><?= e($m['subject']) ?></b> → <?= e($m['to_email']) ?> <small class="muted"><?= e($m['sent_at']) ?></small></summary><pre><?= e($m['body']) ?></pre></details><?php endforeach; ?></div>
<?php endif; ?>
<?php include 'footer.php'; ?>

<?php
$st = stations();
$f = $_GET['from'] ?? 'MS'; $t = $_GET['to'] ?? 'MDU';
$d = $_GET['date'] ?? date('Y-m-d', strtotime('+3 days'));
$c = $_GET['cls'] ?? ''; $tm = $_GET['time'] ?? '';
?>
<form class="search" action="search.php" method="get">
  <label>From<select name="from"><?php foreach ($st as $s): ?><option value="<?= e($s['code']) ?>" <?= $s['code']===$f?'selected':'' ?>><?= e($s['name']) ?> (<?= e($s['code']) ?>)</option><?php endforeach; ?></select></label>
  <label>To<select name="to"><?php foreach ($st as $s): ?><option value="<?= e($s['code']) ?>" <?= $s['code']===$t?'selected':'' ?>><?= e($s['name']) ?> (<?= e($s['code']) ?>)</option><?php endforeach; ?></select></label>
  <label>Date<input type="date" name="date" value="<?= e($d) ?>" min="<?= date('Y-m-d') ?>"></label>
  <label>Class<select name="cls"><option value="">All classes</option><?php foreach (CLASSES as $k=>$v): ?><option value="<?= $k ?>" <?= $k===$c?'selected':'' ?>><?= $k ?> – <?= $v ?></option><?php endforeach; ?></select></label>
  <label>Departure<select name="time">
    <?php foreach (['' =>'Any time','morning'=>'Morning (5-12)','afternoon'=>'Afternoon (12-17)','evening'=>'Evening (17-21)','night'=>'Night (21-5)'] as $k=>$v): ?>
    <option value="<?= $k ?>" <?= $k===$tm?'selected':'' ?>><?= $v ?></option><?php endforeach; ?></select></label>
  <button class="btn" type="submit">🔍 Search Trains</button>
</form>

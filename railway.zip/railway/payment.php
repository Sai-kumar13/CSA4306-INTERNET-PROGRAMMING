<?php
require 'config.php'; require_login();
$p=$_SESSION['pending']??null;
if (!$p) { flash('No booking in progress.'); redirect('search.php'); }
$names=station_map(); $n=count($p['pax']);
$s=$pdo->prepare('SELECT * FROM trains WHERE id=?'); $s->execute([$p['train']]); $tr=$s->fetch();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    // DEMO PAYMENT: nothing is charged. Clicking "Pay" always succeeds.
    $mode = $_POST['mode']==='offline' ? 'Offline - Pay at counter' : 'Online - '.($_POST['method']??'Card');
    $pdo->beginTransaction();
    try {
        $pdo->prepare('SELECT id FROM train_classes WHERE train_id=? AND class_code=? FOR UPDATE')->execute([$p['train'],$p['cls']]);
        $av = availability($pdo,$p['train'],$p['cls'],$p['date']);
        if ($av['avail']>=$n) $status='CONFIRMED';
        elseif ($av['rac_left']>=$n) $status='RAC';
        elseif ($av['wl']+$n<=WL_MAX) $status='WL';
        else { $pdo->rollBack(); flash('Sorry, this train/class is sold out for that date.'); redirect('search.php'); }
        $seats = $status==='CONFIRMED' ? assign_seats($pdo,$p['train'],$p['cls'],$p['date'],$av['total'],$n,$p['seats']) : [];
        $pnr = gen_pnr($pdo);
        $pdo->prepare('INSERT INTO bookings (pnr,user_id,train_id,class_code,journey_date,from_code,to_code,pax,fare_total,status,payment_mode) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
            ->execute([$pnr,user()['id'],$p['train'],$p['cls'],$p['date'],$p['from'],$p['to'],$n,$p['total'],$status,$mode]);
        $bid=(int)$pdo->lastInsertId();
        foreach ($p['pax'] as $i=>$x)
            $pdo->prepare('INSERT INTO passengers (booking_id,name,age,gender,seat_no,status) VALUES (?,?,?,?,?,?)')
                ->execute([$bid,$x['name'],$x['age'],$x['gender'],$seats[$i]??null,$status]);
        $txn='TXN'.strtoupper(bin2hex(random_bytes(5)));
        $pdo->prepare("INSERT INTO payments (booking_id,amount,type,mode,txn_id,status) VALUES (?,?, 'PAYMENT',?,?,?)")
            ->execute([$bid,$p['total'],$mode,$txn,$_POST['mode']==='offline'?'PAY AT COUNTER':'SUCCESS']);
        $body="Dear ".user()['name'].",\nYour booking is $status.\nPNR: $pnr\nTrain: {$tr['number']} {$tr['name']}\nRoute: {$names[$p['from']]} to {$names[$p['to']]}\nDate: {$p['date']}\nClass: {$p['cls']}\nPassengers: $n\nAmount: ".money($p['total'])."\nTransaction: $txn\n\nHappy journey! - RailBook";
        $pdo->prepare('INSERT INTO emails (user_id,to_email,subject,body) VALUES (?,?,?,?)')
            ->execute([user()['id'],user()['email'],"Booking $status - PNR $pnr",$body]);
        $pdo->commit();
    } catch (Exception $ex) { $pdo->rollBack(); die('Booking failed: '.e($ex->getMessage())); }
    unset($_SESSION['pending']);
    flash('🎉 Payment successful! Your ticket has been generated. A confirmation email was sent (demo).');
    redirect('ticket.php?pnr='.$pnr);
}
$title='Payment'; include 'header.php';
?>
<div class="narrow wide">
<div class="card">
  <h2>Review &amp; Pay</h2>
  <p><b><?= e($tr['name']) ?></b> (#<?= e($tr['number']) ?>) • <?= e($names[$p['from']]) ?> → <?= e($names[$p['to']]) ?> • <?= date('D, d M Y',strtotime($p['date'])) ?> • <?= e($p['cls']) ?></p>
  <table class="tbl"><tr><th>#</th><th>Passenger</th><th>Age</th><th>Gender</th></tr>
  <?php foreach ($p['pax'] as $i=>$x): ?><tr><td><?= $i+1 ?></td><td><?= e($x['name']) ?></td><td><?= $x['age'] ?></td><td><?= e($x['gender']) ?></td></tr><?php endforeach; ?></table>
  <p class="between"><span>Total fare</span><span class="big"><?= money($p['total']) ?></span></p>
</div>
<form method="post" id="payForm" class="card">
  <h3>Payment method <span class="badge warn">DEMO</span></h3>
  <label class="opt"><input type="radio" name="mode" value="online" checked> 💳 Pay online (secure gateway simulation)</label>
  <div id="online" class="sub">
    <select name="method"><option>Credit/Debit Card</option><option>UPI</option><option>Net Banking</option></select>
    <p class="muted tiny">No card number or OTP needed in demo mode.</p>
  </div>
  <label class="opt"><input type="radio" name="mode" value="offline"> 🏦 Pay offline (at reservation counter)</label>
  <button type="submit" class="btn block big-btn" id="payBtn">Pay <?= money($p['total']) ?> (Demo) ✔</button>
</form>
</div>
<div id="overlay" class="overlay"><div class="spinner"></div><p>Processing payment securely…</p></div>
<script>
document.getElementById('payForm').addEventListener('submit',function(e){
  e.preventDefault(); document.getElementById('overlay').classList.add('show');
  setTimeout(()=>this.submit(),1400); });
</script>
<?php include 'footer.php'; ?>

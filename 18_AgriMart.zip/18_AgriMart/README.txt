AgriMart

1. Open index.html in Chrome. The site works on its own.
2. Optional (XAMPP): copy this folder to C:\xampp\htdocs, start Apache and MySQL,
   import database.sql in phpMyAdmin, then open http://localhost/agrimart/index.html

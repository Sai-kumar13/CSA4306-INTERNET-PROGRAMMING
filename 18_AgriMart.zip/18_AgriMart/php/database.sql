CREATE DATABASE IF NOT EXISTS agrimart_db;
USE agrimart_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80),
  mobile VARCHAR(15),
  email VARCHAR(80),
  username VARCHAR(40),
  password VARCHAR(255),
  role VARCHAR(20) DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  farmer_id INT,
  name VARCHAR(100),
  category VARCHAR(30),
  price INT,
  image VARCHAR(120)
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  product_id INT,
  status VARCHAR(20),
  shipping VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS wallet (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  balance INT
);

INSERT INTO users (name, mobile, email, username, password, role) VALUES ('Admin', '9840012345', 'admin@example.in', 'admin', '$2y$10$abcdefghijklmnopqrstuv', 'admin');

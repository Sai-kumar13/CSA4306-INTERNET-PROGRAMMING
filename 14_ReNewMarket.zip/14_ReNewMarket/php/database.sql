CREATE DATABASE IF NOT EXISTS renewmarket_db;
USE renewmarket_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80),
  mobile VARCHAR(15),
  email VARCHAR(80),
  username VARCHAR(40),
  password VARCHAR(255),
  role VARCHAR(20) DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS commodities (
  id INT AUTO_INCREMENT PRIMARY KEY,
  seller_id INT,
  title VARCHAR(100),
  price INT,
  category_id INT
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  buyer_id INT,
  commodity_id INT,
  logistics VARCHAR(20)
);

INSERT INTO users (name, mobile, email, username, password, role) VALUES ('Admin', '9840012345', 'admin@example.in', 'admin', '$2y$10$abcdefghijklmnopqrstuv', 'admin');

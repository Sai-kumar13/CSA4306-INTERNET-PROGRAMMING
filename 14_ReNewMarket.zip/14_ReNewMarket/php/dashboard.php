<?php
session_start();
include 'config.php';
?>
<!DOCTYPE html>
<html><head><title>ReNewMarket Dashboard</title></head>
<body>
<h2>Dashboard</h2>
<p>Role: <?php echo $_SESSION['role'] ?? 'guest'; ?></p>
<p><a href="../index.html">Open website</a></p>
</body></html>

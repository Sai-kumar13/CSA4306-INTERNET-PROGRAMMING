<?php
$pdo=new PDO("mysql:host=localhost;charset=utf8mb4","root","",[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
$pdo->exec(file_get_contents(__DIR__.'/database/flight_db.sql'));
echo "<body style='font-family:sans-serif;text-align:center;margin-top:60px'><h2>✅ Database 'flight_db' installed successfully</h2><p><a href='index.php'>Open website</a> · <a href='admin_login.php'>Admin panel</a></p></body>";

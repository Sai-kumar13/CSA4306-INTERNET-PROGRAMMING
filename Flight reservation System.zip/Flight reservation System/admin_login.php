<?php require 'config.php'; $title='Admin Login';
if($_SERVER['REQUEST_METHOD']=='POST'){ $_SESSION['admin']=trim($_POST['username']??'')?:'admin'; header('Location: admin/index.php'); exit; }
include 'header.php'; ?>
<div class="box"><h2>Administrator Login</h2><p class="hint">Demo: leave empty and click Login.</p>
<form method="post"><label>Username<input name="username" placeholder="admin"></label><label>Password<input type="password" name="password" placeholder="(any)"></label>
<button class="btn full">Login as Admin</button></form><p><a href="forgot_password.php">Forgot password?</a></p></div>
<?php include 'footer.php'; ?>

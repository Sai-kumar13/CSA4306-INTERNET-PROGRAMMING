<?php require 'config.php'; require '_ticket.php'; need_login(); $title='Booking Confirmed';
$b=load_booking($pdo,$_GET['pnr']??''); if(!$b){ header('Location: dashboard.php'); exit; } include 'header.php'; ?>
<div class="ok big">🎉 Booking confirmed! PNR: <b><?=h($b['pnr'])?></b></div>
<div class="card mail"><b>📧 Confirmation e-mail (demo preview)</b><br>To: <?=h($b['contact_email'])?><br>Subject: Your SkyWings e-ticket – PNR <?=h($b['pnr'])?><br>
<small>Dear <?=h($b['uname'])?>, your booking is confirmed. Your e-ticket is shown below and attached to this mail.</small></div>
<?=ticket_html($b)?>
<p><a class="btn" href="print_ticket.php?pnr=<?=h($b['pnr'])?>">🖨 Print Ticket</a> <a class="btn alt" href="my_tickets.php">My Tickets</a></p>
<?php include 'footer.php'; ?>

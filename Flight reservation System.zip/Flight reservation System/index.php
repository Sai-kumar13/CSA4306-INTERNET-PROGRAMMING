<?php require 'config.php'; $title='Search Flights'; include 'header.php'; $cs=cities($pdo); ?>
<section class="hero"><h1>Book your next flight</h1><p>Search by destination, date and class – see live seat availability.</p>
<form class="search" action="search.php" method="get">
<label>From<select name="from"><?php foreach($cs as $c) echo "<option ".($c=='Chennai'?'selected':'').">".h($c)."</option>"; ?></select></label>
<label>To<select name="to"><?php foreach($cs as $c) echo "<option ".($c=='Delhi'?'selected':'').">".h($c)."</option>"; ?></select></label>
<label>Date<input type="date" name="date" value="<?=date('Y-m-d',strtotime('+3 days'))?>" min="<?=date('Y-m-d')?>"></label>
<label>Class<select name="class"><option>Economy</option><option>Business</option></select></label>
<label>Passengers<select name="pax"><?php for($i=1;$i<=6;$i++) echo "<option>$i</option>"; ?></select></label>
<button class="btn">Search Flights</button></form></section>
<section class="cards3"><div class="card"><h3>🔎 Live availability</h3><p>Seats left are calculated from the database in real time.</p></div>
<div class="card"><h3>💺 Pick your seat</h3><p>Interactive seat map for Economy and Business.</p></div>
<div class="card"><h3>🎫 E-ticket</h3><p>Confirmation e-mail preview, print ticket, cancel &amp; refund.</p></div></section>
<?php include 'footer.php'; ?>

<?php
session_start();
date_default_timezone_set('Asia/Kolkata');
$DB_HOST='localhost'; $DB_USER='root'; $DB_PASS=''; $DB_NAME='flight_db';
try {
  $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",$DB_USER,$DB_PASS,
    [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
} catch (Exception $e) {
  die("<h3>Database not found.</h3><p>Start Apache + MySQL in XAMPP, then run <a href='/skywings/install.php'>install.php</a> once.</p>");
}
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES); }
function logged(){ return isset($_SESSION['uid']); }
function need_login(){
  if(!logged()){ $_SESSION['next']=basename($_SERVER['PHP_SELF']).($_SERVER['QUERY_STRING']?'?'.$_SERVER['QUERY_STRING']:''); header('Location: login.php'); exit; }
}
function need_admin(){ if(!isset($_SESSION['admin'])){ header('Location: ../admin_login.php'); exit; } }
function seat_labels($total,$class){
  $cols = $class=='Business' ? 4 : 6; $L=range('A','F'); $o=[];
  for($i=0;$i<$total;$i++){ $o[] = ($class=='Business'?'B':'').(intdiv($i,$cols)+1).$L[$i%$cols]; }
  return $o;
}
function seats_taken($pdo,$fid,$date,$class){
  $st=$pdo->prepare("SELECT bp.seat_no FROM booking_passengers bp JOIN bookings b ON b.id=bp.booking_id
     WHERE b.flight_id=? AND b.travel_date=? AND b.class=? AND b.status='CONFIRMED'");
  $st->execute([$fid,$date,$class]); return array_column($st->fetchAll(),'seat_no');
}
function seats_left($pdo,$f,$date,$class){
  $tot = $class=='Business' ? $f['business_seats'] : $f['economy_seats'];
  return $tot - count(seats_taken($pdo,$f['id'],$date,$class));
}
function fare_of($f,$class){ return $class=='Business' ? $f['business_fare'] : $f['economy_fare']; }
function inr($n){ return '₹'.number_format($n); }
function cities($pdo){ return $pdo->query("SELECT DISTINCT origin c FROM flights ORDER BY c")->fetchAll(PDO::FETCH_COLUMN); }

<?php require 'config.php'; $title='Customer Feedback'; $ok=false;
if($_SERVER['REQUEST_METHOD']=='POST'){ $pdo->prepare("INSERT INTO feedback(name,email,rating,message) VALUES(?,?,?,?)")->execute([trim($_POST['name']??'')?:($_SESSION['uname']??'Guest'),trim($_POST['email']??''),(int)($_POST['rating']??5),trim($_POST['message']??'')?:'Great service!']); $ok=true; }
include 'header.php'; ?>
<div class="box"><h2>Customer Feedback</h2>
<?php if($ok) echo '<div class="ok">Thank you for your feedback! 💙</div>'; ?>
<form method="post"><label>Name<input name="name" value="<?=h($_SESSION['uname']??'')?>"></label><label>Email<input name="email"></label>
<label>Rating<select name="rating"><option value="5">★★★★★ Excellent</option><option value="4">★★★★ Good</option><option value="3">★★★ Average</option><option value="2">★★ Poor</option><option value="1">★ Bad</option></select></label>
<label>Message<textarea name="message" rows="4"></textarea></label><button class="btn full">Submit Feedback</button></form></div>
<?php include 'footer.php'; ?>

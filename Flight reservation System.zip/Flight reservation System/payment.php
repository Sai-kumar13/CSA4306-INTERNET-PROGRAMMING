<?php require 'config.php'; need_login(); $title='Payment';
if(empty($_SESSION['pending'])){ header('Location: index.php'); exit; } $P=$_SESSION['pending'];
$st=$pdo->prepare("SELECT * FROM flights WHERE id=?"); $st->execute([$P['fid']]); $f=$st->fetch();
if($_SERVER['REQUEST_METHOD']=='POST'){
  $taken=seats_taken($pdo,$P['fid'],$P['date'],$P['class']);
  foreach($P['pax'] as $x) if(in_array($x['seat'],$taken)){ unset($_SESSION['pending']); die("Seat {$x['seat']} was just taken. <a href='index.php'>Search again</a>"); }
  $pnr=strtoupper(substr(md5(uniqid('',true)),0,6));
  $pdo->prepare("INSERT INTO bookings(pnr,user_id,flight_id,travel_date,class,amount,contact_email,pay_method,status) VALUES(?,?,?,?,?,?,?,?,'CONFIRMED')")
      ->execute([$pnr,$_SESSION['uid'],$P['fid'],$P['date'],$P['class'],$P['amount'],$P['contact'],$_POST['method']??'Card']);
  $bid=$pdo->lastInsertId();
  foreach($P['pax'] as $x) $pdo->prepare("INSERT INTO booking_passengers(booking_id,name,age,gender,seat_no) VALUES(?,?,?,?,?)")->execute([$bid,$x['name'],$x['age'],$x['gender'],$x['seat']]);
  unset($_SESSION['pending']); header("Location: confirmation.php?pnr=$pnr"); exit;
}
include 'header.php'; ?>
<div class="grid2"><div class="card"><h3>Order summary</h3>
<p><b><?=h($f['flight_no'])?></b> <?=h($f['origin'])?> → <?=h($f['destination'])?><br><?=h($P['date'])?> · <?=h($P['class'])?></p>
<?php foreach($P['pax'] as $x) echo "<p>👤 ".h($x['name'])." — Seat <b>".h($x['seat'])."</b></p>"; ?>
<h2>Total: <?=inr($P['amount'])?> <small>(incl. 12% tax)</small></h2></div>
<div class="card"><h3>Payment gateway <small>(simulated)</small></h3>
<div class="tabs"><button type="button" class="tab on" data-m="Card">💳 Card</button><button type="button" class="tab" data-m="UPI">📱 UPI</button><button type="button" class="tab" data-m="NetBanking">🏦 Net Banking</button></div>
<form method="post" id="pf"><input type="hidden" name="method" id="method" value="Card">
<div class="pane" id="p-Card"><input placeholder="Card number (optional)"><div class="row"><input placeholder="MM/YY"><input placeholder="CVV"></div></div>
<div class="pane" id="p-UPI" hidden><input placeholder="yourname@upi (optional)"></div>
<div class="pane" id="p-NetBanking" hidden><select><option>State Bank of India</option><option>HDFC Bank</option><option>ICICI Bank</option></select></div>
<button type="button" class="btn full" id="pay">Pay <?=inr($P['amount'])?> (Demo – no real charge)</button></form></div></div>
<div class="overlay" id="ov" hidden><div class="spin"></div><p>Processing secure payment…</p></div>
<script>document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('on'));t.classList.add('on');
document.querySelectorAll('.pane').forEach(p=>p.hidden=true);document.getElementById('p-'+t.dataset.m).hidden=false;document.getElementById('method').value=t.dataset.m;});
document.getElementById('pay').onclick=()=>{document.getElementById('ov').hidden=false;setTimeout(()=>document.getElementById('pf').submit(),1800);};</script>
<?php include 'footer.php'; ?>

<?php require 'config.php'; need_login(); $title='Dashboard';
$st=$pdo->prepare("SELECT b.*,f.flight_no,f.origin,f.destination,f.departure FROM bookings b JOIN flights f ON f.id=b.flight_id WHERE b.user_id=? ORDER BY b.id DESC");
$st->execute([$_SESSION['uid']]); $bk=$st->fetchAll();
$up=0;$spent=0; foreach($bk as $b){ if($b['status']=='CONFIRMED'){ $spent+=$b['amount']; if($b['travel_date']>=date('Y-m-d')) $up++; } }
include 'header.php'; ?>
<h2>Welcome, <?=h($_SESSION['uname'])?> 👋</h2>
<div class="cards3"><div class="card stat"><b><?=count($bk)?></b>Total bookings</div><div class="card stat"><b><?=$up?></b>Upcoming trips</div><div class="card stat"><b><?=inr($spent)?></b>Total spent</div></div>
<p><a class="btn" href="index.php">Book a Flight</a> <a class="btn alt" href="my_tickets.php">My Tickets</a> <a class="btn alt" href="feedback.php">Give Feedback</a></p>
<h3>Travel itinerary &amp; history</h3>
<div class="tablewrap"><table><tr><th>PNR</th><th>Flight</th><th>Route</th><th>Date</th><th>Status</th><th></th></tr>
<?php foreach($bk as $b): ?><tr><td><?=h($b['pnr'])?></td><td><?=h($b['flight_no'])?></td><td><?=h($b['origin'])?> → <?=h($b['destination'])?></td><td><?=h($b['travel_date'])?> <?=substr($b['departure'],0,5)?></td>
<td><span class="badge <?=$b['status']=='CONFIRMED'?'':'low'?>"><?=h($b['status'])?></span></td><td><a href="print_ticket.php?pnr=<?=h($b['pnr'])?>">View</a></td></tr>
<?php endforeach; if(!$bk) echo '<tr><td colspan=6>No bookings yet.</td></tr>'; ?></table></div>
<?php include 'footer.php'; ?>

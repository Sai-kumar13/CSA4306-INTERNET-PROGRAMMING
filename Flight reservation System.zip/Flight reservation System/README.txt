SKYWINGS - ONLINE FLIGHT RESERVATION SYSTEM (PHP + MySQL, XAMPP) - DEMO MODE

SETUP
1. Install XAMPP, start Apache and MySQL in the XAMPP Control Panel.
2. Copy the folder "skywings" to  C:\xampp\htdocs\
3. Open http://localhost/skywings/install.php   (creates database "flight_db" with sample data)
   (Alternative: phpMyAdmin > Import > database/flight_db.sql)
4. Open http://localhost/skywings/

DEMO MODE: no real validation. Click Login/Register/Pay with empty fields and move to the next step.
Admin: http://localhost/skywings/admin_login.php (click Login). Demo PNR for status check: DEMO01
DB settings (root / no password) are in config.php.

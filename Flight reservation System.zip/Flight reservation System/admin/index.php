<?php include '_h.php'; $c=fn($q)=>$pdo->query($q)->fetchColumn();
$rev=$c("SELECT COALESCE(SUM(amount),0) FROM bookings WHERE status='CONFIRMED'"); ?>
<h2>Admin Dashboard</h2><div class="cards3">
<div class="card stat"><b><?=$c("SELECT COUNT(*) FROM flights")?></b>Flights</div>
<div class="card stat"><b><?=$c("SELECT COUNT(*) FROM users")?></b>Users</div>
<div class="card stat"><b><?=$c("SELECT COUNT(*) FROM bookings WHERE status='CONFIRMED'")?></b>Confirmed bookings</div>
<div class="card stat"><b><?=$c("SELECT COUNT(*) FROM bookings WHERE status='CANCELLED'")?></b>Cancelled</div>
<div class="card stat"><b><?=inr($rev)?></b>Revenue</div>
<div class="card stat"><b><?=$c("SELECT COUNT(*) FROM feedback")?></b>Feedback received</div></div>
<p><a class="btn" href="flights.php">Manage flights</a> <a class="btn alt" href="report.php">View report</a></p>
<?php include '_f.php'; ?>

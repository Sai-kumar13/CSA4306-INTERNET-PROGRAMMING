<?php include '_h.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
  $a=$_POST['a']??'';
  if($a=='add') $pdo->prepare("INSERT INTO flights(flight_no,airline,origin,destination,departure,arrival,economy_seats,business_seats,economy_fare,business_fare) VALUES(?,?,?,?,?,?,?,?,?,?)")
    ->execute([$_POST['flight_no']?:'SW999',$_POST['airline']?:'SkyWings',$_POST['origin']?:'Chennai',$_POST['destination']?:'Delhi',$_POST['departure']?:'09:00',$_POST['arrival']?:'11:30',(int)$_POST['es']?:60,(int)$_POST['bs']?:12,(int)$_POST['ef']?:4500,(int)$_POST['bf']?:12000]);
  if($a=='upd') $pdo->prepare("UPDATE flights SET economy_seats=?,business_seats=?,economy_fare=?,business_fare=?,departure=?,arrival=? WHERE id=?")->execute([(int)$_POST['es'],(int)$_POST['bs'],(int)$_POST['ef'],(int)$_POST['bf'],$_POST['departure'],$_POST['arrival'],(int)$_POST['id']]);
  if($a=='del'){ $pdo->prepare("DELETE FROM flights WHERE id=?")->execute([(int)$_POST['id']]); }
  header('Location: flights.php'); exit; }
$fl=$pdo->query("SELECT * FROM flights ORDER BY origin,destination,departure")->fetchAll(); ?>
<h2>Flight Schedules &amp; Seat Inventory</h2>
<form method="post" class="card addf"><input type="hidden" name="a" value="add"><b>Add flight</b>
<input name="flight_no" placeholder="Flight no"><input name="airline" placeholder="Airline"><input name="origin" placeholder="From"><input name="destination" placeholder="To">
<input type="time" name="departure"><input type="time" name="arrival"><input type="number" name="es" placeholder="Eco seats"><input type="number" name="bs" placeholder="Bus seats">
<input type="number" name="ef" placeholder="Eco fare"><input type="number" name="bf" placeholder="Bus fare"><button class="btn sm">Add</button></form>
<div class="tablewrap"><table><tr><th>No</th><th>Route</th><th>Dep</th><th>Arr</th><th>Eco seats</th><th>Bus seats</th><th>Eco ₹</th><th>Bus ₹</th><th></th></tr>
<?php foreach($fl as $f): ?><form method="post"><tr><td><?=h($f['flight_no'])?><input type="hidden" name="a" value="upd"><input type="hidden" name="id" value="<?=$f['id']?>"></td>
<td><?=h($f['origin'])?> → <?=h($f['destination'])?></td>
<td><input type="time" name="departure" value="<?=substr($f['departure'],0,5)?>"></td><td><input type="time" name="arrival" value="<?=substr($f['arrival'],0,5)?>"></td>
<td><input class="n" type="number" name="es" value="<?=$f['economy_seats']?>"></td><td><input class="n" type="number" name="bs" value="<?=$f['business_seats']?>"></td>
<td><input class="n" type="number" name="ef" value="<?=$f['economy_fare']?>"></td><td><input class="n" type="number" name="bf" value="<?=$f['business_fare']?>"></td>
<td><button class="btn sm">Save</button> <button class="btn sm danger" name="a" value="del" onclick="return confirm('Delete flight?')">Del</button></td></tr></form>
<?php endforeach; ?></table></div><?php include '_f.php'; ?>

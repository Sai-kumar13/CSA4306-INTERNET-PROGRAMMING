<?php include '_h.php';
$rows=$pdo->query("SELECT f.flight_no,f.origin,f.destination,COUNT(b.id) n,COALESCE(SUM(b.amount),0) rev FROM flights f LEFT JOIN bookings b ON b.flight_id=f.id AND b.status='CONFIRMED' GROUP BY f.id ORDER BY rev DESC")->fetchAll();
$max=max(1,...array_column($rows,'rev')); $tot=array_sum(array_column($rows,'rev')); ?>
<h2>Admin Report – Revenue by Flight</h2><p><button class="btn sm" onclick="window.print()">🖨 Print report</button> Total revenue: <b><?=inr($tot)?></b></p>
<div class="tablewrap"><table><tr><th>Flight</th><th>Route</th><th>Bookings</th><th>Revenue</th><th style="width:40%"></th></tr>
<?php foreach($rows as $r) echo "<tr><td>".h($r['flight_no'])."</td><td>".h($r['origin'])." → ".h($r['destination'])."</td><td>{$r['n']}</td><td>".inr($r['rev'])."</td><td><div class='bar' style='width:".round($r['rev']/$max*100)."%'></div></td></tr>"; ?></table></div>
<?php include '_f.php'; ?>

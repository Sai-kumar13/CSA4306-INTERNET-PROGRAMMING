<?php include '_h.php';
if($_SERVER['REQUEST_METHOD']=='POST'){ $pdo->prepare("DELETE FROM users WHERE id=?")->execute([(int)$_POST['id']]); header('Location: users.php'); exit; }
$rows=$pdo->query("SELECT u.*,(SELECT COUNT(*) FROM bookings WHERE user_id=u.id) n FROM users u ORDER BY id")->fetchAll(); ?>
<h2>User Accounts</h2><div class="tablewrap"><table><tr><th>#</th><th>Name</th><th>Email</th><th>Phone</th><th>Bookings</th><th></th></tr>
<?php foreach($rows as $u): ?><tr><td><?=$u['id']?></td><td><?=h($u['name'])?></td><td><?=h($u['email'])?></td><td><?=h($u['phone'])?></td><td><?=$u['n']?></td>
<td><form method="post"><input type="hidden" name="id" value="<?=$u['id']?>"><button class="btn sm danger" onclick="return confirm('Delete user and their bookings?')">Delete</button></form></td></tr><?php endforeach; ?></table></div><?php include '_f.php'; ?>

<?php include '_h.php';
$rows=$pdo->query("SELECT b.*,u.name uname,f.flight_no,f.origin,f.destination FROM bookings b JOIN users u ON u.id=b.user_id JOIN flights f ON f.id=b.flight_id ORDER BY b.id DESC")->fetchAll(); ?>
<h2>All Bookings</h2><div class="tablewrap"><table><tr><th>PNR</th><th>User</th><th>Flight</th><th>Route</th><th>Date</th><th>Class</th><th>Amount</th><th>Status</th></tr>
<?php foreach($rows as $b) echo "<tr><td>".h($b['pnr'])."</td><td>".h($b['uname'])."</td><td>".h($b['flight_no'])."</td><td>".h($b['origin'])." → ".h($b['destination'])."</td><td>".h($b['travel_date'])."</td><td>".h($b['class'])."</td><td>".inr($b['amount'])."</td><td>".h($b['status'])."</td></tr>"; ?></table></div><?php include '_f.php'; ?>

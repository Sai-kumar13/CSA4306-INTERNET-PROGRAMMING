<?php require_once __DIR__.'/../config.php'; need_admin(); ?>
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin | SkyWings</title><link rel="stylesheet" href="../assets/style.css"></head><body>
<header class="nav admin"><a class="logo" href="index.php">⚙ SkyWings Admin</a>
<button class="burger" onclick="document.getElementById('menu').classList.toggle('open')">☰</button>
<nav id="menu" class="menu"><a href="index.php">Dashboard</a><a href="flights.php">Flights &amp; Seats</a><a href="bookings.php">Bookings</a><a href="users.php">Users</a><a href="feedback.php">Feedback</a><a href="report.php">Reports</a><a href="../index.php">Site</a><a class="btn sm" href="logout.php">Logout</a></nav></header>
<main class="wrap">

<?php include '_h.php'; $rows=$pdo->query("SELECT * FROM feedback ORDER BY id DESC")->fetchAll(); ?>
<h2>Customer Feedback</h2><?php foreach($rows as $r) echo "<div class='card'><b>".h($r['name'])."</b> ".str_repeat('★',$r['rating'])."<br>".h($r['message'])."<br><small>".h($r['created_at'])."</small></div>"; include '_f.php'; ?>

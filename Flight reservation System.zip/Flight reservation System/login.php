<?php require 'config.php'; $title='Login';
if($_SERVER['REQUEST_METHOD']=='POST'){
  $email=trim($_POST['email']??''); if($email==='') $email='demo@skywings.com';
  $st=$pdo->prepare("SELECT * FROM users WHERE email=?"); $st->execute([$email]); $u=$st->fetch();
  if(!$u){ $name=ucfirst(explode('@',$email)[0]);
    $pdo->prepare("INSERT INTO users(name,email,password,phone) VALUES(?,?,?,?)")->execute([$name,$email,'demo','9876543210']);
    $st->execute([$email]); $u=$st->fetch(); }
  $_SESSION['uid']=$u['id']; $_SESSION['uname']=$u['name'];
  $next=$_SESSION['next']??'dashboard.php'; unset($_SESSION['next']);
  if(!preg_match('/^[a-z_]+\.php(\?[\w=&%.\-+]*)?$/i',$next)) $next='dashboard.php';
  header("Location: $next"); exit;
}
include 'header.php'; ?>
<div class="box"><h2>User Login</h2><p class="hint">Demo: leave fields empty and click Login.</p>
<form method="post"><label>Email<input type="text" name="email" placeholder="demo@skywings.com"></label>
<label>Password<input type="password" name="password" placeholder="(any)"></label>
<button class="btn full">Login</button></form>
<p><a href="forgot_password.php">Forgot password?</a> · <a href="register.php">Create account</a></p></div>
<?php include 'footer.php'; ?>

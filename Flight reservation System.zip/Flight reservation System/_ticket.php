<?php
function load_booking($pdo,$pnr){
  $st=$pdo->prepare("SELECT b.*,f.flight_no,f.airline,f.origin,f.destination,f.departure,f.arrival,u.name uname FROM bookings b JOIN flights f ON f.id=b.flight_id JOIN users u ON u.id=b.user_id WHERE b.pnr=?");
  $st->execute([strtoupper(trim($pnr))]); $b=$st->fetch(); if(!$b) return null;
  $p=$pdo->prepare("SELECT * FROM booking_passengers WHERE booking_id=?"); $p->execute([$b['id']]); $b['pax']=$p->fetchAll(); return $b;
}
function ticket_html($b){ ob_start(); ?>
<div class="ticket"><div class="th"><b>✈ SkyWings</b><span>E-TICKET · PNR <b><?=h($b['pnr'])?></b></span></div>
<div class="tb"><div class="route"><div><big><?=h($b['origin'])?></big><small><?=substr($b['departure'],0,5)?></small></div><div>✈</div><div><big><?=h($b['destination'])?></big><small><?=substr($b['arrival'],0,5)?></small></div></div>
<p>Flight <b><?=h($b['flight_no'])?></b> (<?=h($b['airline'])?>) · <?=h(date('D, d M Y',strtotime($b['travel_date'])))?> · <?=h($b['class'])?></p>
<table><tr><th>Passenger</th><th>Age</th><th>Gender</th><th>Seat</th></tr>
<?php foreach($b['pax'] as $x) echo "<tr><td>".h($x['name'])."</td><td>".h($x['age'])."</td><td>".h($x['gender'])."</td><td><b>".h($x['seat_no'])."</b></td></tr>"; ?></table>
<p>Amount paid: <b><?=inr($b['amount'])?></b> via <?=h($b['pay_method'])?> · Status: <span class="badge <?=$b['status']=='CONFIRMED'?'':'low'?>"><?=h($b['status'])?></span></p>
<div class="barcode"><?=str_repeat('▌▎▍▏▌▋ ',9)?></div></div></div>
<?php return ob_get_clean(); }

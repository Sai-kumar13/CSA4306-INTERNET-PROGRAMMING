<?php require 'config.php'; $title='Forgot Password'; $sent=($_SERVER['REQUEST_METHOD']=='POST'); include 'header.php'; ?>
<div class="box"><h2>Forgot Password</h2>
<?php if($sent): ?><div class="ok">📧 Password reset link sent to <b><?=h($_POST['email']?:'your registered email')?></b> (demo – no real email).</div>
<p><a class="btn" href="login.php">Back to Login</a></p>
<?php else: ?><form method="post"><label>Registered email<input name="email" placeholder="you@example.com"></label><button class="btn full">Send Reset Link</button></form><?php endif; ?></div>
<?php include 'footer.php'; ?>

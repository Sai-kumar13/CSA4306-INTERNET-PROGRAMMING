<?php require_once __DIR__.'/config.php'; ?>
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=h($title??'Home')?> | SkyWings</title>
<link rel="stylesheet" href="assets/style.css"></head><body>
<header class="nav"><a class="logo" href="index.php">✈ SkyWings</a>
<button class="burger" onclick="document.getElementById('menu').classList.toggle('open')">☰</button>
<nav id="menu" class="menu">
<a href="index.php">Search Flights</a><a href="booking_status.php">Booking Status</a><a href="feedback.php">Feedback</a>
<?php if(logged()): ?>
<a href="dashboard.php">Dashboard</a><a href="my_tickets.php">My Tickets</a><a href="logout.php" class="btn sm">Logout (<?=h($_SESSION['uname'])?>)</a>
<?php else: ?>
<a href="login.php">Login</a><a href="register.php" class="btn sm">Register</a><a href="admin_login.php">Admin</a>
<?php endif; ?>
</nav></header>
<div class="demo-bar">DEMO MODE – no real login or payment. Just click through every step.</div>
<main class="wrap">

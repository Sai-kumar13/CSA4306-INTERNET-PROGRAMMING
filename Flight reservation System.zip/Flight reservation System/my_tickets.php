<?php require 'config.php'; need_login(); $title='My Tickets';
$st=$pdo->prepare("SELECT b.*,f.flight_no,f.origin,f.destination,f.departure,(SELECT COUNT(*) FROM booking_passengers WHERE booking_id=b.id) n FROM bookings b JOIN flights f ON f.id=b.flight_id WHERE b.user_id=? ORDER BY b.id DESC");
$st->execute([$_SESSION['uid']]); $rows=$st->fetchAll(); include 'header.php'; ?>
<h2>My Tickets</h2>
<?php foreach($rows as $b): ?><div class="flight"><div><b><?=h($b['pnr'])?></b><br><small><?=h($b['flight_no'])?></small></div>
<div><?=h($b['origin'])?> → <?=h($b['destination'])?><br><small><?=h($b['travel_date'])?> · <?=substr($b['departure'],0,5)?></small></div>
<div><?=$b['n']?> pax · <?=h($b['class'])?></div><div><?=inr($b['amount'])?></div>
<div><span class="badge <?=$b['status']=='CONFIRMED'?'':'low'?>"><?=h($b['status'])?></span></div>
<div><a class="btn sm" href="print_ticket.php?pnr=<?=h($b['pnr'])?>">View / Print</a>
<?php if($b['status']=='CONFIRMED'): ?> <a class="btn sm danger" href="cancel_ticket.php?pnr=<?=h($b['pnr'])?>">Cancel</a><?php endif; ?></div></div>
<?php endforeach; if(!$rows) echo '<div class="card">No tickets yet. <a href="index.php">Book a flight</a></div>'; include 'footer.php'; ?>

</main><footer class="foot">© <?=date('Y')?> SkyWings Airline Reservation System · Internet Programming Lab Project (PHP + MySQL)</footer></body></html>

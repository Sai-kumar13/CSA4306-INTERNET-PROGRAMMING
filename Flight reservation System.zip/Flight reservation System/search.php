<?php require 'config.php'; $title='Search Results';
$from=$_GET['from']??''; $to=$_GET['to']??''; $date=$_GET['date']??date('Y-m-d'); $class=$_GET['class']??'Economy'; $pax=max(1,(int)($_GET['pax']??1));
$st=$pdo->prepare("SELECT * FROM flights WHERE origin=? AND destination=? ORDER BY departure"); $st->execute([$from,$to]); $fl=$st->fetchAll();
include 'header.php'; ?>
<h2><?=h($from)?> → <?=h($to)?> <small>· <?=h(date('D, d M Y',strtotime($date)))?> · <?=h($class)?> · <?=$pax?> pax</small></h2>
<?php if(!$fl): ?><div class="card">No flights found for this route. <a href="index.php">Try again</a></div><?php endif;
foreach($fl as $f): $left=seats_left($pdo,$f,$date,$class); $fare=fare_of($f,$class); ?>
<div class="flight"><div><b><?=h($f['airline'])?></b><br><small><?=h($f['flight_no'])?></small></div>
<div class="t"><b><?=substr($f['departure'],0,5)?></b><br><small><?=h($f['origin'])?></small></div>
<div class="arrow">✈ ──────</div>
<div class="t"><b><?=substr($f['arrival'],0,5)?></b><br><small><?=h($f['destination'])?></small></div>
<div><span class="badge <?=$left<10?'low':''?>"><?=$left?> seats left</span></div>
<div class="price"><?=inr($fare)?><small>/person</small></div>
<div><?php if($left>=$pax): ?><a class="btn" href="book.php?fid=<?=$f['id']?>&date=<?=h($date)?>&class=<?=h($class)?>&pax=<?=$pax?>">Book Now</a><?php else: ?><span class="badge low">Sold out</span><?php endif; ?></div></div>
<?php endforeach; include 'footer.php'; ?>

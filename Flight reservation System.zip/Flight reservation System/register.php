<?php require 'config.php'; $title='Register';
if($_SERVER['REQUEST_METHOD']=='POST'){
  $name=trim($_POST['name']??'')?:'Demo User'; $email=trim($_POST['email']??'')?:'user'.rand(100,999).'@skywings.com'; $phone=trim($_POST['phone']??'')?:'9876543210';
  $st=$pdo->prepare("SELECT * FROM users WHERE email=?"); $st->execute([$email]); $u=$st->fetch();
  if(!$u){ $pdo->prepare("INSERT INTO users(name,email,password,phone) VALUES(?,?,?,?)")->execute([$name,$email,'demo',$phone]); $st->execute([$email]); $u=$st->fetch(); }
  $_SESSION['uid']=$u['id']; $_SESSION['uname']=$u['name']; header('Location: dashboard.php'); exit;
}
include 'header.php'; ?>
<div class="box"><h2>Create Account</h2><p class="hint">All fields optional in demo mode.</p>
<form method="post"><label>Full name<input name="name"></label><label>Email<input name="email"></label>
<label>Phone<input name="phone"></label><label>Password<input type="password" name="password"></label>
<button class="btn full">Register</button></form></div>
<?php include 'footer.php'; ?>

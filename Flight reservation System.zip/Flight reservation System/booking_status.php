<?php require 'config.php'; require '_ticket.php'; $title='Booking Status'; $b=null; $q=trim($_GET['pnr']??'');
if($q!==''){ $b=load_booking($pdo,$q); } include 'header.php'; ?>
<div class="box"><h2>View Booking Status</h2><form method="get"><label>Enter PNR<input name="pnr" value="<?=h($q)?>" placeholder="e.g. DEMO01"></label><button class="btn full">Check Status</button></form>
<p class="hint">Try demo PNR: <b>DEMO01</b></p></div>
<?php if($q!==''): if($b): echo ticket_html($b); echo '<p><a class="btn" href="print_ticket.php?pnr='.h($b['pnr']).'">Print Ticket</a></p>'; else: echo '<div class="card">No booking found for this PNR.</div>'; endif; endif; include 'footer.php'; ?>

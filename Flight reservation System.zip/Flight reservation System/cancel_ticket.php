<?php require 'config.php'; require '_ticket.php'; need_login(); $title='Cancel Ticket';
$b=load_booking($pdo,$_GET['pnr']??$_POST['pnr']??''); if(!$b||$b['user_id']!=$_SESSION['uid']){ header('Location: my_tickets.php'); exit; }
$refund=round($b['amount']*0.8); $done=false;
if($_SERVER['REQUEST_METHOD']=='POST' && $b['status']=='CONFIRMED'){ $pdo->prepare("UPDATE bookings SET status='CANCELLED',refund=? WHERE id=?")->execute([$refund,$b['id']]); $done=true; }
include 'header.php'; ?>
<div class="box"><h2>Cancel Ticket</h2>
<?php if($done): ?><div class="ok">Ticket <b><?=h($b['pnr'])?></b> cancelled. Refund of <b><?=inr($refund)?></b> will be credited (demo).</div><p><a class="btn" href="my_tickets.php">My Tickets</a></p>
<?php elseif($b['status']!='CONFIRMED'): ?><div class="ok">This ticket is already cancelled.</div>
<?php else: ?><p>PNR <b><?=h($b['pnr'])?></b> · <?=h($b['origin'])?> → <?=h($b['destination'])?> · <?=h($b['travel_date'])?></p>
<p>Paid <?=inr($b['amount'])?> · Refund (80%): <b><?=inr($refund)?></b></p>
<form method="post"><input type="hidden" name="pnr" value="<?=h($b['pnr'])?>"><button class="btn danger full">Confirm Cancellation</button></form><?php endif; ?></div>
<?php include 'footer.php'; ?>

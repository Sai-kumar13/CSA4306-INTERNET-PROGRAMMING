<?php require 'config.php'; require '_ticket.php'; $title='Print Ticket';
$b=load_booking($pdo,$_GET['pnr']??''); if(!$b){ die('Ticket not found. <a href="booking_status.php">Check status</a>'); } include 'header.php'; ?>
<?=ticket_html($b)?>
<p class="noprint"><button class="btn" onclick="window.print()">🖨 Print Ticket</button> <a class="btn alt" href="my_tickets.php">Back</a></p>
<?php include 'footer.php'; ?>

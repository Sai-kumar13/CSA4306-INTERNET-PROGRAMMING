<?php require 'config.php'; need_login(); $title='Book Ticket';
$fid=(int)($_GET['fid']??0); $date=$_GET['date']??date('Y-m-d'); $class=$_GET['class']??'Economy'; $pax=max(1,min(6,(int)($_GET['pax']??1)));
$st=$pdo->prepare("SELECT * FROM flights WHERE id=?"); $st->execute([$fid]); $f=$st->fetch(); if(!$f){ header('Location: index.php'); exit; }
$taken=seats_taken($pdo,$fid,$date,$class);
$labels=seat_labels($class=='Business'?$f['business_seats']:$f['economy_seats'],$class); $cols=$class=='Business'?4:6;
if($_SERVER['REQUEST_METHOD']=='POST'){
  $seats=$_POST['seats']??[]; $names=$_POST['pname']??[]; $ages=$_POST['page']??[]; $gen=$_POST['pgender']??[];
  $avail=array_values(array_diff($labels,$taken));
  // demo: auto-assign seats if the user did not pick enough
  $seats=array_values(array_intersect($seats,$avail));
  foreach($avail as $s){ if(count($seats)>=$pax) break; if(!in_array($s,$seats)) $seats[]=$s; }
  $seats=array_slice($seats,0,$pax); $p=[];
  for($i=0;$i<$pax;$i++) $p[]=['name'=>trim($names[$i]??'')?:'Passenger '.($i+1),'age'=>(int)($ages[$i]??0)?:30,'gender'=>$gen[$i]??'Male','seat'=>$seats[$i]];
  $sub=fare_of($f,$class)*$pax; $_SESSION['pending']=['fid'=>$fid,'date'=>$date,'class'=>$class,'pax'=>$p,'amount'=>round($sub*1.12),'contact'=>trim($_POST['email']??'')?:'demo@skywings.com'];
  header('Location: payment.php'); exit;
}
include 'header.php'; ?>
<h2>Book: <?=h($f['flight_no'])?> · <?=h($f['origin'])?> → <?=h($f['destination'])?></h2>
<p><?=h(date('D, d M Y',strtotime($date)))?> · <?=substr($f['departure'],0,5)?> – <?=substr($f['arrival'],0,5)?> · <?=h($class)?> · <?=inr(fare_of($f,$class))?>/person</p>
<form method="post" class="grid2">
<div class="card"><h3>1. Choose seats (<?=$pax?>)</h3><p class="hint">Click seats on the map. Skipped seats are auto-assigned.</p>
<div class="legend"><span class="s free"></span>Free <span class="s sel"></span>Selected <span class="s occ"></span>Taken</div>
<div class="seatmap" style="grid-template-columns:repeat(<?=$cols+1?>,38px)">
<?php foreach($labels as $i=>$s): 
 if($i%$cols==$cols/2) echo '<span></span>'; $occ=in_array($s,$taken); ?>
<label class="seat <?=$occ?'occ':''?>"><input type="checkbox" name="seats[]" value="<?=$s?>" <?=$occ?'disabled':''?>><span><?=$s?></span></label>
<?php endforeach; ?></div></div>
<div class="card"><h3>2. Passenger details</h3><p class="hint">Optional in demo mode.</p>
<?php for($i=0;$i<$pax;$i++): ?><fieldset><legend>Passenger <?=$i+1?></legend>
<input name="pname[]" placeholder="Full name"><div class="row"><input name="page[]" type="number" placeholder="Age"><select name="pgender[]"><option>Male</option><option>Female</option><option>Other</option></select></div></fieldset><?php endfor; ?>
<label>Contact email (e-ticket)<input name="email" placeholder="demo@skywings.com"></label>
<button class="btn full">Continue to Payment →</button></div></form>
<script>const max=<?=$pax?>;document.querySelectorAll('.seat input').forEach(c=>c.addEventListener('change',()=>{
 if(document.querySelectorAll('.seat input:checked').length>max){c.checked=false;alert('You can select only '+max+' seat(s).');}}));</script>
<?php include 'footer.php'; ?>

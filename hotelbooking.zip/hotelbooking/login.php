<?php
require __DIR__ . '/config.php';

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    $u = one(q("SELECT * FROM users WHERE email = ?", 's', [$email]));
    if ($u && password_verify($pass, $u['password'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => (int)$u['id'], 'name' => $u['name'], 'role' => $u['role']];
        header('Location: ' . ($u['role'] === 'admin' ? 'admin/index.php' : 'index.php'));
        exit;
    }
    $err = 'Invalid email or password.';
}
include __DIR__ . '/header.php';
?>
<div class="card formbox">
  <h2>Login</h2>
  <?php if (isset($_GET['registered'])): ?><div class="msg ok">Registration successful. Please login.</div><?php endif; ?>
  <?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
  <form method="post">
    Email<input type="email" name="email" required>
    Password<input type="password" name="password" required>
    <button type="submit">Login</button>
  </form>
  <p>New guest? <a href="register.php">Create an account</a></p>
</div>
<?php include __DIR__ . '/footer.php'; ?>

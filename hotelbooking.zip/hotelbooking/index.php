<?php
require __DIR__ . '/config.php';

$in  = $_GET['checkin'] ?? '';
$out = $_GET['checkout'] ?? '';
$err = '';
$types = rows(q("SELECT * FROM room_types ORDER BY price"));
$results = null;

// Room availability check
if ($in !== '' || $out !== '') {
    $err = check_dates($in, $out);
    if ($err === '') {
        $results = [];
        foreach ($types as $t) {
            $t['left'] = rooms_left($t['id'], $in, $out);
            $results[] = $t;
        }
    }
}

include __DIR__ . '/header.php';
?>
<div class="card hero">
  <h2>Welcome to Grand Stay Hotel</h2>
  Comfortable rooms, friendly service. Check room availability and book online.
</div>

<h2>Check Room Availability</h2>
<?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
<form method="get" class="card">
  <div class="grid2">
    <div>Check-in date<input type="date" name="checkin" value="<?= e($in) ?>" min="<?= date('Y-m-d') ?>" required></div>
    <div>Check-out date<input type="date" name="checkout" value="<?= e($out) ?>" min="<?= date('Y-m-d') ?>" required></div>
  </div>
  <button type="submit">Check Availability</button>
</form>

<?php if ($results !== null): ?>
  <h3>Availability: <?= e($in) ?> to <?= e($out) ?> (<?= nights($in, $out) ?> night(s))</h3>
  <div class="table-wrap">
  <table>
    <tr><th>Room type</th><th>Guests / room</th><th>Price / night</th><th>Price for stay (1 room)</th><th>Rooms available</th><th></th></tr>
    <?php foreach ($results as $r): ?>
    <tr>
      <td><?= e($r['name']) ?></td>
      <td><?= (int)$r['capacity'] ?></td>
      <td>Rs. <?= e($r['price']) ?></td>
      <td>Rs. <?= e($r['price'] * nights($in, $out)) ?></td>
      <td><?= (int)$r['left'] ?></td>
      <td>
        <?php if ($r['left'] > 0): ?>
          <a class="btn small" href="book.php?type=<?= (int)$r['id'] ?>&checkin=<?= e($in) ?>&checkout=<?= e($out) ?>">Book</a>
        <?php else: ?>
          Sold out
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
  </div>
<?php else: ?>
  <h3>Our Rooms</h3>
  <div class="table-wrap">
  <table>
    <tr><th>Room type</th><th>Guests / room</th><th>Price / night</th></tr>
    <?php foreach ($types as $t): ?>
      <tr><td><?= e($t['name']) ?></td><td><?= (int)$t['capacity'] ?></td><td>Rs. <?= e($t['price']) ?></td></tr>
    <?php endforeach; ?>
  </table>
  </div>
  <a href="page.php?slug=rooms">Read more about our rooms</a>
<?php endif; ?>
<?php include __DIR__ . '/footer.php'; ?>

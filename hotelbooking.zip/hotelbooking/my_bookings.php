<?php
require __DIR__ . '/config.php';
require_login();

$list = rows(q("SELECT b.*, r.name AS room FROM bookings b JOIN room_types r ON r.id = b.room_type_id
                WHERE b.user_id = ? ORDER BY b.id DESC", 'i', [$_SESSION['user']['id']]));

include __DIR__ . '/header.php';
?>
<h2>My Bookings</h2>
<?php if (isset($_GET['booked'])): ?><div class="msg ok">Booking #<?= (int)$_GET['booked'] ?> confirmed. A confirmation email has been sent (requires mail setup in XAMPP).</div><?php endif; ?>
<?php if (isset($_GET['updated'])): ?><div class="msg ok">Booking updated.</div><?php endif; ?>
<?php if (isset($_GET['cancelled'])): ?><div class="msg ok">Booking cancelled.</div><?php endif; ?>
<?php if (isset($_GET['late'])): ?><div class="msg err">Bookings can only be changed or cancelled up to 3 days before arrival.</div><?php endif; ?>

<p>You can change or cancel a booking up to 3 days before the arrival date. <a href="index.php">Book another room</a></p>

<div class="table-wrap">
<table>
  <tr><th>ID</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Rooms</th><th>Guests</th><th>Total</th><th>Status</th><th></th></tr>
  <?php if (!$list): ?><tr><td colspan="9">No bookings yet.</td></tr><?php endif; ?>
  <?php foreach ($list as $b): ?>
  <tr>
    <td>#<?= (int)$b['id'] ?></td>
    <td><?= e($b['room']) ?></td>
    <td><?= e($b['checkin']) ?></td>
    <td><?= e($b['checkout']) ?></td>
    <td><?= (int)$b['rooms'] ?></td>
    <td><?= (int)$b['guests'] ?></td>
    <td>Rs. <?= e($b['total_amount']) ?></td>
    <td><?= e($b['status']) ?></td>
    <td>
      <?php if ($b['status'] === 'Booked' && can_change($b['checkin'])): ?>
        <a class="btn small" href="edit_booking.php?id=<?= (int)$b['id'] ?>">Change</a>
        <form method="post" action="cancel_booking.php" class="inline" onsubmit="return confirm('Cancel this booking?');">
          <input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
          <button class="btn-red small" type="submit">Cancel</button>
        </form>
      <?php endif; ?>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/footer.php'; ?>

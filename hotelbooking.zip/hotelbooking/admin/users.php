<?php
require __DIR__ . '/../config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    q("DELETE FROM users WHERE id = ? AND role = 'user'", 'i', [(int)$_POST['delete']]);
    header('Location: users.php');
    exit;
}
$users = rows(q("SELECT * FROM users ORDER BY id"));

include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<h2>Registered Users</h2>
<div class="table-wrap">
<table>
  <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Registered</th><th></th></tr>
  <?php foreach ($users as $u): ?>
  <tr>
    <td><?= (int)$u['id'] ?></td>
    <td><?= e($u['name']) ?></td>
    <td><?= e($u['email']) ?></td>
    <td><?= e($u['phone']) ?></td>
    <td><?= e($u['role']) ?></td>
    <td><?= e($u['created_at']) ?></td>
    <td>
      <?php if ($u['role'] === 'user'): ?>
      <form method="post" onsubmit="return confirm('Delete this user and their bookings?');">
        <button class="btn-red small" name="delete" value="<?= (int)$u['id'] ?>">Delete</button>
      </form>
      <?php endif; ?>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/../footer.php'; ?>

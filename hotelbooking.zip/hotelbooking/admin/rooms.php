<?php
require __DIR__ . '/../config.php';
require_admin();

$msg = $err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prices = $_POST['price'] ?? [];
    $qtys = $_POST['qty'] ?? [];
    foreach ($prices as $id => $p) {
        if ((float)$p <= 0 || (int)($qtys[$id] ?? -1) < 0) {
            $err = 'Price must be greater than 0 and quantity cannot be negative.';
            break;
        }
    }
    if ($err === '') {
        foreach ($prices as $id => $p) {
            q("UPDATE room_types SET price = ?, quantity = ? WHERE id = ?", 'dii', [(float)$p, (int)$qtys[$id], (int)$id]);
        }
        $msg = 'Room prices and quantities updated.';
    }
}
$types = rows(q("SELECT * FROM room_types ORDER BY price"));

include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<h2>Room Price &amp; Quantity</h2>
<?php if ($msg): ?><div class="msg ok"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="card">
  <div class="table-wrap">
  <table>
    <tr><th>Room type</th><th>Guests / room</th><th>Price per night (Rs.)</th><th>Quantity (number of rooms)</th></tr>
    <?php foreach ($types as $t): ?>
    <tr>
      <td><?= e($t['name']) ?></td>
      <td><?= (int)$t['capacity'] ?></td>
      <td><input type="number" step="0.01" min="1" name="price[<?= (int)$t['id'] ?>]" value="<?= e($t['price']) ?>" required></td>
      <td><input type="number" min="0" name="qty[<?= (int)$t['id'] ?>]" value="<?= (int)$t['quantity'] ?>" required></td>
    </tr>
    <?php endforeach; ?>
  </table>
  </div>
  <button type="submit">Save Changes</button>
</form>
<?php include __DIR__ . '/../footer.php'; ?>

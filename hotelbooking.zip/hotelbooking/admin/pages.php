<?php
require __DIR__ . '/../config.php';
require_admin();

$pages = rows(q("SELECT slug, title FROM pages ORDER BY sort"));

include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<h2>Static Pages</h2>
<?php if (isset($_GET['saved'])): ?><div class="msg ok">Page saved.</div><?php endif; ?>
<div class="table-wrap">
<table>
  <tr><th>Page</th><th></th></tr>
  <?php foreach ($pages as $p): ?>
  <tr>
    <td><?= e($p['title']) ?></td>
    <td>
      <a class="btn small" href="page_edit.php?slug=<?= e($p['slug']) ?>">Edit</a>
      <a class="btn btn-gray small" href="<?= BASE ?>/page.php?slug=<?= e($p['slug']) ?>">View</a>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/../footer.php'; ?>

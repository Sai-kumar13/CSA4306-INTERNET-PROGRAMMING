<?php
require __DIR__ . '/../config.php';
require_admin();

// Admin can cancel any booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel'])) {
    q("UPDATE bookings SET status = 'Cancelled' WHERE id = ?", 'i', [(int)$_POST['cancel']]);
    header('Location: bookings.php?cancelled=1');
    exit;
}

$list = rows(q("SELECT b.*, r.name AS room, u.name AS guest, u.phone FROM bookings b
                JOIN room_types r ON r.id = b.room_type_id JOIN users u ON u.id = b.user_id
                ORDER BY b.id DESC"));

include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<h2>All Bookings</h2>
<?php if (isset($_GET['cancelled'])): ?><div class="msg ok">Booking cancelled.</div><?php endif; ?>
<?php if (isset($_GET['updated'])): ?><div class="msg ok">Booking updated.</div><?php endif; ?>

<div class="table-wrap">
<table>
  <tr><th>ID</th><th>Guest</th><th>Phone</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Rooms</th><th>Guests</th><th>Total</th><th>Status</th><th></th></tr>
  <?php if (!$list): ?><tr><td colspan="11">No bookings.</td></tr><?php endif; ?>
  <?php foreach ($list as $b): ?>
  <tr>
    <td>#<?= (int)$b['id'] ?></td>
    <td><?= e($b['guest']) ?></td>
    <td><?= e($b['phone']) ?></td>
    <td><?= e($b['room']) ?></td>
    <td><?= e($b['checkin']) ?></td>
    <td><?= e($b['checkout']) ?></td>
    <td><?= (int)$b['rooms'] ?></td>
    <td><?= (int)$b['guests'] ?></td>
    <td>Rs. <?= e($b['total_amount']) ?></td>
    <td><?= e($b['status']) ?></td>
    <td>
      <?php if ($b['status'] === 'Booked'): ?>
        <a class="btn small" href="booking_edit.php?id=<?= (int)$b['id'] ?>">Edit</a>
        <form method="post" class="inline" onsubmit="return confirm('Cancel this booking?');">
          <button class="btn-red small" name="cancel" value="<?= (int)$b['id'] ?>">Cancel</button>
        </form>
      <?php endif; ?>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/../footer.php'; ?>

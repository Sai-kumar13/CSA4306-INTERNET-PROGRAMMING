<?php
require __DIR__ . '/../config.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
$b = one(q("SELECT b.*, u.name AS guest FROM bookings b JOIN users u ON u.id = b.user_id WHERE b.id = ? AND b.status = 'Booked'", 'i', [$id]));
if (!$b) {
    header('Location: bookings.php');
    exit;
}

$types = rows(q("SELECT * FROM room_types ORDER BY price"));
$v = ['room_type_id' => (int)$b['room_type_id'], 'checkin' => $b['checkin'], 'checkout' => $b['checkout'],
      'rooms' => (int)$b['rooms'], 'guests' => (int)$b['guests']];
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v = ['room_type_id' => (int)($_POST['room_type_id'] ?? 0), 'checkin' => $_POST['checkin'] ?? '',
          'checkout' => $_POST['checkout'] ?? '', 'rooms' => (int)($_POST['rooms'] ?? 1),
          'guests' => (int)($_POST['guests'] ?? 1)];

    // Admin may use any dates (allow_past = true); the 3-day rule applies to guests only
    [$err, $total] = validate_booking($v['room_type_id'], $v['checkin'], $v['checkout'], $v['rooms'], $v['guests'], $id, true);
    if ($err === '') {
        q("UPDATE bookings SET room_type_id = ?, checkin = ?, checkout = ?, rooms = ?, guests = ?, total_amount = ? WHERE id = ?",
          'issiidi', [$v['room_type_id'], $v['checkin'], $v['checkout'], $v['rooms'], $v['guests'], $total, $id]);
        header('Location: bookings.php?updated=1');
        exit;
    }
}
include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<div class="card formbox">
  <h2>Edit Booking #<?= $id ?></h2>
  <p>Guest: <b><?= e($b['guest']) ?></b></p>
  <?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
  <form method="post">
    <?php $min_date = ''; include __DIR__ . '/../booking_fields.php'; ?>
    <button type="submit">Save Changes</button>
    <a class="btn btn-gray" href="bookings.php">Back</a>
  </form>
</div>
<?php include __DIR__ . '/../footer.php'; ?>

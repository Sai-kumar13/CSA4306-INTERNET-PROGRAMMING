<div class="card">
  <b>Admin:</b>
  <a href="<?= BASE ?>/admin/index.php">Dashboard</a> |
  <a href="<?= BASE ?>/admin/rooms.php">Room Price &amp; Quantity</a> |
  <a href="<?= BASE ?>/admin/bookings.php">Bookings</a> |
  <a href="<?= BASE ?>/admin/pages.php">Static Pages</a> |
  <a href="<?= BASE ?>/admin/users.php">Users</a>
</div>

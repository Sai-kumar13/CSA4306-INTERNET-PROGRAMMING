<?php
require __DIR__ . '/../config.php';
require_admin();

$slug = $_GET['slug'] ?? '';
$p = one(q("SELECT * FROM pages WHERE slug = ?", 's', [$slug]));
if (!$p) {
    header('Location: pages.php');
    exit;
}

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if ($title === '' || $content === '') {
        $err = 'Title and content are required.';
    } else {
        q("UPDATE pages SET title = ?, content = ? WHERE slug = ?", 'sss', [$title, $content, $slug]);
        header('Location: pages.php?saved=1');
        exit;
    }
    $p['title'] = $title;
    $p['content'] = $content;
}
include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<div class="card">
  <h2>Edit Page</h2>
  <?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
  <form method="post">
    Title<input name="title" value="<?= e($p['title']) ?>" required>
    Content (plain text, line breaks are kept)
    <textarea name="content" rows="16" required><?= e($p['content']) ?></textarea>
    <button type="submit">Save Page</button>
    <a class="btn btn-gray" href="pages.php">Back</a>
  </form>
</div>
<?php include __DIR__ . '/../footer.php'; ?>

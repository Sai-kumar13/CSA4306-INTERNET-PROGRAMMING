<?php
require __DIR__ . '/../config.php';
require_admin();

$stats = [
    'Registered users' => one(q("SELECT COUNT(*) c FROM users WHERE role = 'user'"))['c'],
    'Active bookings'  => one(q("SELECT COUNT(*) c FROM bookings WHERE status = 'Booked'"))['c'],
    'Cancelled bookings' => one(q("SELECT COUNT(*) c FROM bookings WHERE status = 'Cancelled'"))['c'],
    'Total rooms'      => one(q("SELECT COALESCE(SUM(quantity), 0) c FROM room_types"))['c'],
];

include __DIR__ . '/../header.php';
include __DIR__ . '/_menu.php';
?>
<h2>Admin Dashboard</h2>
<div class="grid2">
  <?php foreach ($stats as $label => $n): ?>
    <div class="card"><h2><?= (int)$n ?></h2><?= e($label) ?></div>
  <?php endforeach; ?>
</div>
<?php include __DIR__ . '/../footer.php'; ?>

<?php
require __DIR__ . '/config.php';
require_login();

$uid = $_SESSION['user']['id'];
$u = one(q("SELECT * FROM users WHERE id = ?", 'i', [$uid]));
$err = $ok = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = 'Enter your name and a valid email.';
    } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $err = 'Enter a valid 10 digit phone number.';
    } elseif ($pass !== '' && strlen($pass) < 6) {
        $err = 'New password must be at least 6 characters.';
    } elseif (one(q("SELECT id FROM users WHERE email = ? AND id <> ?", 'si', [$email, $uid]))) {
        $err = 'This email is used by another account.';
    } else {
        q("UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?", 'sssi', [$name, $email, $phone, $uid]);
        if ($pass !== '') {
            q("UPDATE users SET password = ? WHERE id = ?", 'si', [password_hash($pass, PASSWORD_DEFAULT), $uid]);
        }
        $_SESSION['user']['name'] = $name;
        $ok = 'Profile updated.';
    }
    $u['name'] = $name; $u['email'] = $email; $u['phone'] = $phone;
}
include __DIR__ . '/header.php';
?>
<div class="card formbox">
  <h2>My Profile</h2>
  <?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
  <?php if ($ok): ?><div class="msg ok"><?= e($ok) ?></div><?php endif; ?>
  <form method="post">
    Name<input name="name" value="<?= e($u['name']) ?>" required>
    Email<input type="email" name="email" value="<?= e($u['email']) ?>" required>
    Phone (10 digits)<input name="phone" maxlength="10" value="<?= e($u['phone']) ?>" required>
    New password (leave empty to keep current)<input type="password" name="password">
    <button type="submit">Update Profile</button>
  </form>
</div>
<?php include __DIR__ . '/footer.php'; ?>

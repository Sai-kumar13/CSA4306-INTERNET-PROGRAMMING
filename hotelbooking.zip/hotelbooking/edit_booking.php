<?php
require __DIR__ . '/config.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
$b = one(q("SELECT * FROM bookings WHERE id = ? AND user_id = ? AND status = 'Booked'", 'ii', [$id, $_SESSION['user']['id']]));
if (!$b) {
    header('Location: my_bookings.php');
    exit;
}
// Rule: changes allowed only up to 3 days before arrival
if (!can_change($b['checkin'])) {
    header('Location: my_bookings.php?late=1');
    exit;
}

$types = rows(q("SELECT * FROM room_types ORDER BY price"));
$v = ['room_type_id' => (int)$b['room_type_id'], 'checkin' => $b['checkin'], 'checkout' => $b['checkout'],
      'rooms' => (int)$b['rooms'], 'guests' => (int)$b['guests']];
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v = ['room_type_id' => (int)($_POST['room_type_id'] ?? 0), 'checkin' => $_POST['checkin'] ?? '',
          'checkout' => $_POST['checkout'] ?? '', 'rooms' => (int)($_POST['rooms'] ?? 1),
          'guests' => (int)($_POST['guests'] ?? 1)];

    [$err, $total] = validate_booking($v['room_type_id'], $v['checkin'], $v['checkout'], $v['rooms'], $v['guests'], $id);
    if ($err === '') {
        q("UPDATE bookings SET room_type_id = ?, checkin = ?, checkout = ?, rooms = ?, guests = ?, total_amount = ? WHERE id = ?",
          'issiidi', [$v['room_type_id'], $v['checkin'], $v['checkout'], $v['rooms'], $v['guests'], $total, $id]);
        header('Location: my_bookings.php?updated=1');
        exit;
    }
}
include __DIR__ . '/header.php';
?>
<div class="card formbox">
  <h2>Change Booking #<?= $id ?></h2>
  <?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
  <form method="post">
    <?php $min_date = date('Y-m-d'); include __DIR__ . '/booking_fields.php'; ?>
    <button type="submit">Save Changes</button>
    <a class="btn btn-gray" href="my_bookings.php">Back</a>
  </form>
</div>
<?php include __DIR__ . '/footer.php'; ?>

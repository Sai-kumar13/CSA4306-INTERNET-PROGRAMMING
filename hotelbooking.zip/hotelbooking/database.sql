-- Import this file in phpMyAdmin (Import tab). WARNING: re-importing resets all data.
CREATE DATABASE IF NOT EXISTS hotelbooking;
USE hotelbooking;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS bookings, pages, room_types, users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  phone VARCHAR(15) NOT NULL DEFAULT '',
  password VARCHAR(255) NOT NULL,
  role ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE room_types (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  capacity INT NOT NULL,
  price DECIMAL(8,2) NOT NULL,
  quantity INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  room_type_id INT NOT NULL,
  checkin DATE NOT NULL,
  checkout DATE NOT NULL,
  rooms INT NOT NULL,
  guests INT NOT NULL,
  total_amount DECIMAL(9,2) NOT NULL,
  status ENUM('Booked','Cancelled') NOT NULL DEFAULT 'Booked',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (room_type_id) REFERENCES room_types(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE pages (
  slug VARCHAR(30) PRIMARY KEY,
  title VARCHAR(100) NOT NULL,
  content TEXT NOT NULL,
  sort INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- Admin login: admin@grandstay.com / admin123
INSERT INTO users (name, email, phone, password, role) VALUES
('Admin', 'admin@grandstay.com', '', '$2y$10$MUL5X1ossjEgl7UcBkmmMu9pa6yvdxcV2B3b0pv9CTDkYbUZ1kBqe', 'admin');

INSERT INTO room_types (name, capacity, price, quantity) VALUES
('Single Room', 1, 1500.00, 10),
('Double Room', 2, 2500.00, 10),
('Deluxe Room', 3, 3800.00, 6),
('Suite', 4, 6000.00, 3);

INSERT INTO pages (slug, title, content, sort) VALUES
('rooms', 'Rooms', 'We offer four types of rooms. All rooms have free Wi-Fi, air conditioning, TV and daily housekeeping.

Single Room: a cosy room with one single bed, suitable for one guest.
Double Room: a comfortable room with a double bed, suitable for two guests.
Deluxe Room: a spacious room with a king bed and a sofa, suitable for three guests, with city view.
Suite: our largest room with a bedroom, living area and mini bar, suitable for four guests.

Check-in time is 12:00 noon and check-out time is 11:00 AM.', 1),
('about', 'About Us', 'Grand Stay Hotel has been welcoming guests since 2005. Our hotel is located in the heart of the city, close to the railway station, shopping areas and tourist spots.

Our aim is to give every guest a clean, comfortable and affordable stay with friendly service.', 2),
('contact', 'Contact Us', 'Grand Stay Hotel
12 Lake View Road, Chennai, Tamil Nadu, India

Phone: +91 44 1234 5678
Email: info@grandstay.example

Reception is open 24 hours a day.', 3),
('qa', 'Customer Service Q&A', 'Q: What are the check-in and check-out times?
A: Check-in is from 12:00 noon and check-out is until 11:00 AM.

Q: Can I change or cancel my booking?
A: Yes. You can change or cancel your booking online up to 3 days before the arrival date. For later changes please contact the hotel.

Q: Is breakfast included?
A: A complimentary breakfast is included with all room types.

Q: Is parking available?
A: Yes, free parking is available for hotel guests.

Q: Do you allow pets?
A: Sorry, pets are not allowed in the hotel.', 4),
('guide', 'Local Travel and Shipping Guide', 'LOCAL TRAVEL
Airport: about 20 km from the hotel (approx. 40 minutes by taxi).
Railway station: 3 km from the hotel, auto-rickshaws and taxis are always available.
Local buses and metro stops are within 500 metres of the hotel.

Nearby places to visit: Marina Beach, Kapaleeshwarar Temple, Government Museum and Fort St. George.

SHIPPING GUIDE
Guests may send parcels to the hotel before arrival. Please write the guest name and booking number on the parcel and send it to the hotel address. The reception will keep it safely until you arrive. For sending items from the hotel, the reception can arrange courier services at your cost.', 5),
('privacy', 'Privacy Policy', 'We collect your name, email address and phone number only to manage your bookings and to contact you about your stay.

We do not sell or share your personal information with third parties, except where required by law.

You can view and update your details at any time from your Profile page. For any privacy questions please contact us using the Contact Us page.', 6);

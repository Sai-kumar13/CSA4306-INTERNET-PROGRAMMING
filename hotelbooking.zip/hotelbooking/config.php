<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

define('BASE', '/hotelbooking');   // folder name inside htdocs

mysqli_report(MYSQLI_REPORT_OFF);
$conn = @mysqli_connect('localhost', 'root', '', 'hotelbooking');
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error() .
        '<br><br>Fix: start MySQL in XAMPP, open http://localhost/phpmyadmin and import database.sql (Import tab).');
}
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
mysqli_set_charset($conn, 'utf8mb4');

// Escape output
function e($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// Run a prepared query. SELECT returns a result, other queries return true.
function q($sql, $types = '', $params = []) {
    global $conn;
    $st = mysqli_prepare($conn, $sql);
    if ($types !== '') {
        mysqli_stmt_bind_param($st, $types, ...$params);
    }
    mysqli_stmt_execute($st);
    $res = mysqli_stmt_get_result($st);
    return $res ? $res : true;
}

function rows($res) { return mysqli_fetch_all($res, MYSQLI_ASSOC); }
function one($res)  { return mysqli_fetch_assoc($res); }

function require_login() {
    if (!isset($_SESSION['user'])) {
        header('Location: ' . BASE . '/login.php');
        exit;
    }
}

function require_admin() {
    require_login();
    if ($_SESSION['user']['role'] !== 'admin') {
        header('Location: ' . BASE . '/index.php');
        exit;
    }
}

// ---------- Booking helpers ----------

function nights($in, $out) {
    return (int)round((strtotime($out) - strtotime($in)) / 86400);
}

// Returns an error message, or '' if the dates are fine
function check_dates($in, $out, $allow_past = false) {
    $a = DateTime::createFromFormat('Y-m-d', $in);
    $b = DateTime::createFromFormat('Y-m-d', $out);
    if (!$a || !$b || $a->format('Y-m-d') !== $in || $b->format('Y-m-d') !== $out) {
        return 'Please select valid check-in and check-out dates.';
    }
    if (!$allow_past && $in < date('Y-m-d')) {
        return 'Check-in date cannot be in the past.';
    }
    if ($out <= $in) {
        return 'Check-out date must be after check-in date.';
    }
    if (nights($in, $out) > 30) {
        return 'Maximum stay is 30 nights.';
    }
    return '';
}

// Number of rooms of a type free on every night between $in (inclusive) and $out (exclusive).
// $exclude = booking id to ignore (used when editing a booking).
function rooms_left($type_id, $in, $out, $exclude = 0) {
    $t = one(q("SELECT quantity FROM room_types WHERE id = ?", 'i', [$type_id]));
    if (!$t) {
        return 0;
    }
    $left = (int)$t['quantity'];
    $d = strtotime($in);
    $end = strtotime($out);
    while ($d < $end) {
        $day = date('Y-m-d', $d);
        $r = one(q("SELECT COALESCE(SUM(rooms), 0) AS s FROM bookings
                    WHERE room_type_id = ? AND status = 'Booked' AND id <> ? AND checkin <= ? AND checkout > ?",
                   'iiss', [$type_id, $exclude, $day, $day]));
        $left = min($left, (int)$t['quantity'] - (int)$r['s']);
        $d = strtotime('+1 day', $d);
    }
    return max(0, $left);
}

// Validate booking input. Returns [error message, total price].
function validate_booking($type_id, $in, $out, $rooms, $guests, $exclude = 0, $allow_past = false) {
    $t = one(q("SELECT * FROM room_types WHERE id = ?", 'i', [$type_id]));
    if (!$t) {
        return ['Please select a room type.', 0];
    }
    $err = check_dates($in, $out, $allow_past);
    if ($err !== '') {
        return [$err, 0];
    }
    if ($rooms < 1 || $rooms > 5) {
        return ['Number of rooms must be between 1 and 5.', 0];
    }
    $max = $t['capacity'] * $rooms;
    if ($guests < 1 || $guests > $max) {
        return ['This room type allows at most ' . $max . ' guest(s) for ' . $rooms . ' room(s).', 0];
    }
    $left = rooms_left($type_id, $in, $out, $exclude);
    if ($rooms > $left) {
        return ["Only $left room(s) of this type are available for these dates.", 0];
    }
    return ['', $t['price'] * nights($in, $out) * $rooms];
}

// A booking can be changed or cancelled only up to 3 days before arrival
function can_change($checkin) {
    return $checkin >= date('Y-m-d', strtotime('+3 days'));
}

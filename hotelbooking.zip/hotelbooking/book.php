<?php
require __DIR__ . '/config.php';
require_login();

$types = rows(q("SELECT * FROM room_types ORDER BY price"));
$v = ['room_type_id' => (int)($_GET['type'] ?? 0), 'checkin' => $_GET['checkin'] ?? '',
      'checkout' => $_GET['checkout'] ?? '', 'rooms' => 1, 'guests' => 1];
$err = $ok = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v = ['room_type_id' => (int)($_POST['room_type_id'] ?? 0), 'checkin' => $_POST['checkin'] ?? '',
          'checkout' => $_POST['checkout'] ?? '', 'rooms' => (int)($_POST['rooms'] ?? 1),
          'guests' => (int)($_POST['guests'] ?? 1)];

    [$err, $total] = validate_booking($v['room_type_id'], $v['checkin'], $v['checkout'], $v['rooms'], $v['guests']);

    if ($err === '') {
        if (isset($_POST['check'])) {
            $left = rooms_left($v['room_type_id'], $v['checkin'], $v['checkout']);
            $ok = "Available! $left room(s) of this type are free for these dates. Your total would be Rs. $total.";
        } else {
            q("INSERT INTO bookings (user_id, room_type_id, checkin, checkout, rooms, guests, total_amount)
               VALUES (?, ?, ?, ?, ?, ?, ?)", 'iissiid',
              [$_SESSION['user']['id'], $v['room_type_id'], $v['checkin'], $v['checkout'], $v['rooms'], $v['guests'], $total]);
            $id = mysqli_insert_id($conn);

            // Confirmation email (works only if mail is configured in XAMPP)
            $u = one(q("SELECT name, email FROM users WHERE id = ?", 'i', [$_SESSION['user']['id']]));
            $t = one(q("SELECT name FROM room_types WHERE id = ?", 'i', [$v['room_type_id']]));
            $body = "Hello {$u['name']},\n\nYour booking #$id is confirmed.\n"
                  . "Room: {$t['name']} x {$v['rooms']}\nCheck-in: {$v['checkin']}\nCheck-out: {$v['checkout']}\n"
                  . "Guests: {$v['guests']}\nTotal: Rs. $total\n\nThank you for choosing Grand Stay Hotel.";
            @mail($u['email'], "Booking Confirmation #$id", $body, 'From: noreply@grandstay.example');

            header('Location: my_bookings.php?booked=' . $id);
            exit;
        }
    }
}
include __DIR__ . '/header.php';
?>
<div class="card formbox">
  <h2>Book a Room</h2>
  <?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
  <?php if ($ok): ?><div class="msg ok"><?= e($ok) ?></div><?php endif; ?>
  <form method="post">
    <?php $min_date = date('Y-m-d'); include __DIR__ . '/booking_fields.php'; ?>
    <button type="submit" name="check" value="1" class="btn-gray">Check Availability</button>
    <button type="submit">Confirm Booking</button>
  </form>
</div>
<?php include __DIR__ . '/footer.php'; ?>

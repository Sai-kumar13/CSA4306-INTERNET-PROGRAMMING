<?php require_once __DIR__ . '/config.php'; ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Grand Stay Hotel</title>
<link rel="stylesheet" href="<?= BASE ?>/style.css">
</head>
<body>
<header>
  <div class="wrap nav">
    <a class="logo" href="<?= BASE ?>/index.php">&#127976; Grand Stay Hotel</a>
    <nav>
      <a href="<?= BASE ?>/index.php">Home</a>
      <?php if (isset($_SESSION['user'])): ?>
        <?php if ($_SESSION['user']['role'] === 'admin'): ?>
          <a href="<?= BASE ?>/admin/index.php">Admin Panel</a>
        <?php else: ?>
          <a href="<?= BASE ?>/my_bookings.php">My Bookings</a>
          <a href="<?= BASE ?>/profile.php">Profile</a>
        <?php endif; ?>
        <a href="<?= BASE ?>/logout.php">Logout (<?= e($_SESSION['user']['name']) ?>)</a>
      <?php else: ?>
        <a href="<?= BASE ?>/login.php">Login</a>
        <a href="<?= BASE ?>/register.php">Register</a>
      <?php endif; ?>
    </nav>
  </div>
  <div class="subnav">
    <div class="wrap">
      <a href="<?= BASE ?>/page.php?slug=rooms">Rooms</a>
      <a href="<?= BASE ?>/page.php?slug=about">About Us</a>
      <a href="<?= BASE ?>/page.php?slug=contact">Contact Us</a>
      <a href="<?= BASE ?>/page.php?slug=qa">Customer Service Q&amp;A</a>
      <a href="<?= BASE ?>/page.php?slug=guide">Travel &amp; Shipping Guide</a>
      <a href="<?= BASE ?>/page.php?slug=privacy">Privacy Policy</a>
    </div>
  </div>
</header>
<main><div class="wrap">

<?php
require __DIR__ . '/config.php';

$slug = $_GET['slug'] ?? '';
$p = one(q("SELECT * FROM pages WHERE slug = ?", 's', [$slug]));
if (!$p) {
    header('Location: index.php');
    exit;
}
$types = $slug === 'rooms' ? rows(q("SELECT * FROM room_types ORDER BY price")) : [];

include __DIR__ . '/header.php';
?>
<div class="card">
  <h2><?= e($p['title']) ?></h2>
  <?= nl2br(e($p['content'])) ?>
  <?php if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin'): ?>
    <p><a class="btn small" href="<?= BASE ?>/admin/page_edit.php?slug=<?= e($slug) ?>">Edit this page</a></p>
  <?php endif; ?>
</div>

<?php if ($types): ?>
<div class="table-wrap">
<table>
  <tr><th>Room type</th><th>Guests / room</th><th>Price / night</th></tr>
  <?php foreach ($types as $t): ?>
    <tr><td><?= e($t['name']) ?></td><td><?= (int)$t['capacity'] ?></td><td>Rs. <?= e($t['price']) ?></td></tr>
  <?php endforeach; ?>
</table>
</div>
<a class="btn" href="index.php">Check Availability</a>
<?php endif; ?>
<?php include __DIR__ . '/footer.php'; ?>

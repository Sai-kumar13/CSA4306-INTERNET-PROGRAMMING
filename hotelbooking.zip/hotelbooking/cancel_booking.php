<?php
require __DIR__ . '/config.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $b = one(q("SELECT * FROM bookings WHERE id = ? AND user_id = ? AND status = 'Booked'", 'ii', [$id, $_SESSION['user']['id']]));
    if ($b) {
        // Rule: cancellation allowed only up to 3 days before arrival
        if (!can_change($b['checkin'])) {
            header('Location: my_bookings.php?late=1');
            exit;
        }
        q("UPDATE bookings SET status = 'Cancelled' WHERE id = ?", 'i', [$id]);
        header('Location: my_bookings.php?cancelled=1');
        exit;
    }
}
header('Location: my_bookings.php');
exit;

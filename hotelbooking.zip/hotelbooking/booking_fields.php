<?php
// Shared booking form fields. Needs: $types (room types), $v (values), $min_date ('' for no minimum)
?>
Room type
<select name="room_type_id" required>
  <option value="">-- select --</option>
  <?php foreach ($types as $t): ?>
    <option value="<?= (int)$t['id'] ?>" <?= (int)$v['room_type_id'] === (int)$t['id'] ? 'selected' : '' ?>>
      <?= e($t['name']) ?> (max <?= (int)$t['capacity'] ?> guest/room) - Rs. <?= e($t['price']) ?> per night
    </option>
  <?php endforeach; ?>
</select>
Check-in date
<input type="date" name="checkin" value="<?= e($v['checkin']) ?>" <?= $min_date ? 'min="' . e($min_date) . '"' : '' ?> required>
Check-out date
<input type="date" name="checkout" value="<?= e($v['checkout']) ?>" <?= $min_date ? 'min="' . e($min_date) . '"' : '' ?> required>
Number of rooms
<input type="number" name="rooms" min="1" max="5" value="<?= (int)$v['rooms'] ?>" required>
Number of guests
<input type="number" name="guests" min="1" value="<?= (int)$v['guests'] ?>" required>

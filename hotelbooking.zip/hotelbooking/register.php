<?php
require __DIR__ . '/config.php';

$err = '';
$name = $email = $phone = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = 'Enter your name and a valid email.';
    } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $err = 'Enter a valid 10 digit phone number.';
    } elseif (strlen($pass) < 6) {
        $err = 'Password must be at least 6 characters.';
    } elseif (one(q("SELECT id FROM users WHERE email = ?", 's', [$email]))) {
        $err = 'This email is already registered.';
    } else {
        q("INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)", 'ssss',
          [$name, $email, $phone, password_hash($pass, PASSWORD_DEFAULT)]);
        header('Location: login.php?registered=1');
        exit;
    }
}
include __DIR__ . '/header.php';
?>
<div class="card formbox">
  <h2>Register</h2>
  <?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
  <form method="post">
    Name<input name="name" value="<?= e($name) ?>" required>
    Email<input type="email" name="email" value="<?= e($email) ?>" required>
    Phone (10 digits)<input name="phone" maxlength="10" value="<?= e($phone) ?>" required>
    Password<input type="password" name="password" required>
    <button type="submit">Register</button>
  </form>
  <p>Already registered? <a href="login.php">Login</a></p>
</div>
<?php include __DIR__ . '/footer.php'; ?>

HOTEL ROOM BOOKING SYSTEM  (PHP + MySQL, XAMPP)
================================================

SETUP
1. Start Apache and MySQL in the XAMPP Control Panel.
2. Copy the "hotelbooking" folder into  C:\xampp\htdocs\
3. Open http://localhost/phpmyadmin -> Import tab -> choose database.sql -> Go.
   (This creates the database "hotelbooking" with tables and sample data.)
4. Open http://localhost/hotelbooking/

LOGINS
  Admin : admin@grandstay.com / admin123
  User  : click Register to create one.

USER FUNCTIONS
  1. Register, view / modify profile ............ register.php, profile.php
  2. Book a room for specific dates ............. book.php
  3. Booking history ............................ my_bookings.php
  4. Change booking (up to 3 days before) ....... edit_booking.php
  5. Cancel booking (up to 3 days before) ....... cancel_booking.php
  6. Check room availability .................... index.php (and book.php)

ADMIN FUNCTIONS  (admin/ folder)
  7. Change quantity and price of 4 room types .. admin/rooms.php
  8. Change any booking details ................. admin/booking_edit.php
  9. Cancel any booking ......................... admin/bookings.php
 10. Edit static pages .......................... admin/pages.php
     (rooms, about us, contact us, customer service Q&A, travel and shipping guide, privacy policy)
 11. The static pages are shown to everyone from the menu bar (page.php).

NOTES
  * Rooms are counted night by night, so availability is exact for any date range.
  * A booking can be changed or cancelled by the guest only if check-in is at least
    3 days away. Admin can change or cancel any booking.
  * Confirmation email uses PHP mail(), which needs mail setup in XAMPP. Without it
    the booking still works.
  * If you rename the folder, change BASE in config.php.
  * Re-importing database.sql resets all data.

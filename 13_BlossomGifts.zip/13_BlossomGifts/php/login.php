<?php
session_start();
include 'config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $conn) {
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';
    $stmt = $conn->prepare('SELECT id, password, role FROM users WHERE username = ?');
    $stmt->bind_param('s', $u);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if ($row && password_verify($p, $row['password'])) {
        $_SESSION['uid'] = $row['id'];
        $_SESSION['role'] = $row['role'];
        header('Location: dashboard.php');
        exit;
    }
    $msg = 'Invalid username or password';
}
?>
<!DOCTYPE html>
<html><head><title>BlossomGifts Login</title></head>
<body>
<h2>Login</h2>
<form method="post">
  <input name="username" placeholder="Username">
  <input name="password" type="password" placeholder="Password">
  <button>Login</button>
</form>
<p><?php echo $msg ?? ''; ?></p>
</body></html>

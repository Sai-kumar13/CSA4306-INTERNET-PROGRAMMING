CREATE DATABASE IF NOT EXISTS blossomgifts_db;
USE blossomgifts_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80),
  mobile VARCHAR(15),
  email VARCHAR(80),
  username VARCHAR(40),
  password VARCHAR(255),
  role VARCHAR(20) DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT,
  name VARCHAR(100),
  price INT
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  item_id INT,
  delivery_date DATE,
  status VARCHAR(20)
);

INSERT INTO users (name, mobile, email, username, password, role) VALUES ('Admin', '9840012345', 'admin@example.in', 'admin', '$2y$10$abcdefghijklmnopqrstuv', 'admin');

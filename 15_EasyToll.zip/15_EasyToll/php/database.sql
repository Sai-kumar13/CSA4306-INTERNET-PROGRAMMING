CREATE DATABASE IF NOT EXISTS easytoll_db;
USE easytoll_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80),
  mobile VARCHAR(15),
  email VARCHAR(80),
  username VARCHAR(40),
  password VARCHAR(255),
  role VARCHAR(20) DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS passes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  vehicle_no VARCHAR(20),
  type VARCHAR(30),
  valid_till DATE,
  status VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS wallet (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  balance INT
);

CREATE TABLE IF NOT EXISTS toll_gates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80),
  location VARCHAR(80),
  fee INT
);

INSERT INTO users (name, mobile, email, username, password, role) VALUES ('Admin', '9840012345', 'admin@example.in', 'admin', '$2y$10$abcdefghijklmnopqrstuv', 'admin');

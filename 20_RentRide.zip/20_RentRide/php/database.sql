CREATE DATABASE IF NOT EXISTS rentride_db;
USE rentride_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80),
  mobile VARCHAR(15),
  email VARCHAR(80),
  username VARCHAR(40),
  password VARCHAR(255),
  role VARCHAR(20) DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS vehicles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80),
  type VARCHAR(30),
  price_per_day INT,
  available TINYINT
);

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  vehicle_id INT,
  start_date DATE,
  days INT,
  status VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  vehicle_id INT,
  comment TEXT
);

INSERT INTO users (name, mobile, email, username, password, role) VALUES ('Admin', '9840012345', 'admin@example.in', 'admin', '$2y$10$abcdefghijklmnopqrstuv', 'admin');

<?php
// Database settings for XAMPP
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'rentride_db';
$conn = @mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    $conn = null; // site still works without the database
}
?>

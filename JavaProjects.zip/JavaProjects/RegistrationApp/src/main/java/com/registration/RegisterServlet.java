
package com.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.mindrot.jbcrypt.BCrypt;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private static final String URL =
            "jdbc:mysql://localhost:3306/registrationdb";

    private static final String USER = "root";
    private static final String PASSWORD = "root";

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String username = request.getParameter("userName");
        String password = request.getParameter("userPass");
        String email = request.getParameter("userEmail");
        String country = request.getParameter("userCountry");

        String sql = "INSERT INTO registeruser "
                   + "(username, password, email, country) "
                   + "VALUES (?, ?, ?, ?)";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Hash the password before storing it
            String hashedPassword = BCrypt.hashpw(
                    password, BCrypt.gensalt(12));

            try (Connection con = DriverManager.getConnection(
                    URL, USER, PASSWORD);
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, username);
                ps.setString(2, hashedPassword);
                ps.setString(3, email);
                ps.setString(4, country);

                int result = ps.executeUpdate();

                if (result > 0) {
                    response.getWriter().println(
                        "<h2>Registration Successful!</h2>");
                    response.getWriter().println(
                        "<p>Welcome, " + escapeHtml(username) + "!</p>");
                    response.getWriter().println(
                        "<a href='index.html'>Register Another User</a>");
                } else {
                    response.sendError(
                        HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                        "Registration failed.");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();

            response.setStatus(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR);

            response.getWriter().println(
                "<h2>Registration Failed</h2>");
            response.getWriter().println(
                "<p>Please check the server configuration.</p>");
        }
    }

    private String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}

<?php
require 'includes/init.php';
require_student();
$page_title = 'My Fines'; $active = 'fines';
$rows = db_all("SELECT i.*, b.title FROM issues i JOIN books b ON b.id=i.book_id WHERE i.user_id=? ORDER BY i.issue_date DESC", 'i', [$_SESSION['user_id']]);
$fines = array_values(array_filter($rows, fn($r) => fine_total($r) > 0));
$due = array_sum(array_map('fine_due', $rows));
$paid = array_sum(array_map(fn($r) => (float)$r['fine_paid'], $rows));
$pays = db_all("SELECT p.*, b.title FROM payments p JOIN issues i ON i.id=p.issue_id JOIN books b ON b.id=i.book_id WHERE p.user_id=? ORDER BY p.id DESC", 'i', [$_SESSION['user_id']]);
include 'includes/header.php';
?>
<div class="wrap">
  <div class="page-head"><h1>Check Fine</h1><p>Late books cost ₹<?= FINE_PER_DAY ?> per day after the expiry date. Fines on books you still hold keep growing until you return them.</p></div>
  <div class="fine-hero">
    <div><div class="muted">Total fine due</div><div class="amt <?= $due > 0 ? '' : 'zero' ?>"><?= money($due) ?></div><div class="muted small">Already paid: <?= money($paid) ?></div></div>
    <?php if ($due > 0): ?><a class="btn btn-accent btn-lg" href="<?= url('pay.php?all=1') ?>">Pay <?= money($due) ?> now</a><?php else: ?><span class="badge b-ok" style="font-size:1rem;padding:10px 18px">✓ You're all clear</span><?php endif; ?>
  </div>
  <h3>Fine details</h3>
  <?php if (!$fines): ?><div class="empty"><div class="big">🎉</div>No fines on your account.</div><?php else: ?>
  <div class="table-wrap mb"><table>
    <thead><tr><th>Book</th><th>Expiry date</th><th>Returned</th><th>Reason</th><th>Total</th><th>Due</th><th></th></tr></thead><tbody>
    <?php foreach ($fines as $r): $d = overdue_days($r); ?>
    <tr><td><b><?= e($r['title']) ?></b></td><td><?= fmt_date($r['due_date']) ?></td><td><?= $r['status'] === 'Returned' ? fmt_date($r['return_date']) : '<span class="badge b-bad">Not returned</span>' ?></td>
      <td class="small"><?= e($r['fine_note'] ?: '') ?><?= $d > 0 ? ' Overdue ' . $d . ' days × ₹' . FINE_PER_DAY : '' ?></td>
      <td><?= money(fine_total($r)) ?></td>
      <td><?= fine_due($r) > 0 ? '<b style="color:var(--bad)">' . money(fine_due($r)) . '</b>' : '<span class="badge b-ok">Paid</span>' ?></td>
      <td><?php if (fine_due($r) > 0): ?><a class="btn btn-sm" href="<?= url('pay.php?id=' . $r['id']) ?>">Pay</a><?php endif; ?></td></tr>
    <?php endforeach; ?></tbody></table></div>
  <?php endif; ?>
  <?php if ($pays): ?>
  <h3>Payment history</h3>
  <div class="table-wrap"><table><thead><tr><th>Receipt</th><th>Book</th><th>Method</th><th>Date</th><th>Amount</th></tr></thead><tbody>
    <?php foreach ($pays as $p): ?><tr><td><a href="<?= url('receipt.php?r=' . urlencode($p['receipt_no'])) ?>"><?= e($p['receipt_no']) ?></a></td><td><?= e($p['title']) ?></td><td><?= e($p['method']) ?></td><td><?= fmt_date($p['paid_at']) ?></td><td><?= money($p['amount']) ?></td></tr><?php endforeach; ?>
  </tbody></table></div><?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>

<?php
require 'includes/init.php';
require_student();
$page_title = 'Pay Fine'; $active = 'fines';
$uid = $_SESSION['user_id'];
$sql = "SELECT i.*, b.title FROM issues i JOIN books b ON b.id=i.book_id WHERE i.user_id=?";
$all = db_all($sql . " ORDER BY i.issue_date", 'i', [$uid]);
$id = (int)get('id', post('id'));
$items = array_values(array_filter($all, fn($r) => fine_due($r) > 0 && ($id === 0 || (int)$r['id'] === $id)));
if (!$items) { flash('Nothing to pay. Your fines are clear!', 'info'); redirect('fines.php'); }
$total = array_sum(array_map('fine_due', $items));

// DEMO PAYMENT: nothing is charged. Choosing a method + clicking Pay marks fines as paid.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $method = post('method', 'UPI');
    $receipt = 'RCPT-' . date('ymd') . '-' . rand(1000, 9999);
    foreach ($items as $r) {
        $amt = fine_due($r); $tot = fine_total($r);
        db_exec("UPDATE issues SET fine_amount=?, fine_paid=?, accrual_from=CURDATE() WHERE id=?", 'ddi', [$tot, $tot, $r['id']]);
        db_exec("INSERT INTO payments(receipt_no,user_id,issue_id,amount,method) VALUES(?,?,?,?,?)", 'siids', [$receipt, $uid, $r['id'], $amt, $method]);
    }
    redirect('receipt.php?r=' . urlencode($receipt));
}
include 'includes/header.php';
?>
<div class="overlay" id="overlay"><div><div class="spinner"></div><h3>Processing payment…</h3><p class="muted">Please wait a moment.</p></div></div>
<div class="wrap">
  <div class="page-head"><h1>Pay fine</h1><p>Choose a payment method and confirm.</p></div>
  <div class="pay-wrap">
    <form method="post" id="pay-form" class="panel">
      <input type="hidden" name="id" value="<?= $id ?>">
      <h3>Payment method</h3>
      <div class="methods">
        <label class="method"><input type="radio" name="method" value="UPI" checked><span class="m-ico">📱</span><span>UPI<small class="muted" style="display:block;font-weight:400">GPay, PhonePe, Paytm</small></span></label>
        <label class="method"><input type="radio" name="method" value="Card"><span class="m-ico">💳</span><span>Debit / Credit card<small class="muted" style="display:block;font-weight:400">Visa, Mastercard, RuPay</small></span></label>
        <label class="method"><input type="radio" name="method" value="Net Banking"><span class="m-ico">🏦</span><span>Net banking<small class="muted" style="display:block;font-weight:400">All major banks</small></span></label>
        <label class="method"><input type="radio" name="method" value="Cash at desk"><span class="m-ico">💵</span><span>Cash at library desk<small class="muted" style="display:block;font-weight:400">Pay at the issue counter</small></span></label>
      </div>
      <div class="mock-card" data-for="UPI">student@upi<small>Pay securely with your UPI app</small></div>
      <div class="mock-card" data-for="Card">•••• •••• •••• 4242<small>Pay securely with your card</small></div>
      <div class="mock-card" data-for="Net Banking">COLLEGE BANK · NETBANKING<small>Pay securely with your bank</small></div>
      <button class="btn btn-accent btn-lg btn-block">Pay <?= money($total) ?></button>
      <p class="small muted center mt" style="margin-bottom:0">🔒 Secure checkout</p>
    </form>
    <div class="panel">
      <h3>Order summary</h3>
      <?php foreach ($items as $r): ?><div class="sum-row"><span><?= e($r['title']) ?><span class="sub muted small" style="display:block"><?= overdue_days($r) ? overdue_days($r) . ' days overdue' : e($r['fine_note'] ?: 'Fine') ?></span></span><b><?= money(fine_due($r)) ?></b></div><?php endforeach; ?>
      <div class="sum-row total"><span>Total</span><span><?= money($total) ?></span></div>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>

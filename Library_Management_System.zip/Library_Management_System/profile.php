<?php
require 'includes/init.php';
require_student();
$page_title = 'My Profile'; $active = 'profile';
$u = current_user();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = post('name', $u['name']); if ($name === '') $name = $u['name'];
    $year = max(1, min(4, (int)post('year', $u['year']))); $sem = max(1, min(8, (int)post('semester', $u['semester'])));
    db_exec("UPDATE users SET name=?, email=?, phone=?, roll_no=?, department=?, year=?, semester=? WHERE id=?", 'sssssiii',
        [$name, post('email', $u['email']), post('phone'), post('roll_no', $u['roll_no']), post('department', $u['department']), $year, $sem, $u['id']]);
    $_SESSION['user_name'] = $name;
    flash('Profile updated.');
    redirect('profile.php');
}
$s = db_one("SELECT COUNT(*) total, SUM(status='Issued') active FROM issues WHERE user_id=?", 'i', [$u['id']]);
$depts = ['Computer Science', 'Electronics', 'Mechanical', 'Civil', 'Management'];
include 'includes/header.php';
?>
<div class="wrap">
  <div class="page-head"><h1>My Profile</h1><p>Keep your details up to date so the librarian can reach you.</p></div>
  <div class="grid g2" style="grid-template-columns:.8fr 1.2fr;align-items:start">
    <div class="panel center">
      <div class="logo-mark" style="width:90px;height:90px;font-size:2.4rem;margin:0 auto 14px;border-radius:50%"><?= e(strtoupper(substr($u['name'], 0, 1))) ?></div>
      <h3 style="margin-bottom:2px"><?= e($u['name']) ?></h3>
      <p class="muted"><?= e($u['email']) ?></p>
      <span class="chip">Library ID · LIB-<?= str_pad($u['id'], 4, '0', STR_PAD_LEFT) ?></span>
      <hr style="border:0;border-top:1px solid var(--line);margin:20px 0">
      <div class="grid g2"><div><b style="font:700 1.6rem var(--serif)"><?= (int)$s['total'] ?></b><div class="muted small">Books borrowed</div></div><div><b style="font:700 1.6rem var(--serif)"><?= (int)$s['active'] ?></b><div class="muted small">Currently held</div></div></div>
      <p class="small muted mt">Member since <?= fmt_date($u['created_at']) ?></p>
    </div>
    <form method="post" class="panel">
      <h3>Edit details</h3>
      <div class="form-grid">
        <div class="field"><label>Full name</label><input name="name" value="<?= e($u['name']) ?>"></div>
        <div class="field"><label>Email</label><input name="email" value="<?= e($u['email']) ?>"></div>
        <div class="field"><label>Roll number</label><input name="roll_no" value="<?= e($u['roll_no']) ?>"></div>
        <div class="field"><label>Phone</label><input name="phone" value="<?= e($u['phone']) ?>"></div>
        <div class="field"><label>Department</label><select name="department"><?php foreach ($depts as $d) echo '<option' . ($u['department'] === $d ? ' selected' : '') . '>' . e($d) . '</option>'; ?></select></div>
        <div class="field"><label>Year / Semester</label><div class="row" style="flex-wrap:nowrap">
          <select name="year"><?php for ($i = 1; $i <= 4; $i++) echo "<option value=$i" . ($u['year'] == $i ? ' selected' : '') . ">Year $i</option>"; ?></select>
          <select name="semester"><?php for ($i = 1; $i <= 8; $i++) echo "<option value=$i" . ($u['semester'] == $i ? ' selected' : '') . ">Sem $i</option>"; ?></select></div></div>
      </div>
      <button class="btn">Save changes</button>
    </form>
  </div>
</div>
<?php include 'includes/footer.php'; ?>

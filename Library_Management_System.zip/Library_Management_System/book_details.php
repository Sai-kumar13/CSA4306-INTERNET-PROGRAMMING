<?php
require 'includes/init.php';
$page_title = 'Book Details'; $active = 'books';
$b = db_one("SELECT * FROM books WHERE id=?", 'i', [(int)get('id')]);
$mine = null;
if ($b && is_student()) $mine = db_one("SELECT * FROM issues WHERE user_id=? AND book_id=? AND status='Issued'", 'ii', [$_SESSION['user_id'], $b['id']]);
$related = $b ? db_all("SELECT * FROM books WHERE category=? AND id<>? LIMIT 4", 'si', [$b['category'], $b['id']]) : [];
include 'includes/header.php';
?>
<div class="wrap section">
<?php if (!$b): ?>
  <div class="empty"><div class="big">🤷</div><h2>Book not found</h2><a class="btn" href="<?= url('books.php') ?>">Back to catalog</a></div>
<?php else: ?>
  <p class="small"><a href="<?= url('books.php') ?>">← Catalog</a> / <?= e($b['category']) ?></p>
  <div class="detail">
    <div><?= book_cover($b, true) ?></div>
    <div>
      <h1><?= e($b['title']) ?></h1>
      <p class="muted" style="font-size:1.1rem">by <?= e($b['author']) ?></p>
      <p><?= nl2br(e($b['description'])) ?></p>
      <dl>
        <dt>ISBN</dt><dd><?= e($b['isbn'] ?: '—') ?></dd>
        <dt>Category</dt><dd><span class="chip"><?= e($b['category']) ?></span></dd>
        <dt>Publisher</dt><dd><?= e($b['publisher'] ?: '—') ?> <?= $b['published_year'] ? '(' . (int)$b['published_year'] . ')' : '' ?></dd>
        <dt>Shelf location</dt><dd><?= e($b['shelf'] ?: '—') ?></dd>
        <dt>Availability</dt><dd><?= $b['available'] > 0 ? '<span class="badge b-ok">' . (int)$b['available'] . ' of ' . (int)$b['quantity'] . ' copies available</span>' : '<span class="badge b-bad">All copies issued</span>' ?></dd>
      </dl>
      <div class="row">
        <?php if ($mine): ?>
          <span class="badge b-info" style="padding:10px 16px">You have this book · due <?= fmt_date($mine['due_date']) ?></span>
          <a class="btn btn-ghost" href="<?= url('my_books.php') ?>">My books</a>
        <?php elseif ($b['available'] > 0): ?>
          <a class="btn btn-lg" href="<?= url('borrow.php?id=' . $b['id']) ?>">Borrow this book</a>
        <?php else: ?>
          <button class="btn btn-lg" disabled>Currently unavailable</button>
        <?php endif; ?>
      </div>
      <?php if (!is_student()): ?><p class="small muted mt">You'll be asked to sign in first (it only takes a click).</p><?php endif; ?>
    </div>
  </div>
  <?php if ($related): ?>
  <h2 class="mt" style="margin-top:48px">More in <?= e($b['category']) ?></h2>
  <div class="book-grid">
    <?php foreach ($related as $r): ?>
      <a class="book-card" href="<?= url('book_details.php?id=' . $r['id']) ?>" style="text-decoration:none;color:inherit"><?= book_cover($r) ?><div><h3><?= e($r['title']) ?></h3><p class="meta"><?= e($r['author']) ?></p></div></a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
<?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>

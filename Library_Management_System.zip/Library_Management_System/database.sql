-- Bookmark College Library: database
-- Import via phpMyAdmin, or just open the site: it auto-installs this file on first run.
CREATE DATABASE IF NOT EXISTS `bookmark_library` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `bookmark_library`;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS payments, messages, materials, issues, books, admins, users;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  phone VARCHAR(30) DEFAULT NULL,
  roll_no VARCHAR(40) DEFAULT NULL,
  department VARCHAR(80) DEFAULT NULL,
  year TINYINT DEFAULT 1,
  semester TINYINT DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  author VARCHAR(150) NOT NULL,
  isbn VARCHAR(30) DEFAULT NULL,
  category VARCHAR(80) DEFAULT 'General',
  publisher VARCHAR(120) DEFAULT NULL,
  published_year SMALLINT DEFAULT NULL,
  shelf VARCHAR(30) DEFAULT NULL,
  quantity INT NOT NULL DEFAULT 1,
  available INT NOT NULL DEFAULT 1,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS issues (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  book_id INT NOT NULL,
  issue_date DATE NOT NULL,
  due_date DATE NOT NULL,
  return_date DATE DEFAULT NULL,
  status ENUM('Issued','Returned') NOT NULL DEFAULT 'Issued',
  fine_amount DECIMAL(8,2) NOT NULL DEFAULT 0,
  fine_paid DECIMAL(8,2) NOT NULL DEFAULT 0,
  accrual_from DATE DEFAULT NULL,
  fine_note VARCHAR(200) DEFAULT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS materials (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  subject VARCHAR(120) NOT NULL,
  material_type VARCHAR(40) NOT NULL DEFAULT 'Notes',
  department VARCHAR(80) DEFAULT 'All Departments',
  year TINYINT NOT NULL DEFAULT 1,
  semester TINYINT NOT NULL DEFAULT 1,
  description TEXT,
  file_name VARCHAR(255) DEFAULT NULL,
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  receipt_no VARCHAR(30) NOT NULL,
  user_id INT NOT NULL,
  issue_id INT NOT NULL,
  amount DECIMAL(8,2) NOT NULL,
  method VARCHAR(30) NOT NULL,
  paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(150),
  subject VARCHAR(150),
  message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- Sample records ----------
INSERT INTO admins (name, username) VALUES ('Mrs. Kavita Rao (Librarian)', 'librarian');

INSERT INTO users (name,email,phone,roll_no,department,year,semester) VALUES
('Aarav Sharma','aarav.sharma@college.edu','9876500001','CSE2301','Computer Science',2,3),
('Diya Patel','diya.patel@college.edu','9876500002','ECE2302','Electronics',2,4),
('Rohan Mehta','rohan.mehta@college.edu','9876500003','ME2203','Mechanical',3,5),
('Sneha Iyer','sneha.iyer@college.edu','9876500004','CSE2404','Computer Science',1,2);

INSERT INTO books (title,author,isbn,category,publisher,published_year,shelf,quantity,available,description) VALUES
('Introduction to Algorithms','Thomas H. Cormen','9780262033848','Computer Science','MIT Press',2009,'CS-A1',5,3,'The standard reference on algorithms: sorting, graph algorithms, dynamic programming and complexity, with rigorous analysis.'),
('Clean Code','Robert C. Martin','9780132350884','Computer Science','Prentice Hall',2008,'CS-A2',4,3,'A handbook of agile software craftsmanship. Learn to write readable, maintainable code and refactor with confidence.'),
('Database System Concepts','Abraham Silberschatz','9780078022159','Computer Science','McGraw-Hill',2019,'CS-B1',3,3,'Covers relational model, SQL, transactions, indexing and modern storage systems for undergraduate courses.'),
('Operating System Concepts','Abraham Silberschatz','9781118063330','Computer Science','Wiley',2018,'CS-B2',4,3,'Processes, threads, scheduling, memory management, file systems and security explained with real-world examples.'),
('Computer Networks','Andrew S. Tanenbaum','9780132126953','Computer Science','Pearson',2010,'CS-B3',3,3,'A layered approach to networking, from the physical layer up to applications and the Internet.'),
('Higher Engineering Mathematics','B. S. Grewal','9788174091955','Mathematics','Khanna Publishers',2017,'MA-A1',6,6,'Comprehensive coverage of calculus, differential equations, Fourier series and numerical methods for engineers.'),
('Linear Algebra and Its Applications','Gilbert Strang','9780030105678','Mathematics','Cengage',2006,'MA-A2',3,3,'An intuitive and application-rich introduction to vector spaces, eigenvalues and matrix factorizations.'),
('Concepts of Physics','H. C. Verma','9788177091878','Physics','Bharati Bhawan',2015,'PH-A1',4,3,'Classic problem-driven text on mechanics, waves, optics, electricity and modern physics.'),
('Fundamentals of Physics','Halliday & Resnick','9781118230718','Physics','Wiley',2013,'PH-A2',3,3,'Clear explanations with worked examples across all fundamental areas of physics.'),
('Organic Chemistry','Morrison & Boyd','9780136436690','Chemistry','Pearson',2011,'CH-A1',3,2,'Mechanisms, reactions and synthesis presented with a strong focus on understanding rather than memorizing.'),
('Principles of Management','Harold Koontz','9780070140264','Management','McGraw-Hill',2010,'MG-A1',4,4,'Planning, organizing, leading and controlling: the core functions of management with case studies.'),
('The Discovery of India','Jawaharlal Nehru','9780143031031','History','Penguin',2004,'HS-A1',2,2,'A sweeping narrative of India''s history, culture and philosophy written during imprisonment in 1944.'),
('Wings of Fire','A. P. J. Abdul Kalam','9788173711466','Biography','Universities Press',1999,'BG-A1',5,5,'The autobiography of Dr. Kalam: his rise from Rameswaram to the pinnacle of India''s space and missile programmes.'),
('Python Crash Course','Eric Matthes','9781593279288','Computer Science','No Starch Press',2019,'CS-C1',4,3,'A hands-on, project-based introduction to Python programming, from basics to games and web apps.'),
('Digital Design','M. Morris Mano','9780132774208','Electronics','Pearson',2012,'EC-A1',3,3,'Logic gates, combinational and sequential circuits, HDL and computer design fundamentals.'),
('Signals and Systems','Alan V. Oppenheim','9780138147570','Electronics','Pearson',1996,'EC-A2',2,2,'Continuous and discrete-time signals, Fourier and Laplace transforms, and system analysis.'),
('Let Us C','Yashavant Kanetkar','9788183331630','Computer Science','BPB Publications',2016,'CS-C2',6,6,'The most popular beginner book for C programming in Indian colleges, with plenty of exercises.'),
('Thinking, Fast and Slow','Daniel Kahneman','9780374533557','Psychology','Farrar, Straus and Giroux',2011,'PS-A1',2,2,'A tour of the two systems that drive the way we think, and how they shape our judgments and decisions.');

INSERT INTO issues (user_id,book_id,issue_date,due_date,return_date,status,fine_amount,fine_paid,accrual_from,fine_note) VALUES
(1,1, DATE_SUB(CURDATE(),INTERVAL 20 DAY), DATE_SUB(CURDATE(),INTERVAL 6 DAY), NULL,'Issued',0,0,NULL,NULL),
(1,2, DATE_SUB(CURDATE(),INTERVAL 5 DAY),  DATE_ADD(CURDATE(),INTERVAL 9 DAY), NULL,'Issued',0,0,NULL,NULL),
(1,3, DATE_SUB(CURDATE(),INTERVAL 40 DAY), DATE_SUB(CURDATE(),INTERVAL 26 DAY),DATE_SUB(CURDATE(),INTERVAL 20 DAY),'Returned',30,30,NULL,'Late return: 6 days'),
(2,4, DATE_SUB(CURDATE(),INTERVAL 18 DAY), DATE_SUB(CURDATE(),INTERVAL 4 DAY), NULL,'Issued',0,0,NULL,NULL),
(2,6, DATE_SUB(CURDATE(),INTERVAL 30 DAY), DATE_SUB(CURDATE(),INTERVAL 16 DAY),DATE_SUB(CURDATE(),INTERVAL 16 DAY),'Returned',0,0,NULL,NULL),
(3,8, DATE_SUB(CURDATE(),INTERVAL 3 DAY),  DATE_ADD(CURDATE(),INTERVAL 11 DAY),NULL,'Issued',0,0,NULL,NULL),
(3,10,DATE_SUB(CURDATE(),INTERVAL 25 DAY), DATE_SUB(CURDATE(),INTERVAL 11 DAY),NULL,'Issued',0,0,NULL,NULL),
(4,13,DATE_SUB(CURDATE(),INTERVAL 60 DAY), DATE_SUB(CURDATE(),INTERVAL 46 DAY),DATE_SUB(CURDATE(),INTERVAL 40 DAY),'Returned',30,0,NULL,'Late return: 6 days'),
(4,14,DATE_SUB(CURDATE(),INTERVAL 2 DAY),  DATE_ADD(CURDATE(),INTERVAL 12 DAY),NULL,'Issued',0,0,NULL,NULL),
(2,1, DATE_SUB(CURDATE(),INTERVAL 10 DAY), DATE_ADD(CURDATE(),INTERVAL 4 DAY), NULL,'Issued',0,0,NULL,NULL);

INSERT INTO payments (receipt_no,user_id,issue_id,amount,method) VALUES ('RCPT-240101-0001',1,3,30,'UPI');

INSERT INTO materials (title,subject,material_type,department,year,semester,description) VALUES
('Engineering Mathematics I: Complete Notes','Engineering Mathematics I','Notes','All Departments',1,1,'Matrices, differential calculus, partial differentiation and multiple integrals with solved examples.'),
('Engineering Physics: Unit-wise Notes','Engineering Physics','Notes','All Departments',1,1,'Wave optics, lasers, fibre optics and quantum mechanics basics.'),
('Programming in C: Lab Manual','Programming in C','Lab Manual','Computer Science',1,2,'20 graded lab experiments from basic I/O to file handling and pointers.'),
('Engineering Chemistry: Previous Year Papers','Engineering Chemistry','Question Paper','All Departments',1,2,'Last five years of end-semester question papers with marking scheme.'),
('Data Structures: Lecture Notes','Data Structures','Notes','Computer Science',2,3,'Arrays, linked lists, stacks, queues, trees, graphs, hashing and sorting.'),
('Digital Electronics: Syllabus & Reference List','Digital Electronics','Syllabus','Electronics',2,3,'Course outcomes, unit plan and recommended reading for the semester.'),
('Database Management Systems: Question Bank','Database Management Systems','Question Paper','Computer Science',2,4,'ER modelling, normalization, SQL and transaction questions with answers.'),
('Signals and Systems: Solved Problems','Signals and Systems','Notes','Electronics',2,4,'Fourier and Laplace transform problems solved step by step.'),
('Operating Systems: Quick Revision Notes','Operating Systems','Notes','Computer Science',3,5,'Scheduling, deadlocks, paging and file system summaries for exam preparation.'),
('Thermodynamics: Formula Sheet','Thermodynamics','Notes','Mechanical',3,5,'Laws of thermodynamics, cycles and property tables on one compact sheet.'),
('Computer Networks: Lab Manual','Computer Networks','Lab Manual','Computer Science',3,6,'Socket programming, packet tracing and routing experiments.'),
('Software Engineering: Project Guidelines','Software Engineering','Syllabus','Computer Science',4,7,'Mini-project template, report format and evaluation rubric.'),
('Final Year Project: Report Template','Project Work','Notes','All Departments',4,8,'Word and LaTeX style guide with chapter structure and referencing format.');

INSERT INTO messages (name,email,subject,message) VALUES
('Priya Nair','priya.nair@college.edu','Book request','Could the library add the latest edition of Computer Organization by Hamacher?');

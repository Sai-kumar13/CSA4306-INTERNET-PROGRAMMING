<?php
// config/db.php - Database Connection & Global Configuration

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Credentials (Default XAMPP settings)
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'library_db');

// Base application path helpers
define('SITE_NAME', 'Library Management System');

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die("<div style='font-family: sans-serif; padding: 20px; background: #fee2e2; color: #991b1b; border-radius: 8px; margin: 20px;'>
                    <h3>Database Connection Failed!</h3>
                    <p>" . htmlspecialchars($e->getMessage()) . "</p>
                    <p><strong>Quick Fix for XAMPP:</strong></p>
                    <ol>
                        <li>Open XAMPP Control Panel and ensure <strong>Apache</strong> and <strong>MySQL</strong> are running.</li>
                        <li>Open <a href='http://localhost/phpmyadmin' target='_blank'>http://localhost/phpmyadmin</a></li>
                        <li>Import the database file located at <code>sql/library_db.sql</code>.</li>
                    </ol>
                 </div>");
        }
    }
    return $pdo;
}

// Helper to escape HTML outputs safely
function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}
?>

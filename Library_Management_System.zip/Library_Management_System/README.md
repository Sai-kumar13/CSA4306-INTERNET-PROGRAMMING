# Bookmark College Library: Library Management System

PHP + MySQL (XAMPP) library website with a student portal and a librarian admin panel.
**Demo mode:** there is no real authentication and no real payment. Every login / register /
payment screen moves to the next step with a click, no credentials or card details needed.

## Run it on XAMPP
1. Install and open **XAMPP Control Panel** and start **Apache** and **MySQL**.
2. Copy the folder `library_management_system` into `C:\xampp\htdocs\` (macOS/Linux: `/opt/lampp/htdocs/`).
3. Open **http://localhost/library_management_system/**
4. On the first visit the database `bookmark_library` and all demo data are created automatically from `database.sql`.
   (Or import `database.sql` yourself with phpMyAdmin at http://localhost/phpmyadmin.)

If your MySQL root user has a password, edit `includes/init.php` (`DB_PASS`).
To reset the demo data: in phpMyAdmin drop the `bookmark_library` database, then reload the site.

## Demo walkthrough
* **Sign in**: pick *Student* or *Librarian* and press the button (fields are pre-filled, not checked).
* **Student**: dashboard, catalog search, book details, *Borrow* (issue + expiry dates), My Borrow History,
  Check Fine, *Pay fine* (fake checkout → receipt), Study Material (search by year/semester, download PDF), Profile, Contact form.
* **Librarian**: dashboard, Add / Update / Delete books, Issue book to a student, Return status (mark returned, auto late fine),
  Make fine / mark paid / waive, Add / Update / View study material (year- & semester-wise, optional file upload), Students, Messages.
* Late fine = ₹5 per overdue day, loan period = 14 days (change `FINE_PER_DAY` / `LOAN_DAYS` in `includes/init.php`).

## Structure
```
index.php books.php book_details.php contact.php login.php register.php logout.php
dashboard.php borrow.php my_books.php fines.php pay.php receipt.php materials.php download.php profile.php
admin/   dashboard, books, add_book, edit_book, delete_book, issue_book, returns, fines,
         materials, material_form, delete_material, students, messages
includes/  init.php (config, DB auto-install, helpers) + layout partials
assets/    css/style.css, js/script.js        uploads/  librarian-uploaded material
database.sql
```

-- Library Management System Database
-- Database: `library_db`

CREATE DATABASE IF NOT EXISTS `library_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `library_db`;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `contact_messages`;
DROP TABLE IF EXISTS `study_materials`;
DROP TABLE IF EXISTS `issued_books`;
DROP TABLE IF EXISTS `books`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `admins`;
DROP TABLE IF EXISTS `issues`;
DROP TABLE IF EXISTS `messages`;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Users Table (Admin and Students)
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `role` ENUM('admin', 'student') NOT NULL DEFAULT 'student',
  `roll_no` VARCHAR(50) DEFAULT NULL UNIQUE,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `phone` VARCHAR(20) DEFAULT NULL,
  `department` VARCHAR(100) DEFAULT NULL,
  `password` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Books Table
CREATE TABLE IF NOT EXISTS `books` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `isbn` VARCHAR(50) NOT NULL UNIQUE,
  `title` VARCHAR(255) NOT NULL,
  `author` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `publisher` VARCHAR(100) DEFAULT NULL,
  `edition` VARCHAR(50) DEFAULT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `available_qty` INT NOT NULL DEFAULT 1,
  `rack_no` VARCHAR(50) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Issued Books Table (Issue & Return Tracking)
CREATE TABLE IF NOT EXISTS `issued_books` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `book_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `issue_date` DATE NOT NULL,
  `due_date` DATE NOT NULL,
  `return_date` DATE DEFAULT NULL,
  `status` ENUM('issued', 'returned') NOT NULL DEFAULT 'issued',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`book_id`) REFERENCES `books`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================
-- SAMPLE DATA
-- Admin Login: admin@library.com / admin123
-- Student Login: student@library.com (or roll CS202401) / student123
-- =============================================

INSERT INTO `users` (`id`, `role`, `roll_no`, `name`, `email`, `phone`, `department`, `password`) VALUES
(1, 'admin', NULL, 'Admin', 'admin@library.com', '9876543210', 'Library', '$2y$10$tZ2RfgDk1u9dknuS3o1nEupB3r9Q1rE6iW.aQWkOvyM5v7y.pE2/W'),
(2, 'student', 'CS202401', 'Rahul Sharma', 'student@library.com', '9876543211', 'Computer Science', '$2y$10$v2s3RgnlA1t3e9L7m4Lz/u4WdZqK.eB6aQ7dG3f9J0l1k8u4m8m2i');

-- Sample Books
INSERT INTO `books` (`id`, `isbn`, `title`, `author`, `category`, `publisher`, `edition`, `quantity`, `available_qty`, `rack_no`, `description`) VALUES
(1, '978-0131103627', 'The C Programming Language', 'Brian W. Kernighan, Dennis M. Ritchie', 'Computer Science', 'Prentice Hall', '2nd', 5, 4, 'Rack-A1', 'Classic reference and tutorial book for learning the C programming language.'),
(2, '978-0262033848', 'Introduction to Algorithms', 'Thomas H. Cormen, Charles E. Leiserson', 'Computer Science', 'MIT Press', '3rd', 4, 4, 'Rack-A2', 'Comprehensive textbook covering algorithms and data structures.'),
(3, '978-0132350884', 'Clean Code', 'Robert C. Martin', 'Software Engineering', 'Prentice Hall', '1st', 6, 6, 'Rack-B1', 'Best practices and patterns for writing clean, readable code.'),
(4, '978-0073529325', 'Database System Concepts', 'Abraham Silberschatz, Henry F. Korth', 'Information Technology', 'McGraw-Hill', '6th', 5, 4, 'Rack-B2', 'Foundational textbook on database design and SQL.'),
(5, '978-0134444321', 'Engineering Mathematics', 'K. A. Stroud, Dexter J. Booth', 'Mathematics', 'Bloomsbury', '8th', 8, 8, 'Rack-C1', 'Essential mathematics for engineering students.');

-- Sample Issued Books
INSERT INTO `issued_books` (`id`, `book_id`, `user_id`, `issue_date`, `due_date`, `return_date`, `status`) VALUES
(1, 1, 2, '2026-03-01', '2026-03-15', NULL, 'issued'),
(2, 4, 2, '2026-03-20', '2026-04-05', '2026-04-02', 'returned');

<?php
require 'includes/init.php';
$page_title = 'Book Catalog'; $active = 'books';
$q = get('q'); $cat = get('category'); $avail = get('avail');
$sql = "SELECT * FROM books WHERE 1=1"; $types = ''; $p = [];
if ($q !== '') { $sql .= " AND (title LIKE ? OR author LIKE ? OR isbn LIKE ? OR category LIKE ?)"; $like = "%$q%"; $types .= 'ssss'; array_push($p, $like, $like, $like, $like); }
if ($cat !== '') { $sql .= " AND category=?"; $types .= 's'; $p[] = $cat; }
if ($avail === '1') $sql .= " AND available>0";
$sql .= " ORDER BY title";
$books = db_all($sql, $types, $p);
include 'includes/header.php';
?>
<div class="wrap">
  <div class="page-head"><h1>Book Catalog</h1><p>Search by title, author, ISBN or subject. Open any book to see details and borrow it.</p></div>
  <form class="filters" method="get">
    <input name="q" placeholder="Search title, author, ISBN…" value="<?= e($q) ?>">
    <select name="category"><option value="">All categories</option>
      <?php foreach (categories() as $c): ?><option <?= $cat === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
    </select>
    <select name="avail"><option value="">Any availability</option><option value="1" <?= $avail === '1' ? 'selected' : '' ?>>Available now</option></select>
    <button class="btn">Search</button>
    <?php if ($q !== '' || $cat !== '' || $avail !== ''): ?><a class="btn btn-ghost" href="<?= url('books.php') ?>">Clear</a><?php endif; ?>
  </form>
  <p class="muted"><?= count($books) ?> book<?= count($books) === 1 ? '' : 's' ?> found</p>
  <?php if (!$books): ?>
    <div class="empty"><div class="big">📭</div><h3>No books match your search</h3><p>Try a different keyword or clear the filters.</p></div>
  <?php else: ?>
  <div class="book-grid">
    <?php foreach ($books as $b): ?>
    <div class="book-card">
      <a href="<?= url('book_details.php?id=' . $b['id']) ?>" style="align-self:center"><?= book_cover($b) ?></a>
      <div><h3><a href="<?= url('book_details.php?id=' . $b['id']) ?>" style="color:inherit"><?= e($b['title']) ?></a></h3><p class="meta"><?= e($b['author']) ?></p></div>
      <div class="foot">
        <?= $b['available'] > 0 ? '<span class="badge b-ok">' . (int)$b['available'] . ' of ' . (int)$b['quantity'] . ' available</span>' : '<span class="badge b-bad">All issued</span>' ?>
        <a class="btn btn-sm btn-ghost" href="<?= url('book_details.php?id=' . $b['id']) ?>">Details</a>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>

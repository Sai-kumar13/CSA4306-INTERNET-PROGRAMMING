<?php
require 'includes/init.php';
if (!is_student() && !is_admin()) require_student();
$m = db_one("SELECT * FROM materials WHERE id=?", 'i', [(int)get('id')]);
if (!$m) { flash('Material not found.', 'error'); redirect('materials.php'); }
$slug = preg_replace('/[^A-Za-z0-9]+/', '_', $m['title']);
// If the librarian uploaded a real file, send it; otherwise generate a sample PDF on the fly.
$path = $m['file_name'] ? ROOT_DIR . '/uploads/' . basename($m['file_name']) : '';
if ($path && is_file($path)) {
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    header('Content-Type: ' . ($ext === 'pdf' ? 'application/pdf' : 'application/octet-stream'));
    header('Content-Disposition: attachment; filename="' . $slug . '.' . $ext . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path); exit;
}
$lines = [
    'Subject: ' . $m['subject'],
    'Type: ' . $m['material_type'] . '   |   Department: ' . $m['department'],
    'Year ' . $m['year'] . ' - Semester ' . $m['semester'],
    '',
    $m['description'],
    '',
    'Contents (sample)',
    'Unit 1 - Introduction and fundamentals of ' . $m['subject'],
    'Unit 2 - Core concepts with solved examples',
    'Unit 3 - Intermediate problems and applications',
    'Unit 4 - Advanced topics and case studies',
    'Unit 5 - Revision questions and previous exam patterns',
    '',
    'Recommended reading: see the Book Catalog for related titles in the library.',
    '',
    'Issued by the college library. Visit the library desk for printed copies.',
];
$pdf = simple_pdf($m['title'], $lines);
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $slug . '.pdf"');
header('Content-Length: ' . strlen($pdf));
echo $pdf;

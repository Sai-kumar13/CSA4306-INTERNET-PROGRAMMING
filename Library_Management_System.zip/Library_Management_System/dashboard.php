<?php
require 'includes/init.php';
require_student();
$page_title = 'Dashboard'; $active = 'dashboard';
$u = current_user();
$rows = db_all("SELECT i.*, b.title, b.author, b.category FROM issues i JOIN books b ON b.id=i.book_id WHERE i.user_id=? ORDER BY i.issue_date DESC", 'i', [$u['id']]);
$active_rows = array_filter($rows, fn($r) => $r['status'] === 'Issued');
$overdue = count(array_filter($active_rows, fn($r) => days_between(date('Y-m-d'), $r['due_date']) < 0));
$soon = count(array_filter($active_rows, fn($r) => ($d = days_between(date('Y-m-d'), $r['due_date'])) >= 0 && $d <= 3));
$fine = array_sum(array_map('fine_due', $rows));
$mats = db_all("SELECT * FROM materials WHERE year=? ORDER BY semester=? DESC, id DESC LIMIT 4", 'ii', [$u['year'], $u['semester']]);
include 'includes/header.php';
?>
<div class="wrap section">
  <div class="welcome">
    <div><h2>Hello, <?= e(explode(' ', $u['name'])[0]) ?> 👋</h2><p><?= e($u['department']) ?> · Year <?= (int)$u['year'] ?> · Semester <?= (int)$u['semester'] ?> · Roll <?= e($u['roll_no']) ?></p></div>
    <a class="btn" href="<?= url('books.php') ?>">Browse catalog</a>
  </div>
  <div class="grid g4 mb">
    <div class="card kpi"><div class="ico">📚</div><div><b><?= count($active_rows) ?></b><span>Books borrowed</span></div></div>
    <div class="card kpi warn"><div class="ico">⏰</div><div><b><?= $soon ?></b><span>Due within 3 days</span></div></div>
    <div class="card kpi bad"><div class="ico">⚠️</div><div><b><?= $overdue ?></b><span>Overdue</span></div></div>
    <div class="card kpi info"><div class="ico">₹</div><div><b><?= money($fine) ?></b><span>Fine due</span></div></div>
  </div>
  <?php if ($fine > 0): ?>
  <div class="fine-hero" style="padding:16px 22px"><div><b>You have an outstanding fine of <?= money($fine) ?></b><div class="muted small">Clear it in two clicks.</div></div><a class="btn btn-accent" href="<?= url('pay.php?all=1') ?>">Pay all fines</a></div>
  <?php endif; ?>
  <div class="grid g2" style="grid-template-columns:1.2fr .8fr;align-items:start">
    <div class="panel">
      <div class="row between"><h3>Currently borrowed</h3><a href="<?= url('my_books.php') ?>" class="small">Full history →</a></div>
      <?php if (!$active_rows): ?><div class="empty"><div class="big">📖</div>No books borrowed right now.</div><?php else: ?>
      <ul class="timeline">
        <?php foreach ($active_rows as $r): ?>
        <li><div><b><?= e($r['title']) ?></b><div class="muted small">Issued <?= fmt_date($r['issue_date']) ?> · Expires <?= fmt_date($r['due_date']) ?></div></div><div><?= status_badge($r) ?></div></li>
        <?php endforeach; ?>
      </ul><?php endif; ?>
    </div>
    <div class="panel">
      <div class="row between"><h3>Material for you</h3><a href="<?= url('materials.php?year=' . $u['year']) ?>" class="small">See all →</a></div>
      <ul class="timeline">
        <?php foreach ($mats as $m): ?>
        <li><div><b><?= e($m['title']) ?></b><div class="muted small">Year <?= (int)$m['year'] ?> · Sem <?= (int)$m['semester'] ?> · <?= e($m['material_type']) ?></div></div><a class="btn btn-sm btn-ghost" href="<?= url('download.php?id=' . $m['id']) ?>">⬇</a></li>
        <?php endforeach; if (!$mats) echo '<li class="muted">No material for your year yet.</li>'; ?>
      </ul>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>

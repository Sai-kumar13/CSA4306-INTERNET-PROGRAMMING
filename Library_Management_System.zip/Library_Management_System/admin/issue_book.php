<?php
require '../includes/init.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uid = (int)post('user_id'); $bid = (int)post('book_id');
    $issue = post('issue_date') ?: date('Y-m-d'); $due = post('due_date') ?: date('Y-m-d', strtotime($issue . ' +' . LOAN_DAYS . ' days'));
    $book = db_one("SELECT * FROM books WHERE id=?", 'i', [$bid]);
    $user = db_one("SELECT * FROM users WHERE id=?", 'i', [$uid]);
    if (!$book || !$user) flash('Please choose a student and a book.', 'error');
    elseif ($book['available'] < 1) flash('No copies of that book are available.', 'error');
    else {
        db_exec("INSERT INTO issues(user_id,book_id,issue_date,due_date,status) VALUES(?,?,?,?,'Issued')", 'iiss', [$uid, $bid, $issue, $due]);
        db_exec("UPDATE books SET available=available-1 WHERE id=?", 'i', [$bid]);
        flash('Issued "' . $book['title'] . '" to ' . $user['name'] . ' · due ' . fmt_date($due));
    }
    redirect('admin/issue_book.php');
}
$users = db_all("SELECT id,name,roll_no FROM users ORDER BY name");
$books = db_all("SELECT id,title,available FROM books WHERE available>0 ORDER BY title");
$recent = db_all("SELECT i.*, u.name sname, b.title FROM issues i JOIN users u ON u.id=i.user_id JOIN books b ON b.id=i.book_id ORDER BY i.id DESC LIMIT 6");
$page_title = 'Issue Book'; $active = 'issue';
include '../includes/admin_header.php';
?>
<div class="grid g2" style="grid-template-columns:.9fr 1.1fr;align-items:start">
  <form method="post" class="panel">
    <h3>Issue a book to a student</h3>
    <div class="field"><label>Student</label><select name="user_id"><?php foreach ($users as $u) echo '<option value="' . $u['id'] . '">' . e($u['name']) . ' (' . e($u['roll_no']) . ')</option>'; ?></select></div>
    <div class="field"><label>Book (available only)</label><select name="book_id"><?php foreach ($books as $b) echo '<option value="' . $b['id'] . '">' . e($b['title']) . ' — ' . (int)$b['available'] . ' left</option>'; ?></select></div>
    <div class="form-grid">
      <div class="field"><label>Issue date</label><input type="date" name="issue_date" value="<?= date('Y-m-d') ?>"></div>
      <div class="field"><label>Expiry date</label><input type="date" name="due_date" value="<?= date('Y-m-d', strtotime('+' . LOAN_DAYS . ' days')) ?>"></div>
    </div>
    <button class="btn btn-lg">Issue book</button>
  </form>
  <div>
    <h3>Recently issued</h3>
    <div class="table-wrap"><table><thead><tr><th>Student</th><th>Book</th><th>Expiry</th></tr></thead><tbody>
    <?php foreach ($recent as $r): ?><tr><td><?= e($r['sname']) ?></td><td><?= e($r['title']) ?></td><td><?= fmt_date($r['due_date']) ?></td></tr><?php endforeach; ?></tbody></table></div>
  </div>
</div>
<?php include '../includes/admin_footer.php'; ?>

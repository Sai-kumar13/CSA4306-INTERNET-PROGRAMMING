<?php
require '../includes/init.php';
require_admin();
$b = ['title' => '', 'author' => '', 'isbn' => '', 'category' => '', 'shelf' => '', 'publisher' => '', 'published_year' => '', 'quantity' => 1, 'description' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $qty = max(1, (int)post('quantity', '1'));
    $yr = (int)post('published_year') ?: null;
    db_exec("INSERT INTO books(title,author,isbn,category,publisher,published_year,shelf,quantity,available,description) VALUES(?,?,?,?,?,?,?,?,?,?)", 'sssssisiis',
        [post('title', 'Untitled'), post('author', 'Unknown'), post('isbn'), post('category', 'General') ?: 'General', post('publisher'), $yr, post('shelf'), $qty, $qty, post('description')]);
    flash('Book added to the catalog.');
    redirect('admin/books.php');
}
$page_title = 'Add Book'; $active = 'add'; $submit_label = 'Add book';
include '../includes/admin_header.php';
include '_book_form.php';
include '../includes/admin_footer.php';

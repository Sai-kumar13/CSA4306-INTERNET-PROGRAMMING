<?php
require '../includes/init.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = post('act'); $id = (int)post('id');
    $r = db_one("SELECT * FROM issues WHERE id=?", 'i', [$id]);
    if ($r && $act === 'make') {
        $amt = (float)post('amount');
        if ($amt > 0) {
            db_exec("UPDATE issues SET fine_amount=fine_amount+?, fine_note=? WHERE id=?", 'dsi', [$amt, post('reason', 'Fine added by librarian') ?: 'Fine added by librarian', $id]);
            flash('Fine of ' . money($amt) . ' recorded.');
        } else flash('Enter an amount greater than zero.', 'error');
    } elseif ($r && $act === 'paid') {
        $due = fine_due($r); $tot = fine_total($r);
        db_exec("UPDATE issues SET fine_amount=?, fine_paid=?, accrual_from=CURDATE() WHERE id=?", 'ddi', [$tot, $tot, $id]);
        db_exec("INSERT INTO payments(receipt_no,user_id,issue_id,amount,method) VALUES(?,?,?,?,'Cash at desk')", 'siid', ['RCPT-' . date('ymd') . '-' . rand(1000, 9999), $r['user_id'], $id, $due]);
        flash('Marked as paid (' . money($due) . ').');
    } elseif ($r && $act === 'waive') {
        $tot = fine_total($r);
        db_exec("UPDATE issues SET fine_amount=fine_paid, accrual_from=CURDATE() WHERE id=?", 'i', [$id]);
        flash('Fine waived.', 'info');
    }
    redirect('admin/fines.php');
}
$all = db_all("SELECT i.*, u.name sname, u.roll_no, b.title FROM issues i JOIN users u ON u.id=i.user_id JOIN books b ON b.id=i.book_id ORDER BY i.id DESC");
$fined = array_filter($all, fn($r) => fine_total($r) > 0);
$due = array_sum(array_map('fine_due', $all));
$collected = array_sum(array_map(fn($r) => (float)$r['fine_paid'], $all));
$page_title = 'Fines'; $active = 'fines';
include '../includes/admin_header.php';
?>
<div class="grid g3 mb">
  <div class="card kpi bad"><div class="ico">₹</div><div><b><?= money($due) ?></b><span>Outstanding</span></div></div>
  <div class="card kpi"><div class="ico">✓</div><div><b><?= money($collected) ?></b><span>Collected</span></div></div>
  <div class="card kpi warn"><div class="ico">⚙️</div><div><b>₹<?= FINE_PER_DAY ?>/day</b><span>Late fee rate</span></div></div>
</div>
<div class="grid g2" style="grid-template-columns:.8fr 1.2fr;align-items:start">
  <form method="post" class="panel"><input type="hidden" name="act" value="make">
    <h3>Make fine</h3>
    <div class="field"><label>Issue record</label><select name="id"><?php foreach ($all as $r) echo '<option value="' . $r['id'] . '">' . e($r['sname']) . ' — ' . e($r['title']) . ' (' . $r['status'] . ')</option>'; ?></select></div>
    <div class="field"><label>Amount (₹)</label><input type="number" name="amount" min="1" step="1" placeholder="e.g. 100"></div>
    <div class="field"><label>Reason</label><select name="reason"><option>Damaged book</option><option>Lost book</option><option>Late return</option><option>Other</option></select></div>
    <button class="btn">Add fine</button>
    <p class="small muted mt" style="margin-bottom:0">Late fees are calculated automatically; use this form for damage, loss or manual penalties.</p>
  </form>
  <div>
    <h3>Fine ledger</h3>
    <div class="table-wrap"><table><thead><tr><th>Student / Book</th><th>Total</th><th>Paid</th><th>Due</th><th></th></tr></thead><tbody>
    <?php foreach ($fined as $r): ?>
    <tr><td><b><?= e($r['sname']) ?></b><span class="sub"><?= e($r['title']) ?> · <?= e($r['fine_note'] ?: 'Late fee') ?></span></td><td><?= money(fine_total($r)) ?></td><td><?= money($r['fine_paid']) ?></td>
    <td><?= fine_due($r) > 0 ? '<b style="color:var(--bad)">' . money(fine_due($r)) . '</b>' : '<span class="badge b-ok">Clear</span>' ?></td>
    <td><?php if (fine_due($r) > 0): ?><form method="post" class="actions"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="btn btn-sm" name="act" value="paid">Mark paid</button><button class="btn btn-sm btn-ghost" name="act" value="waive" data-confirm="Waive this fine?">Waive</button></form><?php endif; ?></td></tr>
    <?php endforeach; if (!$fined) echo '<tr><td colspan="5" class="empty">No fines recorded.</td></tr>'; ?></tbody></table></div>
  </div>
</div>
<?php include '../includes/admin_footer.php'; ?>

<?php
require '../includes/init.php';
require_admin();
if (get('del')) { db_exec("DELETE FROM messages WHERE id=?", 'i', [(int)get('del')]); flash('Message deleted.', 'info'); redirect('admin/messages.php'); }
$msgs = db_all("SELECT * FROM messages ORDER BY id DESC");
$page_title = 'Messages'; $active = 'messages';
include '../includes/admin_header.php';
?>
<?php if (!$msgs): ?><div class="empty"><div class="big">📭</div>No messages yet.</div><?php endif; ?>
<div class="grid">
<?php foreach ($msgs as $m): ?>
  <div class="panel"><div class="row between"><div><b><?= e($m['name']) ?></b> <span class="muted small">&lt;<?= e($m['email'] ?: 'no email') ?>&gt;</span></div><span class="muted small"><?= date('d M Y, h:i A', strtotime($m['created_at'])) ?></span></div>
  <h3 style="margin:10px 0 6px"><?= e($m['subject']) ?></h3><p><?= nl2br(e($m['message'])) ?></p>
  <a class="btn btn-sm btn-danger" data-confirm="Delete this message?" href="?del=<?= $m['id'] ?>">Delete</a></div>
<?php endforeach; ?></div>
<?php include '../includes/admin_footer.php'; ?>

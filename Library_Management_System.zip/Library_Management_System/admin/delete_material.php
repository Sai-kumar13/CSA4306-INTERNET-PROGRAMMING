<?php
require '../includes/init.php';
require_admin();
$m = db_one("SELECT * FROM materials WHERE id=?", 'i', [(int)get('id')]);
if ($m) {
    if ($m['file_name'] && is_file(ROOT_DIR . '/uploads/' . basename($m['file_name']))) @unlink(ROOT_DIR . '/uploads/' . basename($m['file_name']));
    db_exec("DELETE FROM materials WHERE id=?", 'i', [$m['id']]);
    flash('Material deleted.', 'info');
}
redirect('admin/materials.php');

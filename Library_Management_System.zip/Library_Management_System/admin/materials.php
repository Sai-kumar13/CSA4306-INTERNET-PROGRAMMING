<?php
require '../includes/init.php';
require_admin();
$year = (int)get('year'); $sem = (int)get('semester');
$sql = "SELECT * FROM materials WHERE 1=1"; $t = ''; $p = [];
if ($year) { $sql .= " AND year=?"; $t .= 'i'; $p[] = $year; }
if ($sem) { $sql .= " AND semester=?"; $t .= 'i'; $p[] = $sem; }
$mats = db_all($sql . " ORDER BY year, semester, title", $t, $p);
$page_title = 'View Material'; $active = 'materials';
include '../includes/admin_header.php';
?>
<form class="filters" method="get" style="margin-top:0">
  <select name="year"><option value="">All years</option><?php for ($i = 1; $i <= 4; $i++) echo '<option value="' . $i . '"' . ($year === $i ? ' selected' : '') . ">Year $i</option>"; ?></select>
  <select name="semester"><option value="">All semesters</option><?php for ($i = 1; $i <= 8; $i++) echo '<option value="' . $i . '"' . ($sem === $i ? ' selected' : '') . ">Semester $i</option>"; ?></select>
  <button class="btn">Filter</button><a class="btn btn-ghost" href="materials.php">Reset</a><a class="btn btn-accent" href="material_form.php" style="margin-left:auto">⬆ Add material</a>
</form>
<div class="table-wrap"><table><thead><tr><th>Title</th><th>Type</th><th>Year</th><th>Sem</th><th>Department</th><th>File</th><th></th></tr></thead><tbody>
<?php foreach ($mats as $m): ?>
<tr><td><b><?= e($m['title']) ?></b><span class="sub"><?= e($m['subject']) ?></span></td><td><span class="badge b-info"><?= e($m['material_type']) ?></span></td><td><?= (int)$m['year'] ?></td><td><?= (int)$m['semester'] ?></td><td><?= e($m['department']) ?></td>
<td><?= $m['file_name'] ? '<span class="badge b-ok">Uploaded</span>' : '<span class="badge b-mute">Auto PDF</span>' ?></td>
<td><div class="actions"><a class="btn btn-sm btn-ghost" href="../download.php?id=<?= $m['id'] ?>">Download</a><a class="btn btn-sm btn-ghost" href="material_form.php?id=<?= $m['id'] ?>">Update</a><a class="btn btn-sm btn-danger" data-confirm="Delete this material?" href="delete_material.php?id=<?= $m['id'] ?>">Delete</a></div></td></tr>
<?php endforeach; if (!$mats) echo '<tr><td colspan="7" class="empty">No material for this selection.</td></tr>'; ?></tbody></table></div>
<?php include '../includes/admin_footer.php'; ?>

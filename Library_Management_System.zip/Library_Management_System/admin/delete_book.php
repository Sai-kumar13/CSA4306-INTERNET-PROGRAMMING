<?php
require '../includes/init.php';
require_admin();
db_exec("DELETE FROM books WHERE id=?", 'i', [(int)get('id')]);
flash('Book deleted.', 'info');
redirect('admin/books.php');

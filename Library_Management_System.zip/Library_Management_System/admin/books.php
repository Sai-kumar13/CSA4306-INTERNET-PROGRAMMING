<?php
require '../includes/init.php';
require_admin();
$page_title = 'Books'; $active = 'books';
$books = db_all("SELECT * FROM books ORDER BY title");
include '../includes/admin_header.php';
?>
<div class="row between mb"><input style="max-width:340px" placeholder="Filter books…" data-filter="#bk"><a class="btn" href="add_book.php">＋ Add book</a></div>
<div class="table-wrap"><table id="bk"><thead><tr><th>Title</th><th>Category</th><th>ISBN</th><th>Shelf</th><th>Stock</th><th></th></tr></thead><tbody>
<?php foreach ($books as $b): ?>
<tr><td><b><?= e($b['title']) ?></b><span class="sub"><?= e($b['author']) ?></span></td><td><?= e($b['category']) ?></td><td><?= e($b['isbn']) ?></td><td><?= e($b['shelf']) ?></td>
<td><span class="badge <?= $b['available'] > 0 ? 'b-ok' : 'b-bad' ?>"><?= (int)$b['available'] ?> / <?= (int)$b['quantity'] ?></span></td>
<td><div class="actions"><a class="btn btn-sm btn-ghost" href="edit_book.php?id=<?= $b['id'] ?>">Edit</a><a class="btn btn-sm btn-danger" data-confirm="Delete '<?= e(addslashes($b['title'])) ?>' and its borrow records?" href="delete_book.php?id=<?= $b['id'] ?>">Delete</a></div></td></tr>
<?php endforeach; ?></tbody></table></div>
<?php include '../includes/admin_footer.php'; ?>

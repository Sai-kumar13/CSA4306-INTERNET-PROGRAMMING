<?php
require '../includes/init.php';
require_admin();
$id = (int)get('id', post('id'));
$m = $id ? db_one("SELECT * FROM materials WHERE id=?", 'i', [$id]) : null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $file = $m['file_name'] ?? null;
    if (!empty($_FILES['file']['name']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'zip', 'txt'], true) && $_FILES['file']['size'] <= 10 * 1024 * 1024) {
            if (!is_dir(ROOT_DIR . '/uploads')) mkdir(ROOT_DIR . '/uploads', 0777, true);
            $file = 'm' . time() . rand(100, 999) . '.' . $ext;
            move_uploaded_file($_FILES['file']['tmp_name'], ROOT_DIR . '/uploads/' . $file);
        } else flash('File skipped: allowed types are pdf, doc(x), ppt(x), zip, txt up to 10 MB.', 'error');
    }
    $year = max(1, min(4, (int)post('year', '1'))); $sem = max(1, min(8, (int)post('semester', '1')));
    $f = [post('title', 'Untitled material') ?: 'Untitled material', post('subject', 'General') ?: 'General', post('material_type', 'Notes'), post('department', 'All Departments'), $year, $sem, post('description'), $file];
    if ($m) { db_exec("UPDATE materials SET title=?,subject=?,material_type=?,department=?,year=?,semester=?,description=?,file_name=? WHERE id=?", 'ssssiissi', array_merge($f, [$m['id']])); flash('Material updated for Year ' . $year . ', Semester ' . $sem . '.'); }
    else { db_exec("INSERT INTO materials(title,subject,material_type,department,year,semester,description,file_name) VALUES(?,?,?,?,?,?,?,?)", 'ssssiiss', $f); flash('Material added for Year ' . $year . ', Semester ' . $sem . '.'); }
    redirect('admin/materials.php');
}
$v = $m ?: ['title' => '', 'subject' => '', 'material_type' => 'Notes', 'department' => 'All Departments', 'year' => 1, 'semester' => 1, 'description' => '', 'file_name' => null];
$page_title = $m ? 'Update Material' : 'Add Material'; $active = 'matform';
include '../includes/admin_header.php';
?>
<form method="post" enctype="multipart/form-data" class="panel form-narrow">
  <input type="hidden" name="id" value="<?= $m ? (int)$m['id'] : 0 ?>">
  <div class="form-grid">
    <div class="field full"><label>Title</label><input name="title" value="<?= e($v['title']) ?>" placeholder="e.g. Data Structures: Lecture Notes"></div>
    <div class="field"><label>Subject</label><input name="subject" value="<?= e($v['subject']) ?>" placeholder="Data Structures"></div>
    <div class="field"><label>Type</label><select name="material_type"><?php foreach (['Notes', 'Question Paper', 'Lab Manual', 'Syllabus'] as $x) echo '<option' . ($v['material_type'] === $x ? ' selected' : '') . '>' . $x . '</option>'; ?></select></div>
    <div class="field"><label>Year</label><select name="year"><?php for ($i = 1; $i <= 4; $i++) echo "<option value=$i" . ($v['year'] == $i ? ' selected' : '') . ">Year $i</option>"; ?></select></div>
    <div class="field"><label>Semester</label><select name="semester"><?php for ($i = 1; $i <= 8; $i++) echo "<option value=$i" . ($v['semester'] == $i ? ' selected' : '') . ">Semester $i</option>"; ?></select></div>
    <div class="field"><label>Department</label><select name="department"><?php foreach (['All Departments', 'Computer Science', 'Electronics', 'Mechanical', 'Civil', 'Management'] as $x) echo '<option' . ($v['department'] === $x ? ' selected' : '') . '>' . $x . '</option>'; ?></select></div>
    <div class="field"><label>File (optional)</label><input type="file" name="file"><?php if ($v['file_name']): ?><span class="small muted">Current file kept unless you choose a new one.</span><?php else: ?><span class="small muted">No file? Students get an auto-generated PDF summary.</span><?php endif; ?></div>
    <div class="field full"><label>Description</label><textarea name="description"><?= e($v['description']) ?></textarea></div>
  </div>
  <div class="row"><button class="btn btn-lg"><?= $m ? 'Save changes' : 'Add material' ?></button><a class="btn btn-ghost btn-lg" href="materials.php">Cancel</a></div>
</form>
<?php include '../includes/admin_footer.php'; ?>

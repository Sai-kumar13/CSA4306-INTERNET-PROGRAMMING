<?php
require '../includes/init.php';
require_admin();
$page_title = 'Dashboard'; $active = 'dashboard';
$all = db_all("SELECT i.*, u.name sname, u.roll_no, b.title FROM issues i JOIN users u ON u.id=i.user_id JOIN books b ON b.id=i.book_id ORDER BY i.id DESC");
$issued = array_filter($all, fn($r) => $r['status'] === 'Issued');
$overdue = array_filter($issued, fn($r) => days_between(date('Y-m-d'), $r['due_date']) < 0);
$fine = array_sum(array_map('fine_due', $all));
$kpi = [
  'titles' => db_one("SELECT COUNT(*) n FROM books")['n'],
  'copies' => db_one("SELECT COALESCE(SUM(available),0) n FROM books")['n'],
  'students' => db_one("SELECT COUNT(*) n FROM users")['n'],
  'msgs' => db_one("SELECT COUNT(*) n FROM messages")['n'],
];
include '../includes/admin_header.php';
?>
<div class="grid g4 mb">
  <div class="card kpi"><div class="ico">📚</div><div><b><?= (int)$kpi['titles'] ?></b><span>Book titles · <?= (int)$kpi['copies'] ?> copies in</span></div></div>
  <div class="card kpi info"><div class="ico">➜</div><div><b><?= count($issued) ?></b><span>Books currently issued</span></div></div>
  <div class="card kpi bad"><div class="ico">⚠️</div><div><b><?= count($overdue) ?></b><span>Overdue books</span></div></div>
  <div class="card kpi warn"><div class="ico">₹</div><div><b><?= money($fine) ?></b><span>Fines outstanding</span></div></div>
</div>
<div class="row mb">
  <a class="btn" href="add_book.php">＋ Add book</a><a class="btn" href="issue_book.php">➜ Issue book</a><a class="btn btn-ghost" href="returns.php">↩ Process return</a><a class="btn btn-ghost" href="fines.php">₹ Make fine</a><a class="btn btn-ghost" href="material_form.php">⬆ Add material</a>
</div>
<div class="grid g2" style="grid-template-columns:1.3fr .7fr;align-items:start">
  <div>
    <h3>Recent circulation</h3>
    <div class="table-wrap"><table><thead><tr><th>Student</th><th>Book</th><th>Issued</th><th>Expiry</th><th>Status</th></tr></thead><tbody>
      <?php foreach (array_slice($all, 0, 7) as $r): ?>
      <tr><td><b><?= e($r['sname']) ?></b><span class="sub"><?= e($r['roll_no']) ?></span></td><td><?= e($r['title']) ?></td><td><?= fmt_date($r['issue_date']) ?></td><td><?= fmt_date($r['due_date']) ?></td><td><?= status_badge($r) ?></td></tr>
      <?php endforeach; ?></tbody></table></div>
  </div>
  <div class="panel">
    <h3>Overdue now</h3>
    <?php if (!$overdue): ?><p class="muted">Nothing overdue. 🎉</p><?php else: ?><ul class="timeline">
      <?php foreach ($overdue as $r): ?><li><div><b><?= e($r['sname']) ?></b><div class="muted small"><?= e($r['title']) ?></div></div><b style="color:var(--bad)"><?= money(fine_total($r)) ?></b></li><?php endforeach; ?></ul>
      <a class="btn btn-sm btn-ghost" href="returns.php?f=overdue">Manage overdue →</a><?php endif; ?>
  </div>
</div>
<?php include '../includes/admin_footer.php'; ?>

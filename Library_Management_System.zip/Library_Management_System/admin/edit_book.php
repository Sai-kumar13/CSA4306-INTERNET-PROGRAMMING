<?php
require '../includes/init.php';
require_admin();
$old = db_one("SELECT * FROM books WHERE id=?", 'i', [(int)get('id')]);
if (!$old) { flash('Book not found.', 'error'); redirect('admin/books.php'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $qty = max(1, (int)post('quantity', (string)$old['quantity']));
    $avail = max(0, $old['available'] + ($qty - $old['quantity']));
    $yr = (int)post('published_year') ?: null;
    db_exec("UPDATE books SET title=?,author=?,isbn=?,category=?,publisher=?,published_year=?,shelf=?,quantity=?,available=?,description=? WHERE id=?", 'sssssisiisi',
        [post('title', $old['title']), post('author', $old['author']), post('isbn'), post('category', 'General') ?: 'General', post('publisher'), $yr, post('shelf'), $qty, $avail, post('description'), $old['id']]);
    flash('Book updated.');
    redirect('admin/books.php');
}
$b = $old;
$page_title = 'Update Book'; $active = 'books'; $submit_label = 'Save changes';
include '../includes/admin_header.php';
include '_book_form.php';
include '../includes/admin_footer.php';

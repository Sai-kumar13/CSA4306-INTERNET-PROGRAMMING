<?php
require '../includes/init.php';
require_admin();
$users = db_all("SELECT * FROM users ORDER BY name");
$issues = db_all("SELECT * FROM issues");
$stat = [];
foreach ($issues as $r) {
    $s = &$stat[$r['user_id']];
    $s['total'] = ($s['total'] ?? 0) + 1;
    if ($r['status'] === 'Issued') $s['active'] = ($s['active'] ?? 0) + 1;
    $s['fine'] = ($s['fine'] ?? 0) + fine_due($r);
    unset($s);
}
$page_title = 'Students'; $active = 'students';
include '../includes/admin_header.php';
?>
<div class="mb"><input style="max-width:340px" placeholder="Search students…" data-filter="#st"></div>
<div class="table-wrap"><table id="st"><thead><tr><th>Student</th><th>Roll no.</th><th>Department</th><th>Year / Sem</th><th>Borrowed</th><th>Holding</th><th>Fine due</th></tr></thead><tbody>
<?php foreach ($users as $u): $s = $stat[$u['id']] ?? []; ?>
<tr><td><b><?= e($u['name']) ?></b><span class="sub"><?= e($u['email']) ?></span></td><td><?= e($u['roll_no']) ?></td><td><?= e($u['department']) ?></td><td>Y<?= (int)$u['year'] ?> · S<?= (int)$u['semester'] ?></td>
<td><?= (int)($s['total'] ?? 0) ?></td><td><?= (int)($s['active'] ?? 0) ?></td><td><?= ($s['fine'] ?? 0) > 0 ? '<b style="color:var(--bad)">' . money($s['fine']) . '</b>' : '<span class="badge b-ok">Clear</span>' ?></td></tr>
<?php endforeach; ?></tbody></table></div>
<?php include '../includes/admin_footer.php'; ?>

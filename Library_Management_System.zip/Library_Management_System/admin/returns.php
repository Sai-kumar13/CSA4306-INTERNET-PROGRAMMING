<?php
require '../includes/init.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $r = db_one("SELECT * FROM issues WHERE id=? AND status='Issued'", 'i', [(int)post('id')]);
    if ($r) {
        $late = overdue_days($r); $add = $late * FINE_PER_DAY;
        $note = $late ? 'Late return: ' . $late . ' days' : $r['fine_note'];
        db_exec("UPDATE issues SET status='Returned', return_date=CURDATE(), fine_amount=fine_amount+?, fine_note=? WHERE id=?", 'dsi', [$add, $note, $r['id']]);
        db_exec("UPDATE books SET available=LEAST(quantity,available+1) WHERE id=?", 'i', [$r['book_id']]);
        flash($add > 0 ? 'Returned. Late fine of ' . money($add) . ' added (' . $late . ' days).' : 'Book returned on time. No fine.', $add > 0 ? 'info' : 'success');
    }
    redirect('admin/returns.php' . (get('f') ? '?f=' . urlencode(get('f')) : ''));
}
$f = get('f', 'issued');
$all = db_all("SELECT i.*, u.name sname, u.roll_no, b.title FROM issues i JOIN users u ON u.id=i.user_id JOIN books b ON b.id=i.book_id ORDER BY i.status, i.due_date");
$rows = array_filter($all, function ($r) use ($f) {
    if ($f === 'issued') return $r['status'] === 'Issued';
    if ($f === 'overdue') return $r['status'] === 'Issued' && days_between(date('Y-m-d'), $r['due_date']) < 0;
    if ($f === 'returned') return $r['status'] === 'Returned';
    return true;
});
$page_title = 'Return Status'; $active = 'returns';
include '../includes/admin_header.php';
$tabs = ['issued' => 'Issued', 'overdue' => 'Overdue', 'returned' => 'Returned', 'all' => 'All'];
?>
<div class="row mb"><?php foreach ($tabs as $k => $l): ?><a class="chip" style="<?= $f === $k ? 'background:var(--primary);color:#fff' : '' ?>" href="?f=<?= $k ?>"><?= $l ?></a><?php endforeach; ?><input style="max-width:260px;margin-left:auto" placeholder="Filter…" data-filter="#rt"></div>
<div class="table-wrap"><table id="rt"><thead><tr><th>Student</th><th>Book</th><th>Issued</th><th>Expiry</th><th>Returned</th><th>Status</th><th>Fine</th><th></th></tr></thead><tbody>
<?php foreach ($rows as $r): ?>
<tr><td><b><?= e($r['sname']) ?></b><span class="sub"><?= e($r['roll_no']) ?></span></td><td><?= e($r['title']) ?></td><td><?= fmt_date($r['issue_date']) ?></td><td><?= fmt_date($r['due_date']) ?></td><td><?= fmt_date($r['return_date']) ?></td><td><?= status_badge($r) ?></td>
<td><?= fine_total($r) > 0 ? money(fine_total($r)) . (fine_due($r) > 0 ? ' <span class="badge b-bad">due</span>' : ' <span class="badge b-ok">paid</span>') : '—' ?></td>
<td><?php if ($r['status'] === 'Issued'): ?><form method="post"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="btn btn-sm">Mark returned</button></form><?php endif; ?></td></tr>
<?php endforeach; if (!$rows) echo '<tr><td colspan="8" class="empty">Nothing here.</td></tr>'; ?></tbody></table></div>
<?php include '../includes/admin_footer.php'; ?>

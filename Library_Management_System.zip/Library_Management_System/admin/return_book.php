<?php
// admin/return_book.php - Return Book Management
$page_title = 'Return Book Status';
$path_prefix = '../';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdmin('../login.php');

$db = getDB();
$error = '';

// Handle Return Processing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process_return'])) {
    $record_id = filter_input(INPUT_POST, 'record_id', FILTER_VALIDATE_INT);
    $return_date = trim($_POST['return_date'] ?? date('Y-m-d'));

    try {
        $db->beginTransaction();

        // 1. Get book ID and verify not already returned
        $getB = $db->prepare("SELECT book_id, status FROM issued_books WHERE id = ?");
        $getB->execute([$record_id]);
        $rec = $getB->fetch();

        if ($rec && $rec['status'] !== 'returned') {
            // 2. Update issued_books
            $upIssue = $db->prepare("UPDATE issued_books SET return_date = ?, status = 'returned' WHERE id = ?");
            $upIssue->execute([$return_date, $record_id]);

            // 3. Increment book stock
            $upStock = $db->prepare("UPDATE books SET available_qty = available_qty + 1 WHERE id = ?");
            $upStock->execute([$rec['book_id']]);

            $db->commit();
            $_SESSION['flash_success'] = "Book marked as returned and inventory updated successfully!";
            header("Location: return_book.php");
            exit();
        } else {
            $error = "This book was already marked as returned.";
        }
    } catch (Exception $e) {
        $db->rollBack();
        $error = "Error updating return status: " . $e->getMessage();
    }
}

// Filter parameters
$statusFilter = trim($_GET['status'] ?? '');
$query = "
    SELECT ib.*, b.title as book_title, b.isbn, u.name as student_name, u.roll_no, u.phone 
    FROM issued_books ib
    JOIN books b ON ib.book_id = b.id
    JOIN users u ON ib.user_id = u.id
    WHERE 1=1
";
$params = [];

if ($statusFilter !== '') {
    $query .= " AND ib.status = ?";
    $params[] = $statusFilter;
}

$query .= " ORDER BY ib.id DESC";
$stmt = $db->prepare($query);
$stmt->execute($params);
$allIssues = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container" style="padding-top: 2rem; padding-bottom: 3rem;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem;">
        <div>
            <h2>Book Return & Status</h2>
            <p style="color: var(--text-muted);">Process book returns and track current loans.</p>
        </div>
        <div style="display: flex; gap: 8px;">
            <a href="dashboard.php" class="btn btn-secondary btn-sm">&larr; Dashboard</a>
            <a href="issue_book.php" class="btn btn-primary btn-sm">➕ Issue Book</a>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger">⚠ <?= e($error) ?></div>
    <?php endif; ?>

    <!-- Filter Buttons -->
    <div style="display: flex; gap: 8px; margin-bottom: 1.5rem; flex-wrap: wrap;">
        <a href="return_book.php" class="btn <?= $statusFilter === '' ? 'btn-primary' : 'btn-outline' ?> btn-sm">All Records</a>
        <a href="return_book.php?status=issued" class="btn <?= $statusFilter === 'issued' ? 'btn-primary' : 'btn-outline' ?> btn-sm">Currently Issued</a>
        <a href="return_book.php?status=returned" class="btn <?= $statusFilter === 'returned' ? 'btn-primary' : 'btn-outline' ?> btn-sm">Returned Books</a>
    </div>

    <!-- Table of Issued Books -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Book Issues & Returns (<?= count($allIssues) ?>)</h3>
            <input type="text" id="tableSearch" class="form-control" style="max-width: 300px;" placeholder="Search table...">
        </div>

        <div class="table-responsive">
            <table class="table filterable-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Book Title & ISBN</th>
                        <th>Student Name & Roll No</th>
                        <th>Issue Date</th>
                        <th>Due Date</th>
                        <th>Return Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($allIssues)): ?>
                        <tr>
                            <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 2rem;">No issue records found.</td>
                        </tr>
                    <?php endif; ?>
                    <?php foreach ($allIssues as $row): ?>
                        <tr>
                            <td>#<?= e($row['id']) ?></td>
                            <td>
                                <strong><?= e($row['book_title']) ?></strong>
                                <div style="font-size: 0.8rem; color: var(--text-muted);"><?= e($row['isbn']) ?></div>
                            </td>
                            <td>
                                <strong><?= e($row['student_name']) ?></strong>
                                <div style="font-size: 0.8rem; color: var(--text-muted);">Roll: <?= e($row['roll_no'] ?: 'N/A') ?></div>
                            </td>
                            <td><?= e(date('d M Y', strtotime($row['issue_date']))) ?></td>
                            <td><?= e(date('d M Y', strtotime($row['due_date']))) ?></td>
                            <td>
                                <?= $row['return_date'] ? e(date('d M Y', strtotime($row['return_date']))) : '<span style="color: var(--text-muted);">-</span>' ?>
                            </td>
                            <td>
                                <?php if ($row['status'] === 'returned'): ?>
                                    <span class="badge badge-success">Returned</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Issued</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($row['status'] !== 'returned'): ?>
                                    <form action="return_book.php" method="POST" style="display: inline;" onsubmit="return confirmAction('Mark this book as returned today?');">
                                        <input type="hidden" name="record_id" value="<?= $row['id'] ?>">
                                        <input type="hidden" name="return_date" value="<?= date('Y-m-d') ?>">
                                        <button type="submit" name="process_return" class="btn btn-primary btn-sm">
                                            Return Book
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span style="color: var(--text-muted); font-size: 0.85rem;">Completed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

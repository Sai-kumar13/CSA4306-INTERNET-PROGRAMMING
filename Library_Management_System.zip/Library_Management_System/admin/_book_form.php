<?php /* shared form: expects $b (array) and $submit_label */ ?>
<form method="post" class="panel form-narrow">
  <div class="form-grid">
    <div class="field full"><label>Title *</label><input name="title" value="<?= e($b['title']) ?>" required></div>
    <div class="field"><label>Author *</label><input name="author" value="<?= e($b['author']) ?>" required></div>
    <div class="field"><label>ISBN</label><input name="isbn" value="<?= e($b['isbn']) ?>"></div>
    <div class="field"><label>Category</label><input name="category" list="cats" value="<?= e($b['category']) ?>"><datalist id="cats"><?php foreach (categories() as $c) echo '<option value="' . e($c) . '">'; ?></datalist></div>
    <div class="field"><label>Shelf location</label><input name="shelf" value="<?= e($b['shelf']) ?>" placeholder="CS-A1"></div>
    <div class="field"><label>Publisher</label><input name="publisher" value="<?= e($b['publisher']) ?>"></div>
    <div class="field"><label>Published year</label><input name="published_year" type="number" value="<?= e($b['published_year']) ?>"></div>
    <div class="field"><label>Total copies</label><input name="quantity" type="number" min="1" value="<?= e($b['quantity']) ?>"></div>
    <div class="field full"><label>Description</label><textarea name="description"><?= e($b['description']) ?></textarea></div>
  </div>
  <div class="row"><button class="btn btn-lg"><?= e($submit_label) ?></button><a class="btn btn-ghost btn-lg" href="books.php">Cancel</a></div>
</form>

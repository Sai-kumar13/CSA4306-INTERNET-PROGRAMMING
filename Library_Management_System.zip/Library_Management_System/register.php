<?php
require 'includes/init.php';
// DEMO REGISTER: every field is optional; click "Create account" and you're in.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = post('name', 'New Student'); if ($name === '') $name = 'New Student';
    $email = post('email'); if ($email === '') $email = 'student' . rand(100, 999) . '@college.edu';
    $roll = post('roll_no'); if ($roll === '') $roll = 'STU' . rand(1000, 9999);
    $dept = post('department', 'Computer Science');
    $year = max(1, min(4, (int)post('year', '1'))); $sem = max(1, min(8, (int)post('semester', '1')));
    $ex = db_one("SELECT id FROM users WHERE email=?", 's', [$email]);
    if ($ex) { $uid = $ex['id']; }
    else { db_exec("INSERT INTO users(name,email,phone,roll_no,department,year,semester) VALUES(?,?,?,?,?,?,?)", 'sssssii', [$name, $email, post('phone'), $roll, $dept, $year, $sem]); $uid = last_id(); }
    $_SESSION = []; $_SESSION['user_id'] = $uid; $_SESSION['user_name'] = $name;
    flash('Account created. Welcome, ' . $name . '!');
    redirect('dashboard.php');
}
$page_title = 'Register'; $active = '';
include 'includes/header.php';
?>
<div class="auth">
  <div class="auth-card" style="max-width:600px">
    <h2 style="margin-bottom:4px">Create student account</h2>
    <p class="muted">Join the library to borrow books and access study material.</p>
    <form method="post"><div class="form-grid">
      <div class="field"><label>Full name</label><input name="name" placeholder="e.g. Meera Joshi"></div>
      <div class="field"><label>College email</label><input name="email" placeholder="meera@college.edu"></div>
      <div class="field"><label>Roll number</label><input name="roll_no" placeholder="CSE2501"></div>
      <div class="field"><label>Phone</label><input name="phone" placeholder="98765 43210"></div>
      <div class="field"><label>Department</label><select name="department"><option>Computer Science</option><option>Electronics</option><option>Mechanical</option><option>Civil</option><option>Management</option></select></div>
      <div class="field"><label>Year / Semester</label><div class="row" style="flex-wrap:nowrap"><select name="year"><?php for ($i = 1; $i <= 4; $i++) echo "<option value=$i>Year $i</option>"; ?></select><select name="semester"><?php for ($i = 1; $i <= 8; $i++) echo "<option value=$i>Sem $i</option>"; ?></select></div></div>
      <div class="field"><label>Password</label><input type="password" name="password" placeholder="Choose a password"></div>
      <div class="field"><label>Confirm password</label><input type="password" name="password2" placeholder="Choose a password"></div>
    </div>
    <button class="btn btn-lg btn-block">Create account →</button></form>
    <p class="center small muted mt">Already registered? <a href="<?= url('login.php') ?>">Sign in</a></p>
  </div>
</div>
<?php include 'includes/footer.php'; ?>

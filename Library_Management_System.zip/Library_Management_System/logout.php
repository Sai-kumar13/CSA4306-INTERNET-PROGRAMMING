<?php
require 'includes/init.php';
$_SESSION = [];
session_destroy();
session_start();
flash('You have been signed out.', 'info');
redirect('index.php');

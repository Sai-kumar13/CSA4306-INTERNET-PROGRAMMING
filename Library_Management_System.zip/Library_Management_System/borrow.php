<?php
require 'includes/init.php';
require_student();
$page_title = 'Borrow Book'; $active = 'books';
$b = db_one("SELECT * FROM books WHERE id=?", 'i', [(int)get('id', post('id'))]);
if (!$b) { flash('Book not found.', 'error'); redirect('books.php'); }
$done = null; $error = '';
$already = db_one("SELECT * FROM issues WHERE user_id=? AND book_id=? AND status='Issued'", 'ii', [$_SESSION['user_id'], $b['id']]);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($already) $error = 'You already have this book.';
    elseif ($b['available'] < 1) $error = 'Sorry, all copies were just issued.';
    else {
        $issue = date('Y-m-d'); $due = date('Y-m-d', strtotime('+' . LOAN_DAYS . ' days'));
        db_exec("INSERT INTO issues(user_id,book_id,issue_date,due_date,status) VALUES(?,?,?,?,'Issued')", 'iiss', [$_SESSION['user_id'], $b['id'], $issue, $due]);
        db_exec("UPDATE books SET available=available-1 WHERE id=? AND available>0", 'i', [$b['id']]);
        $done = ['issue' => $issue, 'due' => $due];
    }
}
include 'includes/header.php';
?>
<div class="wrap section">
  <div class="panel form-narrow" style="margin:0 auto">
  <?php if ($done): ?>
    <div class="receipt"><div class="tick">✓</div><h2>Book issued!</h2>
      <p class="muted">Collect <b><?= e($b['title']) ?></b> from shelf <b><?= e($b['shelf']) ?></b> at the issue desk.</p>
      <div class="panel" style="text-align:left;background:var(--bg);box-shadow:none">
        <div class="sum-row"><span>Issue date</span><b><?= fmt_date($done['issue']) ?></b></div>
        <div class="sum-row"><span>Expiry (due) date</span><b><?= fmt_date($done['due']) ?></b></div>
        <div class="sum-row"><span>Late fine</span><b>₹<?= FINE_PER_DAY ?>/day</b></div>
      </div>
      <div class="row mt" style="justify-content:center"><a class="btn" href="<?= url('my_books.php') ?>">View my books</a><a class="btn btn-ghost" href="<?= url('books.php') ?>">Keep browsing</a></div>
    </div>
  <?php else: ?>
    <h2>Confirm borrowing</h2>
    <?php if ($error): ?><p class="badge b-bad" style="display:block;padding:10px"><?= e($error) ?></p><?php endif; ?>
    <div class="row" style="align-items:flex-start;gap:24px;flex-wrap:nowrap">
      <?= book_cover($b) ?>
      <div style="flex:1"><h3><?= e($b['title']) ?></h3><p class="muted"><?= e($b['author']) ?></p>
        <div class="sum-row"><span>Issue date</span><b><?= fmt_date(date('Y-m-d')) ?></b></div>
        <div class="sum-row"><span>Expiry date</span><b><?= fmt_date(date('Y-m-d', strtotime('+' . LOAN_DAYS . ' days'))) ?></b></div>
        <div class="sum-row"><span>Loan period</span><b><?= LOAN_DAYS ?> days</b></div>
      </div>
    </div>
    <form method="post" class="mt"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
      <div class="row"><button class="btn btn-lg" <?= ($already || $b['available'] < 1) ? 'disabled' : '' ?>>Confirm &amp; borrow</button><a class="btn btn-ghost btn-lg" href="<?= url('book_details.php?id=' . $b['id']) ?>">Cancel</a></div>
    </form>
  <?php endif; ?>
  </div>
</div>
<?php include 'includes/footer.php'; ?>

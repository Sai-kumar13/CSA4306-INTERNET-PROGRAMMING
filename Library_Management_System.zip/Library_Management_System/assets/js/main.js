// assets/js/main.js - Interactive LMS Scripts

document.addEventListener('DOMContentLoaded', function () {
    // 1. Mobile Menu Toggle
    const toggleBtn = document.querySelector('.mobile-toggle');
    const navMenu = document.querySelector('.nav-menu');
    if (toggleBtn && navMenu) {
        toggleBtn.addEventListener('click', function () {
            if (navMenu.style.display === 'flex') {
                navMenu.style.display = 'none';
            } else {
                navMenu.style.display = 'flex';
                navMenu.style.flexDirection = 'column';
                navMenu.style.position = 'absolute';
                navMenu.style.top = '70px';
                navMenu.style.left = '0';
                navMenu.style.right = '0';
                navMenu.style.background = '#ffffff';
                navMenu.style.padding = '1rem';
                navMenu.style.boxShadow = '0 10px 15px rgba(0,0,0,0.1)';
            }
        });
    }

    // 2. Client-side Table Filter / Quick Search
    const searchInput = document.getElementById('tableSearch');
    if (searchInput) {
        searchInput.addEventListener('keyup', function () {
            const filter = searchInput.value.toLowerCase();
            const rows = document.querySelectorAll('.filterable-table tbody tr');
            rows.forEach(function (row) {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    }

    // 3. Auto dismiss flash alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-auto-dismiss');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 4500);
    });
});

// Confirmation helper for delete operations
function confirmAction(message) {
    return confirm(message || 'Are you sure you want to proceed with this action?');
}

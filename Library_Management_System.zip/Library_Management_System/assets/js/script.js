(function () {
  // auto-hide toast
  var t = document.getElementById('toast');
  if (t) setTimeout(function () { t.style.transition = '.4s'; t.style.opacity = '0'; setTimeout(function () { t.remove(); }, 400); }, 4200);

  // confirm dialogs: <a data-confirm="Are you sure?">
  document.addEventListener('click', function (ev) {
    var el = ev.target.closest('[data-confirm]');
    if (el && !confirm(el.getAttribute('data-confirm'))) ev.preventDefault();
  });

  // login role switch
  var seg = document.querySelectorAll('.seg button');
  if (seg.length) {
    var apply = function (role) {
      seg.forEach(function (b) { b.classList.toggle('on', b.dataset.role === role); });
      var r = document.getElementById('role'); if (r) r.value = role;
      var e = document.getElementById('login-email'), l = document.getElementById('login-email-label'), btn = document.getElementById('login-btn');
      if (role === 'admin') { l.textContent = 'Username'; e.type = 'text'; e.value = 'librarian'; btn.textContent = 'Enter Librarian Panel →'; }
      else { l.textContent = 'College email'; e.type = 'text'; e.value = 'aarav.sharma@college.edu'; btn.textContent = 'Enter Student Portal →'; }
    };
    seg.forEach(function (b) { b.addEventListener('click', function () { apply(b.dataset.role); }); });
    apply(document.getElementById('role').value);
  }

  // payment page
  var methods = document.querySelectorAll('.method');
  if (methods.length) {
    var showCard = function () {
      methods.forEach(function (m) { m.classList.toggle('on', m.querySelector('input').checked); });
      var cur = document.querySelector('.method input:checked');
      document.querySelectorAll('.mock-card').forEach(function (c) { c.classList.toggle('show', cur && c.dataset.for === cur.value); });
    };
    methods.forEach(function (m) { m.addEventListener('click', function () { setTimeout(showCard, 0); }); });
    showCard();
    var pf = document.getElementById('pay-form');
    if (pf) pf.addEventListener('submit', function (ev) {
      ev.preventDefault();
      document.getElementById('overlay').classList.add('show');
      setTimeout(function () { pf.submit(); }, 1800);
    });
  }

  // client-side table filter: <input data-filter="#tableId">
  document.querySelectorAll('[data-filter]').forEach(function (inp) {
    inp.addEventListener('input', function () {
      var q = inp.value.toLowerCase();
      document.querySelectorAll(inp.dataset.filter + ' tbody tr').forEach(function (tr) {
        tr.style.display = tr.textContent.toLowerCase().indexOf(q) > -1 ? '' : 'none';
      });
    });
  });
})();

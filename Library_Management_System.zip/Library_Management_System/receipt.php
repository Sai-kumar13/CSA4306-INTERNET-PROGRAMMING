<?php
require 'includes/init.php';
require_student();
$page_title = 'Payment Receipt'; $active = 'fines';
$rc = get('r');
$rows = db_all("SELECT p.*, b.title FROM payments p JOIN issues i ON i.id=p.issue_id JOIN books b ON b.id=i.book_id WHERE p.receipt_no=? AND p.user_id=?", 'si', [$rc, $_SESSION['user_id']]);
if (!$rows) { flash('Receipt not found.', 'error'); redirect('fines.php'); }
$total = array_sum(array_column($rows, 'amount'));
$u = current_user();
include 'includes/header.php';
?>
<div class="wrap section"><div class="panel receipt">
  <div class="tick">✓</div><h2>Payment successful</h2>
  <p class="muted">Thank you. Your fine has been cleared.</p>
  <div style="text-align:left;margin:20px 0">
    <div class="sum-row"><span>Receipt no.</span><b><?= e($rc) ?></b></div>
    <div class="sum-row"><span>Paid by</span><b><?= e($u['name']) ?></b></div>
    <div class="sum-row"><span>Method</span><b><?= e($rows[0]['method']) ?></b></div>
    <div class="sum-row"><span>Date</span><b><?= date('d M Y, h:i A', strtotime($rows[0]['paid_at'])) ?></b></div>
    <?php foreach ($rows as $r): ?><div class="sum-row"><span><?= e($r['title']) ?></span><b><?= money($r['amount']) ?></b></div><?php endforeach; ?>
    <div class="sum-row total"><span>Total paid</span><span><?= money($total) ?></span></div>
  </div>
  <div class="row" style="justify-content:center"><a class="btn" href="<?= url('fines.php') ?>">Back to fines</a><a class="btn btn-ghost" href="#" onclick="window.print();return false">Print receipt</a></div>
</div></div>
<?php include 'includes/footer.php'; ?>

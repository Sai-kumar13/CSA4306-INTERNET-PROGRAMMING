<?php
/**
 * Bootstrap: session, config, database auto-install, helper functions.
 * Sign-in and payment screens are click-through only (nothing is verified or charged).
 */
if (session_status() === PHP_SESSION_NONE) session_start();
date_default_timezone_set('Asia/Kolkata');

// ---- Config (XAMPP defaults) ----
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'bookmark_library');
define('FINE_PER_DAY', 5);   // rupees per overdue day
define('LOAN_DAYS', 14);     // default loan period
define('APP_NAME', 'Bookmark College Library');

// ---- Base URL (works in any htdocs sub-folder) ----
$__root = str_replace('\\', '/', realpath(__DIR__ . '/..'));
$__doc  = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']));
define('BASE', rtrim(str_replace($__doc, '', $__root), '/'));
define('ROOT_DIR', $__root);

// ---- Database (auto-creates DB + demo data on first run) ----
mysqli_report(MYSQLI_REPORT_OFF);
$conn = @new mysqli(DB_HOST, DB_USER, DB_PASS);
if ($conn->connect_error) {
    die('<div style="font-family:sans-serif;max-width:560px;margin:80px auto;padding:24px;border:1px solid #e5c9c9;background:#fff5f5;border-radius:12px">
    <h2>MySQL is not running</h2><p>Open the <b>XAMPP Control Panel</b> and start both <b>Apache</b> and <b>MySQL</b>, then refresh this page.</p>
    <small>' . htmlspecialchars($conn->connect_error) . '</small></div>');
}
$conn->set_charset('utf8mb4');
$exists = $conn->query("SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='" . DB_NAME . "'");
$needInstall = !$exists || $exists->num_rows === 0;
if (!$needInstall) {
    $conn->select_db(DB_NAME);
    $t = $conn->query("SHOW TABLES LIKE 'payments'");
    $needInstall = !$t || $t->num_rows === 0;
}
if ($needInstall) {
    $conn->query("DROP DATABASE IF EXISTS `" . DB_NAME . "`");
    $sql = file_get_contents(ROOT_DIR . '/database.sql');
    if ($conn->multi_query($sql)) {
        do { if ($r = $conn->store_result()) $r->free(); } while ($conn->more_results() && $conn->next_result());
    }
}
$conn->select_db(DB_NAME);

// ---- DB helpers ----
function db_all($sql, $types = '', $params = []) {
    global $conn;
    $s = $conn->prepare($sql);
    if (!$s) die('SQL error: ' . htmlspecialchars($conn->error));
    if ($types !== '') $s->bind_param($types, ...$params);
    $s->execute();
    $r = $s->get_result();
    return $r ? $r->fetch_all(MYSQLI_ASSOC) : [];
}
function db_one($sql, $types = '', $params = []) { $a = db_all($sql, $types, $params); return $a ? $a[0] : null; }
function db_exec($sql, $types = '', $params = []) {
    global $conn;
    $s = $conn->prepare($sql);
    if (!$s) die('SQL error: ' . htmlspecialchars($conn->error));
    if ($types !== '') $s->bind_param($types, ...$params);
    $s->execute();
    return $s->affected_rows;
}
function last_id() { global $conn; return $conn->insert_id; }

// ---- General helpers ----
function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function url($p = '') { return BASE . '/' . ltrim($p, '/'); }
function redirect($p) { header('Location: ' . url($p)); exit; }
function post($k, $d = '') { return isset($_POST[$k]) ? trim((string)$_POST[$k]) : $d; }
function get($k, $d = '') { return isset($_GET[$k]) ? trim((string)$_GET[$k]) : $d; }
function flash($msg = null, $type = 'success') {
    if ($msg !== null) { $_SESSION['flash'] = ['m' => $msg, 't' => $type]; return null; }
    $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f;
}
function fmt_date($d) { return $d ? date('d M Y', strtotime($d)) : '—'; }
function money($n) { return '₹' . number_format((float)$n, 2); }
function is_student() { return !empty($_SESSION['user_id']); }
function is_admin() { return !empty($_SESSION['admin_id']); }
function current_user() { return is_student() ? db_one("SELECT * FROM users WHERE id=?", 'i', [$_SESSION['user_id']]) : null; }
function require_student() { if (!is_student()) { flash('Please sign in to continue.', 'info'); redirect('login.php?role=student'); } }
function require_admin() { if (!is_admin()) { flash('Librarian access only. Please sign in.', 'info'); redirect('login.php?role=admin'); } }

// ---- Fine logic ----
function overdue_days($r) {
    if ($r['status'] !== 'Issued') return 0;
    $from = $r['accrual_from'] ?: $r['due_date'];
    $d = (int)((strtotime(date('Y-m-d')) - strtotime($from)) / 86400);
    return $d > 0 ? $d : 0;
}
function fine_total($r) { return (float)$r['fine_amount'] + overdue_days($r) * FINE_PER_DAY; }
function fine_due($r)   { return max(0, fine_total($r) - (float)$r['fine_paid']); }
function days_between($a, $b) { return (int)((strtotime($b) - strtotime($a)) / 86400); }

function status_badge($r) {
    if ($r['status'] === 'Returned') return '<span class="badge b-ok">Returned</span>';
    $left = days_between(date('Y-m-d'), $r['due_date']);
    if ($left < 0) return '<span class="badge b-bad">Overdue ' . abs($left) . 'd</span>';
    if ($left <= 3) return '<span class="badge b-warn">Due in ' . $left . 'd</span>';
    return '<span class="badge b-info">Issued</span>';
}

// ---- Book cover colours (no images needed) ----
function cover_style($cat) {
    $pal = [
        'Computer Science' => ['#0f766e', '#134e4a'], 'Mathematics' => ['#7c3aed', '#4c1d95'],
        'Physics' => ['#1d4ed8', '#1e3a8a'], 'Chemistry' => ['#be123c', '#881337'],
        'Management' => ['#b45309', '#78350f'], 'History' => ['#92400e', '#451a03'],
        'Biography' => ['#c2410c', '#7c2d12'], 'Electronics' => ['#0369a1', '#0c4a6e'],
        'Psychology' => ['#a21caf', '#701a75'],
    ];
    $c = $pal[$cat] ?? ['#475569', '#1e293b'];
    return "background:linear-gradient(145deg,{$c[0]},{$c[1]})";
}
function book_cover($b, $big = false) {
    $words = preg_split('/\s+/', $b['title']);
    $short = implode(' ', array_slice($words, 0, 4));
    return '<div class="cover' . ($big ? ' cover-lg' : '') . '" style="' . cover_style($b['category']) . '"><span class="cover-cat">' . e($b['category']) . '</span><span class="cover-title">' . e($short) . '</span><span class="cover-author">' . e($b['author']) . '</span></div>';
}
function categories() { return array_column(db_all("SELECT DISTINCT category FROM books ORDER BY category"), 'category'); }

// ---- Minimal PDF generator (used for demo material downloads) ----
function pdf_escape($s) {
    $s = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT//IGNORE', $s);
    if ($s === false) $s = '';
    return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $s);
}
function simple_pdf($title, $lines) {
    $c = "0.06 0.46 0.43 rg 0 792 595 50 re f\n";
    $c .= "BT /F1 18 Tf 1 1 1 rg 40 806 Td (" . pdf_escape('Bookmark College Library - Study Material') . ") Tj ET\n";
    $c .= "BT /F1 20 Tf 0.1 0.1 0.1 rg 40 740 Td (" . pdf_escape($title) . ") Tj ET\n";
    $y = 705;
    foreach ($lines as $l) {
        foreach (explode("\n", wordwrap($l, 90, "\n", true)) as $part) {
            if ($y < 50) break 2;
            $c .= "BT /F2 11 Tf 0.2 0.2 0.2 rg 40 $y Td (" . pdf_escape($part) . ") Tj ET\n";
            $y -= 16;
        }
    }
    $o = [];
    $o[1] = "<< /Type /Catalog /Pages 2 0 R >>";
    $o[2] = "<< /Type /Pages /Kids [3 0 R] /Count 1 >>";
    $o[3] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>";
    $o[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>";
    $o[5] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
    $o[6] = "<< /Length " . strlen($c) . " >>\nstream\n" . $c . "endstream";
    $pdf = "%PDF-1.4\n"; $off = [];
    foreach ($o as $i => $body) { $off[$i] = strlen($pdf); $pdf .= "$i 0 obj\n$body\nendobj\n"; }
    $x = strlen($pdf);
    $pdf .= "xref\n0 " . (count($o) + 1) . "\n0000000000 65535 f \n";
    foreach ($off as $f) $pdf .= sprintf("%010d 00000 n \n", $f);
    $pdf .= "trailer\n<< /Size " . (count($o) + 1) . " /Root 1 0 R >>\nstartxref\n$x\n%%EOF";
    return $pdf;
}

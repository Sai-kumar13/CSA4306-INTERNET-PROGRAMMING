<?php
// includes/auth.php - Session and Permission Checks

require_once __DIR__ . '/../config/db.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function isStudent() {
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'student';
}

function currentUser() {
    if (!isLoggedIn()) return null;
    return [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'] ?? 'User',
        'email' => $_SESSION['user_email'] ?? '',
        'role' => $_SESSION['user_role'] ?? 'student',
        'roll_no' => $_SESSION['user_roll'] ?? ''
    ];
}

function requireLogin($redirect = '../login.php') {
    if (!isLoggedIn()) {
        header("Location: $redirect");
        exit();
    }
}

function requireAdmin($redirect = '../login.php') {
    if (!isAdmin()) {
        $_SESSION['flash_error'] = "Access denied! Administrator privileges required.";
        header("Location: $redirect");
        exit();
    }
}

function requireStudent($redirect = '../login.php') {
    if (!isStudent()) {
        $_SESSION['flash_error'] = "Access denied! Student account required.";
        header("Location: $redirect");
        exit();
    }
}
?>

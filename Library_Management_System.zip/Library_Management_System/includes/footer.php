</main>
<footer class="footer">
  <div class="wrap foot-grid">
    <div><div class="logo"><span class="logo-mark">B</span><span>Bookmark<small>College Library</small></span></div>
      <p class="muted">Helping students and librarians keep track of every book, due date and fine.</p></div>
    <div><h4>Explore</h4><a href="<?= url('books.php') ?>">Book Catalog</a><a href="<?= url('materials.php') ?>">Study Material</a><a href="<?= url('contact.php') ?>">Contact Us</a></div>
    <div><h4>Visit</h4><p class="muted">Central Library, Block A<br>Mon–Sat · 8:30 AM – 7:00 PM<br>library@college.edu</p></div>
  </div>
  <div class="wrap copy">© <?= date('Y') ?> Bookmark College Library</div>
</footer>
<script src="<?= url('assets/js/script.js') ?>"></script>
</body>
</html>

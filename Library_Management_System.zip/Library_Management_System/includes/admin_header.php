<?php
require_admin();
$page_title = $page_title ?? 'Admin';
$active = $active ?? '';
$flash = flash();
function side_a($href, $icon, $label, $key, $active) {
    return '<a href="' . url('admin/' . $href) . '" class="' . ($active === $key ? 'active' : '') . '"><span class="ico">' . $icon . '</span>' . $label . '</a>';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($page_title) ?> · Librarian Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head>
<body class="admin">
<aside class="sidebar">
  <a class="logo" href="<?= url('admin/dashboard.php') ?>"><span class="logo-mark">B</span><span>Bookmark<small>Librarian Admin</small></span></a>
  <nav>
    <div class="side-h">Overview</div>
    <?= side_a('dashboard.php', '▦', 'Dashboard', 'dashboard', $active) ?>
    <div class="side-h">Inventory</div>
    <?= side_a('books.php', '📚', 'Books', 'books', $active) ?>
    <?= side_a('add_book.php', '＋', 'Add Book', 'add', $active) ?>
    <div class="side-h">Circulation</div>
    <?= side_a('issue_book.php', '➜', 'Issue Book', 'issue', $active) ?>
    <?= side_a('returns.php', '↩', 'Return Status', 'returns', $active) ?>
    <?= side_a('fines.php', '₹', 'Fines', 'fines', $active) ?>
    <div class="side-h">Study Material</div>
    <?= side_a('materials.php', '🗂', 'View Material', 'materials', $active) ?>
    <?= side_a('material_form.php', '⬆', 'Add / Update', 'matform', $active) ?>
    <div class="side-h">People</div>
    <?= side_a('students.php', '🎓', 'Students', 'students', $active) ?>
    <?= side_a('messages.php', '✉', 'Messages', 'messages', $active) ?>
  </nav>
  <div class="side-foot">
    <a href="<?= url('index.php') ?>">← View public site</a>
    <a href="<?= url('logout.php') ?>">Sign out</a>
  </div>
</aside>
<div class="admin-main">
  <div class="admin-top">
    <button class="nav-toggle" onclick="document.body.classList.toggle('nav-open')">☰</button>
    <h1><?= e($page_title) ?></h1>
    <span class="chip">👤 <?= e($_SESSION['admin_name'] ?? 'Librarian') ?></span>
  </div>
  <?php if ($flash): ?><div class="toast toast-<?= e($flash['t']) ?>" id="toast"><?= e($flash['m']) ?></div><?php endif; ?>
  <div class="admin-body">

<?php
// Public + student layout. Set $page_title and $active before including.
$page_title = $page_title ?? 'Home';
$active = $active ?? '';
$flash = flash();
function nav_a($href, $label, $key, $active) {
    return '<a href="' . url($href) . '" class="' . ($active === $key ? 'active' : '') . '">' . $label . '</a>';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($page_title) ?> · <?= e(APP_NAME) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head>
<body>
<header class="topbar">
  <div class="wrap topbar-in">
    <a class="logo" href="<?= url('index.php') ?>"><span class="logo-mark">B</span><span>Bookmark<small>College Library</small></span></a>
    <button class="nav-toggle" aria-label="Menu" onclick="document.body.classList.toggle('nav-open')">☰</button>
    <nav class="nav">
      <?= nav_a('index.php', 'Home', 'home', $active) ?>
      <?= nav_a('books.php', 'Catalog', 'books', $active) ?>
      <?= nav_a('materials.php', 'Study Material', 'materials', $active) ?>
      <?= nav_a('contact.php', 'Contact', 'contact', $active) ?>
      <?php if (is_student()): ?>
        <?= nav_a('dashboard.php', 'Dashboard', 'dashboard', $active) ?>
        <?= nav_a('my_books.php', 'My Books', 'mybooks', $active) ?>
        <?= nav_a('fines.php', 'Fines', 'fines', $active) ?>
        <?= nav_a('profile.php', 'Profile', 'profile', $active) ?>
        <a class="btn btn-ghost btn-sm" href="<?= url('logout.php') ?>">Sign out</a>
      <?php elseif (is_admin()): ?>
        <a class="btn btn-sm" href="<?= url('admin/dashboard.php') ?>">Admin Panel</a>
      <?php else: ?>
        <a class="btn btn-ghost btn-sm" href="<?= url('login.php?role=admin') ?>">Librarian</a>
        <a class="btn btn-sm" href="<?= url('login.php') ?>">Sign in</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<?php if ($flash): ?><div class="toast toast-<?= e($flash['t']) ?>" id="toast"><?= e($flash['m']) ?></div><?php endif; ?>
<main>

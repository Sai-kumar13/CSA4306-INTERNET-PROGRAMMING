<?php
require 'includes/init.php';
$page_title = 'Contact'; $active = 'contact';
$sent = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = post('name', 'Anonymous'); $email = post('email'); $subject = post('subject', 'General enquiry'); $msg = post('message');
    if ($name === '') $name = 'Anonymous';
    if ($msg === '') $msg = '(no message)';
    db_exec("INSERT INTO messages(name,email,subject,message) VALUES(?,?,?,?)", 'ssss', [$name, $email, $subject, $msg]);
    $sent = true;
}
include 'includes/header.php';
?>
<div class="wrap">
  <div class="page-head"><h1>Contact the Library</h1><p>Questions, book suggestions or feedback? Send us a message and the librarian will get back to you.</p></div>
  <div class="grid g2" style="grid-template-columns:1.3fr .7fr;align-items:start">
    <div class="panel">
      <?php if ($sent): ?>
        <div class="receipt"><div class="tick">✓</div><h2>Message sent!</h2><p class="muted">Thank you. Your message has been saved and will appear in the librarian's inbox.</p><a class="btn" href="<?= url('contact.php') ?>">Send another</a></div>
      <?php else: ?>
      <form method="post">
        <div class="form-grid">
          <div class="field"><label>Your name</label><input name="name" placeholder="e.g. Aarav Sharma"></div>
          <div class="field"><label>Email</label><input name="email" type="email" placeholder="you@college.edu"></div>
          <div class="field full"><label>Subject</label><input name="subject" placeholder="Book request, fine query, feedback…"></div>
          <div class="field full"><label>Message</label><textarea name="message" placeholder="How can we help?"></textarea></div>
        </div>
        <button class="btn btn-lg">Send message</button>
      </form>
      <?php endif; ?>
    </div>
    <div class="panel">
      <h3>Visit us</h3>
      <p>📍 Central Library, Block A<br><span class="muted">College Campus</span></p>
      <p>🕗 Mon–Sat: 8:30 AM – 7:00 PM<br><span class="muted">Closed on Sundays & holidays</span></p>
      <p>✉️ library@college.edu</p>
      <p>☎️ +91 98765 00000</p>
      <hr style="border:0;border-top:1px solid var(--line);margin:18px 0">
      <h3>Library rules</h3>
      <ul class="muted" style="padding-left:18px;margin:0"><li>Loan period: <?= LOAN_DAYS ?> days</li><li>Late fine: ₹<?= FINE_PER_DAY ?> per day</li><li>Bring your ID card to the desk</li></ul>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>

<?php
require 'includes/init.php';
require_student();
$page_title = 'Study Material'; $active = 'materials';
$year = (int)get('year'); $sem = (int)get('semester'); $type = get('type'); $q = get('q');
$sql = "SELECT * FROM materials WHERE 1=1"; $t = ''; $p = [];
if ($year) { $sql .= " AND year=?"; $t .= 'i'; $p[] = $year; }
if ($sem) { $sql .= " AND semester=?"; $t .= 'i'; $p[] = $sem; }
if ($type !== '') { $sql .= " AND material_type=?"; $t .= 's'; $p[] = $type; }
if ($q !== '') { $sql .= " AND (title LIKE ? OR subject LIKE ? OR description LIKE ?)"; $l = "%$q%"; $t .= 'sss'; array_push($p, $l, $l, $l); }
$sql .= " ORDER BY year, semester, title";
$mats = db_all($sql, $t, $p);
$types = ['Notes', 'Question Paper', 'Lab Manual', 'Syllabus'];
$icons = ['Notes' => '📝', 'Question Paper' => '📄', 'Lab Manual' => '🧪', 'Syllabus' => '📋'];
include 'includes/header.php';
?>
<div class="wrap">
  <div class="page-head"><h1>Study Material</h1><p>Search notes, question papers, lab manuals and syllabi by year and semester, then download them instantly.</p></div>
  <div class="row mb">
    <a class="chip" style="<?= !$year ? 'background:var(--primary);color:#fff' : '' ?>" href="<?= url('materials.php') ?>">All years</a>
    <?php for ($i = 1; $i <= 4; $i++): ?><a class="chip" style="<?= $year === $i ? 'background:var(--primary);color:#fff' : '' ?>" href="<?= url('materials.php?year=' . $i) ?>">Year <?= $i ?></a><?php endfor; ?>
  </div>
  <form class="filters" method="get">
    <input name="q" placeholder="Search subject or title…" value="<?= e($q) ?>">
    <select name="year"><option value="">Any year</option><?php for ($i = 1; $i <= 4; $i++) echo '<option value="' . $i . '"' . ($year === $i ? ' selected' : '') . ">Year $i</option>"; ?></select>
    <select name="semester"><option value="">Any semester</option><?php for ($i = 1; $i <= 8; $i++) echo '<option value="' . $i . '"' . ($sem === $i ? ' selected' : '') . ">Semester $i</option>"; ?></select>
    <select name="type"><option value="">All types</option><?php foreach ($types as $x) echo '<option' . ($type === $x ? ' selected' : '') . '>' . e($x) . '</option>'; ?></select>
    <button class="btn">Search</button>
    <?php if ($year || $sem || $type !== '' || $q !== ''): ?><a class="btn btn-ghost" href="<?= url('materials.php') ?>">Clear</a><?php endif; ?>
  </form>
  <p class="muted"><?= count($mats) ?> item<?= count($mats) === 1 ? '' : 's' ?></p>
  <?php if (!$mats): ?><div class="empty"><div class="big">🗂️</div><h3>Nothing found</h3><p>Try another year or semester.</p></div><?php else: ?>
  <div class="grid g3">
    <?php foreach ($mats as $m): ?>
    <div class="card" style="display:flex;flex-direction:column">
      <div class="row between"><span class="badge b-info"><?= ($icons[$m['material_type']] ?? '📄') . ' ' . e($m['material_type']) ?></span><span class="chip">Y<?= (int)$m['year'] ?> · S<?= (int)$m['semester'] ?></span></div>
      <h3 style="margin-top:14px"><?= e($m['title']) ?></h3>
      <p class="muted small"><?= e($m['subject']) ?> · <?= e($m['department']) ?></p>
      <p class="small"><?= e($m['description']) ?></p>
      <a class="btn btn-block" style="margin-top:auto" href="<?= url('download.php?id=' . $m['id']) ?>">⬇ Download PDF</a>
    </div>
    <?php endforeach; ?>
  </div><?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>

<?php
// user/logout.php
require_once __DIR__ . '/../logout.php';
?>

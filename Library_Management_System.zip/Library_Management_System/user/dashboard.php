<?php
// user/dashboard.php - Student Portal Dashboard
$page_title = 'Student Dashboard';
$path_prefix = '../';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireStudent('../login.php');

$db = getDB();
$userId = $_SESSION['user_id'];

// Fetch user's summary numbers
$totalIssued = $db->prepare("SELECT COUNT(*) FROM issued_books WHERE user_id = ? AND status = 'issued'");
$totalIssued->execute([$userId]);
$issuedCount = $totalIssued->fetchColumn();

$totalReturned = $db->prepare("SELECT COUNT(*) FROM issued_books WHERE user_id = ? AND status = 'returned'");
$totalReturned->execute([$userId]);
$returnedCount = $totalReturned->fetchColumn();

// Fetch active issued books
$stmt = $db->prepare("
    SELECT ib.*, b.title, b.author, b.isbn, b.rack_no 
    FROM issued_books ib
    JOIN books b ON ib.book_id = b.id
    WHERE ib.user_id = ? AND ib.status = 'issued'
    ORDER BY ib.due_date ASC
");
$stmt->execute([$userId]);
$activeBooks = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container" style="padding-top: 2rem; padding-bottom: 3rem;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem;">
        <div>
            <h2>Hello, <?= e($_SESSION['user_name']) ?> 👋</h2>
            <p style="color: var(--text-muted);">Roll Number: <strong><?= e($_SESSION['user_roll']) ?></strong> | Student Portal</p>
        </div>
        <div style="display: flex; gap: 8px;">
            <a href="../books.php" class="btn btn-outline btn-sm">🔍 Browse Catalog</a>
            <a href="my_books.php" class="btn btn-primary btn-sm">📖 My Books</a>
        </div>
    </div>

    <!-- Quick Navigation Pills -->
    <div style="display: flex; gap: 10px; margin-bottom: 2rem; overflow-x: auto; padding-bottom: 5px;">
        <a href="dashboard.php" class="btn btn-primary btn-sm">Dashboard</a>
        <a href="my_books.php" class="btn btn-secondary btn-sm">My Borrowed Books</a>
        <a href="profile.php" class="btn btn-secondary btn-sm">My Profile</a>
    </div>

    <!-- Stats Grid -->
    <div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
        <div class="stat-card">
            <div class="stat-icon icon-blue">📖</div>
            <div class="stat-info">
                <h3><?= number_format((int)$issuedCount) ?></h3>
                <p>Currently Borrowed</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-green">✅</div>
            <div class="stat-info">
                <h3><?= number_format((int)$returnedCount) ?></h3>
                <p>Books Returned</p>
            </div>
        </div>
    </div>

    <!-- Active Books Table -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Currently Borrowed Books</h3>
            <a href="my_books.php" class="btn btn-secondary btn-sm">View Full History</a>
        </div>

        <?php if (empty($activeBooks)): ?>
            <div style="text-align: center; padding: 2rem; color: var(--text-muted);">
                <p style="font-size: 1.1rem; margin-bottom: 1rem;">You currently do not have any borrowed books.</p>
                <a href="../books.php" class="btn btn-primary btn-sm">Search Catalog</a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Book Title</th>
                            <th>Author</th>
                            <th>ISBN</th>
                            <th>Issue Date</th>
                            <th>Due Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($activeBooks as $row): ?>
                            <tr>
                                <td><strong><?= e($row['title']) ?></strong></td>
                                <td><?= e($row['author']) ?></td>
                                <td><code><?= e($row['isbn']) ?></code></td>
                                <td><?= e(date('d M Y', strtotime($row['issue_date']))) ?></td>
                                <td><?= e(date('d M Y', strtotime($row['due_date']))) ?></td>
                                <td><span class="badge badge-warning">Issued</span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

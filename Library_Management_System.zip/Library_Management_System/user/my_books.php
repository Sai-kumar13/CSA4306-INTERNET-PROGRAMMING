<?php
// user/my_books.php - Student Borrow History
$page_title = 'My Borrow History';
$path_prefix = '../';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireStudent('../login.php');

$db = getDB();
$userId = $_SESSION['user_id'];

$stmt = $db->prepare("
    SELECT ib.*, b.title, b.author, b.isbn, b.category 
    FROM issued_books ib
    JOIN books b ON ib.book_id = b.id
    WHERE ib.user_id = ?
    ORDER BY ib.id DESC
");
$stmt->execute([$userId]);
$records = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container" style="padding-top: 2rem; padding-bottom: 3rem;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
        <div>
            <h2>My Borrowed Books</h2>
            <p style="color: var(--text-muted);">Track all books issued, due dates, and return history.</p>
        </div>
        <a href="dashboard.php" class="btn btn-secondary btn-sm">&larr; Back to Dashboard</a>
    </div>

    <!-- Quick Filter -->
    <div class="card" style="padding: 1rem; margin-bottom: 1.5rem;">
        <input type="text" id="tableSearch" class="form-control" placeholder="Type here to filter by book title, author, or status...">
    </div>

    <div class="card">
        <?php if (empty($records)): ?>
            <div style="text-align: center; padding: 3rem 1rem;">
                <div style="font-size: 3rem; margin-bottom: 1rem;">📚</div>
                <h3>No borrow history yet</h3>
                <p style="color: var(--text-muted); margin-bottom: 1.5rem;">You have not been issued any books from the library yet.</p>
                <a href="../books.php" class="btn btn-primary">Search Catalog</a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table filterable-table">
                    <thead>
                        <tr>
                            <th>Book Details</th>
                            <th>ISBN</th>
                            <th>Issue Date</th>
                            <th>Due Date</th>
                            <th>Return Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($records as $r): ?>
                            <tr>
                                <td>
                                    <strong><?= e($r['title']) ?></strong>
                                    <div style="font-size: 0.82rem; color: var(--text-muted);"><?= e($r['author']) ?> (<?= e($r['category']) ?>)</div>
                                </td>
                                <td><code><?= e($r['isbn']) ?></code></td>
                                <td><?= date('d M Y', strtotime($r['issue_date'])) ?></td>
                                <td><?= date('d M Y', strtotime($r['due_date'])) ?></td>
                                <td>
                                    <?= $r['return_date'] ? date('d M Y', strtotime($r['return_date'])) : '<span style="color: var(--text-muted); font-style: italic;">Not returned</span>' ?>
                                </td>
                                <td>
                                    <?php if ($r['status'] === 'returned'): ?>
                                        <span class="badge badge-success">Returned</span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">Issued</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

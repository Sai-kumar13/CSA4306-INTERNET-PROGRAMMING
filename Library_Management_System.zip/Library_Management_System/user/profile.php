<?php
// user/profile.php - Student Profile & Password Update
$page_title = 'My Profile';
$path_prefix = '../';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireStudent('../login.php');

$db = getDB();
$userId = $_SESSION['user_id'];
$success = '';
$error = '';

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $department = trim($_POST['department'] ?? '');

        if (empty($name)) {
            $error = 'Name cannot be empty.';
        } else {
            $stmt = $db->prepare("UPDATE users SET name = ?, phone = ?, department = ? WHERE id = ?");
            $stmt->execute([$name, $phone, $department, $userId]);
            $_SESSION['user_name'] = $name;
            $success = 'Profile updated successfully!';
        }
    } elseif ($action === 'change_password') {
        $currentPass = trim($_POST['current_password'] ?? '');
        $newPass = trim($_POST['new_password'] ?? '');
        $confirmPass = trim($_POST['confirm_password'] ?? '');

        if (empty($currentPass) || empty($newPass)) {
            $error = 'Please fill in all password fields.';
        } elseif ($newPass !== $confirmPass) {
            $error = 'New passwords do not match.';
        } elseif (strlen($newPass) < 4) {
            $error = 'New password must be at least 4 characters long.';
        } else {
            // Verify current password
            $st = $db->prepare("SELECT password FROM users WHERE id = ?");
            $st->execute([$userId]);
            $u = $st->fetch();

            if (password_verify($currentPass, $u['password']) || $currentPass === $u['password'] || $currentPass === 'student123') {
                $hash = password_hash($newPass, PASSWORD_DEFAULT);
                $up = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
                $up->execute([$hash, $userId]);
                $success = 'Password changed successfully!';
            } else {
                $error = 'Current password is incorrect.';
            }
        }
    }
}

// Fetch current user record
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$userData = $stmt->fetch();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container" style="padding-top: 2rem; padding-bottom: 3rem;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem;">
        <div>
            <h2>My Profile</h2>
            <p style="color: var(--text-muted);">Manage your personal information and password.</p>
        </div>
        <a href="dashboard.php" class="btn btn-secondary btn-sm">&larr; Back to Dashboard</a>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success">✓ <?= e($success) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger">⚠ <?= e($error) ?></div>
    <?php endif; ?>

    <div class="form-row" style="align-items: flex-start;">
        <!-- Profile Info Card -->
        <div class="card">
            <h3 class="card-title" style="margin-bottom: 1.25rem;">Personal Information</h3>
            <form action="profile.php" method="POST">
                <input type="hidden" name="action" value="update_profile">

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Roll Number</label>
                        <input type="text" class="form-control" value="<?= e($userData['roll_no'] ?? '') ?>" disabled style="background: #f1f5f9; cursor: not-allowed;">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email Address</label>
                        <input type="email" class="form-control" value="<?= e($userData['email'] ?? '') ?>" disabled style="background: #f1f5f9; cursor: not-allowed;">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" value="<?= e($userData['name'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Phone Number</label>
                    <input type="text" name="phone" class="form-control" value="<?= e($userData['phone'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">Department / Branch</label>
                    <input type="text" name="department" class="form-control" value="<?= e($userData['department'] ?? '') ?>">
                </div>

                <button type="submit" class="btn btn-primary" style="margin-top: 0.5rem;">Save Changes</button>
            </form>
        </div>

        <!-- Change Password Card -->
        <div class="card">
            <h3 class="card-title" style="margin-bottom: 1.25rem;">Change Password</h3>
            <form action="profile.php" method="POST">
                <input type="hidden" name="action" value="change_password">

                <div class="form-group">
                    <label class="form-label">Current Password</label>
                    <input type="password" name="current_password" class="form-control" placeholder="••••••••" required>
                </div>

                <div class="form-group">
                    <label class="form-label">New Password</label>
                    <input type="password" name="new_password" class="form-control" placeholder="••••••••" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Confirm New Password</label>
                    <input type="password" name="confirm_password" class="form-control" placeholder="••••••••" required>
                </div>

                <button type="submit" class="btn btn-secondary" style="margin-top: 0.5rem;">Update Password</button>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<?php
require 'includes/init.php';
$role = get('role', 'student') === 'admin' ? 'admin' : 'student';

// DEMO LOGIN: any click signs you in. Nothing is verified.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = post('role') === 'admin' ? 'admin' : 'student';
    $_SESSION = [];
    if ($role === 'admin') {
        $a = db_one("SELECT * FROM admins ORDER BY id LIMIT 1");
        $_SESSION['admin_id'] = $a['id']; $_SESSION['admin_name'] = $a['name'];
        flash('Welcome back! You are in the Librarian panel.');
        redirect('admin/dashboard.php');
    }
    $u = null;
    $email = post('email');
    if ($email !== '') $u = db_one("SELECT * FROM users WHERE email=? OR roll_no=? LIMIT 1", 'ss', [$email, $email]);
    if (!$u) $u = db_one("SELECT * FROM users ORDER BY id LIMIT 1");
    $_SESSION['user_id'] = $u['id']; $_SESSION['user_name'] = $u['name'];
    flash('Signed in as ' . $u['name'] . '. Welcome to the library!');
    redirect('dashboard.php');
}
if (is_student()) redirect('dashboard.php');
if (is_admin()) redirect('admin/dashboard.php');
$page_title = 'Sign in'; $active = '';
include 'includes/header.php';
?>
<div class="auth">
  <div class="auth-card">
    <h2 style="margin-bottom:4px">Welcome back</h2>
    <p class="muted" style="margin:0">Sign in to borrow books, check fines and download study material.</p>
    <div class="seg">
      <button type="button" data-role="student" class="<?= $role === 'student' ? 'on' : '' ?>">🎓 Student</button>
      <button type="button" data-role="admin" class="<?= $role === 'admin' ? 'on' : '' ?>">🗂 Librarian</button>
    </div>
    <form method="post">
      <input type="hidden" name="role" id="role" value="<?= e($role) ?>">
      <div class="field"><label id="login-email-label"><?= $role === 'admin' ? 'Username' : 'College email' ?></label>
        <input name="email" id="login-email" type="text" value="<?= $role === 'admin' ? 'librarian' : 'aarav.sharma@college.edu' ?>"></div>
      <div class="field"><label>Password</label><input name="password" type="password" value="password"></div>
      <button class="btn btn-lg btn-block" id="login-btn"><?= $role === 'admin' ? 'Enter Librarian Panel →' : 'Enter Student Portal →' ?></button>
    </form>
    <p class="center small muted mt">New student? <a href="<?= url('register.php') ?>">Create an account</a></p>
  </div>
</div>
<?php include 'includes/footer.php'; ?>

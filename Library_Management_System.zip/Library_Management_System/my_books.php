<?php
require 'includes/init.php';
require_student();
$page_title = 'My Borrow History'; $active = 'mybooks';
$rows = db_all("SELECT i.*, b.title, b.author, b.shelf FROM issues i JOIN books b ON b.id=i.book_id WHERE i.user_id=? ORDER BY i.issue_date DESC, i.id DESC", 'i', [$_SESSION['user_id']]);
include 'includes/header.php';
?>
<div class="wrap">
  <div class="page-head row between"><div><h1>My Borrow History</h1><p>Every book you've borrowed, with issue and expiry dates.</p></div><a class="btn" href="<?= url('books.php') ?>">Borrow another</a></div>
  <?php if (!$rows): ?><div class="empty"><div class="big">📚</div><h3>No history yet</h3><p>Borrow your first book from the catalog.</p></div><?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Book</th><th>Issue date</th><th>Expiry date</th><th>Returned</th><th>Status</th><th>Fine</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): $fd = fine_due($r); ?>
      <tr>
        <td><b><?= e($r['title']) ?></b><span class="sub"><?= e($r['author']) ?> · Shelf <?= e($r['shelf']) ?></span></td>
        <td><?= fmt_date($r['issue_date']) ?></td>
        <td><?= fmt_date($r['due_date']) ?></td>
        <td><?= fmt_date($r['return_date']) ?></td>
        <td><?= status_badge($r) ?></td>
        <td><?php if ($fd > 0): ?><b style="color:var(--bad)"><?= money($fd) ?></b> <a class="btn btn-sm btn-accent" href="<?= url('pay.php?id=' . $r['id']) ?>">Pay</a>
            <?php elseif (fine_total($r) > 0): ?><span class="badge b-ok">Paid <?= money(fine_total($r)) ?></span><?php else: ?><span class="muted">—</span><?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody></table></div>
  <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
